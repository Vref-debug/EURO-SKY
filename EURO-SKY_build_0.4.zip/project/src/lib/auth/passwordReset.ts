import { supabase } from '../supabase';
import { checkUserExists } from './userVerification';

export async function resetPassword(email: string): Promise<string> {
  const exists = await checkUserExists(email);
  
  if (!exists) {
    throw new Error('EURO-SKY user does not exist');
  }

  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/auth/reset-password`,
  });
  
  if (error) {
    throw new Error('Failed to send reset instructions');
  }
  
  return 'Reset instructions sent to EURO-SKY user';
}