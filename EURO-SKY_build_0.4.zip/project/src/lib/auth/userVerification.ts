import { supabase } from '../supabase';

export async function checkUserExists(email: string): Promise<boolean> {
  const { data, error } = await supabase.auth.admin.listUsers({
    filters: {
      email: email
    }
  });

  if (error) {
    console.error('Error checking user:', error);
    return false;
  }

  return data.users.length > 0;
}