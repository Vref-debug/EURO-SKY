import React from 'react';
import { Clock, CheckCircle } from 'lucide-react';

const mockHistory = [
  {
    id: 1,
    date: '2024-03-15',
    type: 'Inspection',
    status: 'Completed',
    notes: '100-hour inspection completed'
  },
  {
    id: 2,
    date: '2024-02-01',
    type: 'Maintenance',
    status: 'Completed',
    notes: 'Oil change and general maintenance'
  }
];

export function MaintenanceHistory() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-6">Maintenance History</h2>
      
      <div className="space-y-4">
        {mockHistory.map((record) => (
          <div
            key={record.id}
            className="border-l-4 border-sky-500 pl-4 py-2"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{record.date}</span>
              </div>
              <div className="flex items-center space-x-1">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm text-green-600">{record.status}</span>
              </div>
            </div>
            <h3 className="font-medium">{record.type}</h3>
            <p className="text-sm text-gray-600">{record.notes}</p>
          </div>
        ))}
      </div>
    </div>
  );
}