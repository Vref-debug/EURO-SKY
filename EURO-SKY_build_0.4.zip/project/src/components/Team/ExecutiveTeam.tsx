import React from 'react';
import { executiveTeamMembers } from './teamData';
import { ExecutiveCard } from './ExecutiveCard';

export function ExecutiveTeam() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      {executiveTeamMembers.map((member, index) => (
        <ExecutiveCard key={index} {...member} />
      ))}
    </div>
  );
}