import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Shield, Phone, Building2, User } from 'lucide-react';
import { signIn, signUp, resetPassword } from '../../lib/auth';
import toast from 'react-hot-toast';
import { SignUpForm } from './SignUpForm';

export function AuthForm() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isResetPassword, setIsResetPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isResetPassword) {
        const message = await resetPassword(email);
        toast.success(message);
        setIsResetPassword(false);
        return;
      }

      if (!isSignUp) {
        const { user } = await signIn(email, password);
        if (user) {
          navigate('/schedule');
        }
      }
    } catch (err: any) {
      if (err.message === 'Email not confirmed') {
        toast.error('Please confirm your email address before logging in');
      } else {
        toast.error(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const toggleMode = () => {
    setIsResetPassword(false);
    setIsSignUp(!isSignUp);
  };

  const toggleResetPassword = () => {
    setIsResetPassword(!isResetPassword);
    setIsSignUp(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <div className="flex justify-center mb-6">
        <Shield className="w-12 h-12 text-sky-600" />
      </div>
      
      <h2 className="text-2xl font-bold text-center mb-6">
        {isResetPassword ? 'Reset Password' : (isSignUp ? 'Create EURO-SKY account' : 'EURO-SKY Log In')}
      </h2>

      {isSignUp ? (
        <SignUpForm onCancel={toggleMode} />
      ) : (
        <>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email address <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
                  required
                />
              </div>
            </div>

            {!isResetPassword && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password <span className="text-red-500">*</span>
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
                  required
                  minLength={8}
                />
                <p className="mt-1 text-sm text-gray-500">
                  Must be at least 8 characters
                </p>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
            >
              {loading ? 'Processing...' : (isResetPassword ? 'Send Reset Instructions' : 'Log In')}
            </button>
          </form>

          <div className="mt-4 text-center space-y-2">
            <button
              onClick={toggleMode}
              className="text-sky-600 hover:text-sky-700 block w-full"
            >
              Need an account? Sign up
            </button>
            
            <button
              onClick={toggleResetPassword}
              className="text-sky-600 hover:text-sky-700 block w-full"
            >
              {isResetPassword ? 'Back to login' : 'Forgot your password?'}
            </button>
          </div>
        </>
      )}
    </div>
  );
}