import React from 'react';
import { serviceCategories } from './data';

export function ServicesDropdown({ isOpen }: { isOpen: boolean }) {
  if (!isOpen) return null;

  return (
    <div className="absolute top-full mt-2 w-72 bg-white rounded-lg shadow-lg py-2 z-50">
      {serviceCategories.map((category, index) => (
        <div key={index} className="py-2">
          <h3 className="px-4 py-1 text-sm font-semibold text-sky-900 bg-gray-50">
            {category.title}
          </h3>
          <ul className="text-gray-800">
            {category.items.map((item, itemIndex) => (
              <li 
                key={itemIndex}
                className="px-4 py-2 hover:bg-sky-50 cursor-pointer text-sm"
              >
                {item}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}