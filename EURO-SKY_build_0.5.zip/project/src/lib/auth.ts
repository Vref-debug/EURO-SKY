import { supabase } from './supabase';

export async function signUp(email: string, password: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        mfa_enabled: true
      },
      emailRedirectTo: `${window.location.origin}/auth`
    }
  });
  
  if (error) throw error;
  
  // Sign in immediately after signup since email confirmation is disabled
  if (data.user) {
    return signIn(email, password);
  }
  
  return data;
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });
  
  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

export async function getSession() {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
}

export async function checkUserExists(email: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('id')
    .eq('email', email)
    .single();
    
  if (error) {
    return false;
  }
  
  return !!data;
}

export async function resetPassword(email: string) {
  const userExists = await checkUserExists(email);
  
  if (!userExists) {
    throw new Error('EURO-SKY user does not exist');
  }

  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/auth/reset-password`,
  });
  
  if (error) throw error;
  
  return 'Reset instructions sent to EURO-SKY user';
}