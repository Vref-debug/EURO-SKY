import { supabase } from '../supabase';
import type { SignUpData } from '../types/auth';

export async function signUp({ email, password, firstName, lastName, phoneNumber, company }: SignUpData) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        first_name: firstName,
        last_name: lastName,
        phone_number: phoneNumber,
        company,
        mfa_enabled: true
      },
      emailRedirectTo: `${window.location.origin}/auth`
    }
  });
  
  if (error) throw error;
  return data;
}

// ... rest of the file remains the same