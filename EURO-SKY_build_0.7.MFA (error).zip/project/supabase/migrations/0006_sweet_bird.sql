/*
  # Remove MFA functionality
  
  1. Changes
    - Remove mfa_enabled column from profiles table
    - Update handle_new_user function to remove MFA references
*/

-- Remove mfa_enabled column if it exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'mfa_enabled'
  ) THEN
    ALTER TABLE profiles DROP COLUMN mfa_enabled;
  END IF;
END $$;

-- Update handle_new_user function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    email,
    first_name,
    last_name,
    phone_number,
    company
  )
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data->>'first_name', ''),
    COALESCE(new.raw_user_meta_data->>'last_name', ''),
    COALESCE(new.raw_user_meta_data->>'phone_number', ''),
    new.raw_user_meta_data->>'company'
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;