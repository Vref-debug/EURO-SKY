import { supabase } from '../supabase';

export class TOTPService {
  private static instance: TOTPService;

  private constructor() {}

  static getInstance(): TOTPService {
    if (!TOTPService.instance) {
      TOTPService.instance = new TOTPService();
    }
    return TOTPService.instance;
  }

  async enrollTOTP() {
    const { data, error } = await supabase.auth.mfa.enroll({
      factorType: 'totp',
      issuer: 'EURO-SKY',
      friendlyName: `EURO-SKY-${Date.now()}`
    });
    
    if (error) throw error;
    return data;
  }

  async verifyTOTP(factorId: string, code: string) {
    if (!factorId) throw new Error('Factor ID is required');
    
    const { data, error } = await supabase.auth.mfa.verify({
      factorId,
      code,
      challengeId: factorId // Required for first-time verification
    });
    
    if (error) throw error;
    return data;
  }

  async unenrollTOTP(factorId: string) {
    if (!factorId) throw new Error('Factor ID is required');
    
    const { data, error } = await supabase.auth.mfa.unenroll({
      factorId
    });
    
    if (error) throw error;
    return data;
  }
}