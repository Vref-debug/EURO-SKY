import { supabase } from '../../supabase';
import { TOTP_ERRORS } from './errors';
import type { TOTPEnrollResponse } from './types';

export class TOTPService {
  private static instance: TOTPService;
  private readonly issuer = 'EURO-SKY';
  private enrollmentInProgress = false;
  private retryAttempts = 0;
  private maxRetries = 3;
  private retryDelay = 2000;
  private cooldownPeriod = 30000; // 30 seconds
  private lastAttemptTime = 0;

  private constructor() {}

  static getInstance(): TOTPService {
    if (!TOTPService.instance) {
      TOTPService.instance = new TOTPService();
    }
    return TOTPService.instance;
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private async checkCooldown(): Promise<void> {
    const now = Date.now();
    const timeSinceLastAttempt = now - this.lastAttemptTime;
    
    if (timeSinceLastAttempt < this.cooldownPeriod) {
      const remainingTime = Math.ceil((this.cooldownPeriod - timeSinceLastAttempt) / 1000);
      throw new Error(`Please wait ${remainingTime} seconds before trying again`);
    }
  }

  private async cleanupExistingFactors(): Promise<void> {
    try {
      const { data: { factors } } = await supabase.auth.mfa.listFactors();
      
      if (factors?.totp?.length > 0) {
        for (const factor of factors.totp) {
          if (!factor.verified) {
            await supabase.auth.mfa.unenroll({ factorId: factor.id });
            await this.delay(1000);
          }
        }
        await this.delay(2000);
      }
    } catch (error) {
      console.warn('Cleanup warning:', error);
    }
  }

  async enrollTOTP(): Promise<TOTPEnrollResponse> {
    try {
      await this.checkCooldown();
      
      if (this.enrollmentInProgress) {
        throw new Error(TOTP_ERRORS.SETUP_IN_PROGRESS);
      }

      this.enrollmentInProgress = true;
      this.lastAttemptTime = Date.now();
      this.retryAttempts = 0;

      await this.cleanupExistingFactors();

      while (this.retryAttempts < this.maxRetries) {
        try {
          const uniqueId = `EURO-SKY-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
          
          const { data, error } = await supabase.auth.mfa.enroll({
            factorType: 'totp',
            issuer: this.issuer,
            friendlyName: uniqueId
          });

          if (error) {
            if (error.message.includes('too_many_enrolled')) {
              await this.cleanupExistingFactors();
              throw new Error(TOTP_ERRORS.ALREADY_ENROLLED);
            }
            throw error;
          }

          if (!data?.totp) throw new Error(TOTP_ERRORS.INVALID_RESPONSE);

          // Log successful attempt
          await supabase.from('mfa_setup_attempts').insert({
            success: true
          });

          return {
            id: data.totp.id,
            qrCode: data.totp.qr_code,
            secret: data.totp.secret
          };
        } catch (error: any) {
          this.retryAttempts++;
          
          // Log failed attempt
          await supabase.from('mfa_setup_attempts').insert({
            success: false,
            error_message: error.message
          });
          
          if (this.retryAttempts >= this.maxRetries) {
            throw new Error(TOTP_ERRORS.SETUP_FAILED);
          }
          
          await this.delay(this.retryDelay * this.retryAttempts);
          await this.cleanupExistingFactors();
        }
      }

      throw new Error(TOTP_ERRORS.SETUP_FAILED);
    } finally {
      this.enrollmentInProgress = false;
    }
  }

  async verifyTOTP(factorId: string, code: string): Promise<boolean> {
    if (!code) throw new Error(TOTP_ERRORS.INVALID_CODE);
    if (!factorId) throw new Error(TOTP_ERRORS.MISSING_FACTOR);

    try {
      const { data, error } = await supabase.auth.mfa.verify({
        factorId,
        code,
        challengeId: factorId
      });

      if (error) throw error;
      return !!data;
    } catch (error: any) {
      console.error('TOTP verification error:', error);
      throw new Error(TOTP_ERRORS.INVALID_CODE);
    }
  }
}