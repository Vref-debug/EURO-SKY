import { supabase } from '../supabase';
import type { SignUpCredentials } from './types';

export async function signUpWithSupabase(credentials: SignUpCredentials) {
  // Ensure we're sending the exact structure Supabase expects
  const { data, error } = await supabase.auth.signUp({
    email: credentials.email.trim(),
    password: credentials.password,
    options: {
      emailRedirectTo: `${window.location.origin}/auth`,
      data: {
        firstName: credentials.firstName,
        lastName: credentials.lastName,
        phoneNumber: credentials.phoneNumber,
        company: credentials.company || null
      }
    }
  });

  if (error) {
    console.error('Supabase signup error:', error);
    throw error;
  }

  return data;
}