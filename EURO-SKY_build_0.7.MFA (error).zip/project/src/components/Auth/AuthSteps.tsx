import React, { useState } from 'react';
import { AuthForm } from './AuthForm';
import { TOTPSetup } from './TOTPSetup';
import { RoleSelection } from './RoleSelection';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';

interface AuthStepsProps {
  onComplete: () => void;
}

export function AuthSteps({ onComplete }: AuthStepsProps) {
  const [step, setStep] = useState<'auth' | 'role' | 'totp'>('auth');
  const { user } = useAuth();

  const handleAuthComplete = () => {
    setStep('role');
  };

  const handleRoleSelect = async (role: string) => {
    if (user) {
      await supabase
        .from('profiles')
        .update({ role })
        .eq('id', user.id);
    }
    setStep('totp');
  };

  const handleTOTPComplete = () => {
    onComplete();
  };

  switch (step) {
    case 'role':
      return <RoleSelection onSelect={handleRoleSelect} onComplete={() => setStep('totp')} />;
    case 'totp':
      return <TOTPSetup onComplete={handleTOTPComplete} />;
    default:
      return <AuthForm onComplete={handleAuthComplete} />;
  }
}