import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { MFA_STATUS } from '../lib/auth/totp/constants';

export function useMFAStatus(userId?: string) {
  const [status, setStatus] = useState<string>(MFA_STATUS.PENDING);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) return;

    async function checkMFAStatus() {
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('mfa_status, mfa_verified')
          .eq('id', userId)
          .single();

        if (error) throw error;
        setStatus(data.mfa_status);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    checkMFAStatus();
  }, [userId]);

  const updateMFAStatus = async (newStatus: string) => {
    if (!userId) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ mfa_status: newStatus })
        .eq('id', userId);

      if (error) throw error;
      setStatus(newStatus);
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  };

  return { status, loading, error, updateMFAStatus };
}