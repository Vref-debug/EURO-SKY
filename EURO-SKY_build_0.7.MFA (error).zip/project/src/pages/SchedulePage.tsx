import React from 'react';
import { Layout } from '../components/Layout';
import { ScheduleForm } from '../components/Schedule/ScheduleForm';
import { MaintenanceHistory } from '../components/Schedule/MaintenanceHistory';

export function SchedulePage() {
  return (
    <Layout>
      <div className="py-12 bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-8">Schedule Maintenance</h1>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <ScheduleForm />
            <MaintenanceHistory />
          </div>
        </div>
      </div>
    </Layout>
  );
}