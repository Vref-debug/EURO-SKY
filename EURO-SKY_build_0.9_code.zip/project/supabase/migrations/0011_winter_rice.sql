/*
  # Fix MFA Setup Issues

  1. Changes
    - Add MFA attempt tracking
    - Add cooldown period for MFA setup attempts
    - Add cleanup trigger for stale MFA factors
  
  2. Security
    - Enable RLS on new tables
    - Add policies for authenticated users
*/

-- Track MFA setup attempts
CREATE TABLE IF NOT EXISTS mfa_setup_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  attempted_at timestamptz DEFAULT now(),
  success boolean DEFAULT false,
  error_message text
);

-- Enable RLS
ALTER TABLE mfa_setup_attempts ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Users can read own MFA attempts"
  ON mfa_setup_attempts
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to clean up stale MFA factors
CREATE OR REPLACE FUNCTION cleanup_stale_mfa_factors()
RETURNS void AS $$
DECLARE
  factor record;
BEGIN
  -- Get list of factors from auth.mfa_factors
  FOR factor IN 
    SELECT id 
    FROM auth.mfa_factors 
    WHERE updated_at < now() - interval '1 hour'
    AND NOT verified
  LOOP
    -- Attempt to unenroll the factor
    BEGIN
      PERFORM auth.mfa_unenroll(factor.id);
    EXCEPTION WHEN OTHERS THEN
      -- Log error but continue with next factor
      NULL;
    END;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger to automatically clean up stale factors
CREATE OR REPLACE FUNCTION trigger_cleanup_stale_factors()
RETURNS trigger AS $$
BEGIN
  PERFORM cleanup_stale_mfa_factors();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER cleanup_stale_factors_trigger
  AFTER INSERT ON mfa_setup_attempts
  FOR EACH STATEMENT
  EXECUTE FUNCTION trigger_cleanup_stale_factors();

-- Add function to check cooldown period
CREATE OR REPLACE FUNCTION check_mfa_cooldown(user_id uuid)
RETURNS boolean AS $$
DECLARE
  last_attempt timestamptz;
BEGIN
  SELECT MAX(attempted_at)
  INTO last_attempt
  FROM mfa_setup_attempts
  WHERE mfa_setup_attempts.user_id = $1;

  RETURN (
    last_attempt IS NULL OR 
    (now() - last_attempt) > interval '30 seconds'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;