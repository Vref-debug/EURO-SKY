/*
  # Role Management Updates

  1. Changes
    - Add role validation check
    - Add trigger to verify role exists before assignment
    - Add role-based dashboard redirection settings

  2. Security
    - Ensure roles can only be set to valid values
    - Prevent unauthorized role changes
*/

-- Create function to validate roles
CREATE OR REPLACE FUNCTION validate_user_role()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM user_roles WHERE role = NEW.role
  ) THEN
    RAISE EXCEPTION 'Invalid role: %', NEW.role;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for role validation
DROP TRIGGER IF EXISTS validate_role_trigger ON profiles;
CREATE TRIGGER validate_role_trigger
  BEFORE INSERT OR UPDATE OF role ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION validate_user_role();

-- Add dashboard routes for each role
CREATE TABLE IF NOT EXISTS role_dashboards (
  role text PRIMARY KEY REFERENCES user_roles(role),
  dashboard_path text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE role_dashboards ENABLE ROW LEVEL SECURITY;

-- Allow read access to authenticated users
CREATE POLICY "Allow authenticated read access"
  ON role_dashboards
  FOR SELECT
  TO authenticated
  USING (true);

-- Insert dashboard routes
INSERT INTO role_dashboards (role, dashboard_path)
VALUES 
  ('pilot', '/pilot-dashboard'),
  ('instructor', '/instructor-dashboard'),
  ('mechanic', '/mechanic-dashboard'),
  ('inspector', '/inspector-dashboard'),
  ('manager', '/manager-dashboard'),
  ('scheduler', '/scheduler-dashboard'),
  ('student', '/student-dashboard'),
  ('owner', '/owner-dashboard'),
  ('admin', '/admin-dashboard')
ON CONFLICT (role) 
DO UPDATE SET dashboard_path = EXCLUDED.dashboard_path;