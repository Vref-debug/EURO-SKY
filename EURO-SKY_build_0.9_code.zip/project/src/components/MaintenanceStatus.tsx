import React from 'react';
import { Clock, AlertCircle } from 'lucide-react';
import type { Aircraft } from '../types';

const mockAircraft: Aircraft = {
  id: '1',
  registration: 'OO-ABC',
  model: 'Cessna 172S',
  serialNumber: '172S12345',
  yearOfManufacture: 2018,
  totalFlightHours: 1250.5,
  engineHours: 1250.5,
  lastMaintenanceDate: '2024-02-15',
  nextMaintenanceDate: '2024-05-15',
  owner: 'Flight School Demo',
  type: 'school'
};

export function MaintenanceStatus() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-semibold">Aircraft Status</h3>
        <span className="text-sm text-gray-500">Last updated: Today</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-sm text-gray-500">Registration</label>
            <p className="text-lg font-semibold">{mockAircraft.registration}</p>
          </div>
          <div>
            <label className="text-sm text-gray-500">Model</label>
            <p className="text-lg">{mockAircraft.model}</p>
          </div>
          <div>
            <label className="text-sm text-gray-500">Total Flight Hours</label>
            <p className="text-lg">{mockAircraft.totalFlightHours.toFixed(1)}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Clock className="text-sky-600" />
            <div>
              <label className="text-sm text-gray-500">Next Maintenance Due</label>
              <p className="text-lg">{mockAircraft.nextMaintenanceDate}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <AlertCircle className="text-yellow-500" />
            <div>
              <label className="text-sm text-gray-500">Hours Until Service</label>
              <p className="text-lg">48.5 hours</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <button className="bg-sky-600 text-white px-4 py-2 rounded hover:bg-sky-700">
          Log New Flight Hours
        </button>
      </div>
    </div>
  );
}