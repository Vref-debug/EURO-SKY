import React from 'react';
import { Plane } from 'lucide-react';

interface AircraftInfoProps {
  registration: string;
  type: string;
}

export function AircraftInfo({ registration, type }: AircraftInfoProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Aircraft Details</h3>
        <Plane className="w-6 h-6 text-sky-600" />
      </div>
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Registration</span>
          <span className="font-semibold text-sky-700">{registration}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-600">Type</span>
          <span className="font-semibold">{type}</span>
        </div>
      </div>
    </div>
  );
}