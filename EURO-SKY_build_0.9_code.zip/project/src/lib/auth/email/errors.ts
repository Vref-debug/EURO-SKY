export const EMAIL_ERRORS = {
  INVALID_EMAIL: 'Please enter a valid email address',
  SEND_FAILED: 'Failed to send verification code. Please try again.',
  INVALID_CODE: 'Invalid verification code. Please try again.',
  CODE_EXPIRED: 'Verification code has expired. Please request a new one.',
  TOO_MANY_REQUESTS: 'Too many attempts. Please try again in a minute.',
  VERIFICATION_FAILED: 'Verification failed. Please try again.',
  NETWORK_ERROR: 'Network error. Please check your connection.',
  SESSION_EXPIRED: 'Your session has expired. Please log in again.',
  ALREADY_VERIFIED: 'Email already verified.',
  INVALID_SESSION: 'Invalid session. Please log in again.'
} as const;