export const EMAIL_CONSTANTS = {
  COOLDOWN_PERIOD: 60, // seconds
  MAX_RETRIES: 3,
  RETRY_DELAY: 2000, // milliseconds
  CODE_LENGTH: 6,
  RATE_LIMIT_PERIOD: 300 // 5 minutes
} as const;

export const EMAIL_MESSAGES = {
  RATE_LIMIT: 'Too many attempts. Please try again in 5 minutes',
  COOLDOWN: 'Please wait before requesting another code',
  INVALID_CODE: 'Invalid verification code',
  CODE_EXPIRED: 'Code has expired. Please request a new one',
  VERIFICATION_SUCCESS: 'Email verified successfully',
  VERIFICATION_FAILED: 'Verification failed. Please try again'
} as const;