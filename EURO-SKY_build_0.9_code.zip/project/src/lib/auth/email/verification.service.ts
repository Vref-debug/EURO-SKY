import { supabase } from '../../supabase';
import { EMAIL_CONSTANTS, EMAIL_MESSAGES } from './constants';

export class EmailVerificationService {
  private static instance: EmailVerificationService;
  private lastAttemptTime = 0;
  private rateLimitedUntil = 0;
  private attempts = 0;

  private constructor() {}

  static getInstance(): EmailVerificationService {
    if (!EmailVerificationService.instance) {
      EmailVerificationService.instance = new EmailVerificationService();
    }
    return EmailVerificationService.instance;
  }

  private isRateLimited(): boolean {
    return Date.now() < this.rateLimitedUntil;
  }

  private getRateLimitRemaining(): number {
    return Math.ceil((this.rateLimitedUntil - Date.now()) / 1000);
  }

  private canSendCode(): boolean {
    if (this.isRateLimited()) return false;
    
    const now = Date.now();
    const timeSinceLastAttempt = (now - this.lastAttemptTime) / 1000;
    return timeSinceLastAttempt >= EMAIL_CONSTANTS.COOLDOWN_PERIOD;
  }

  private getRemainingCooldown(): number {
    const now = Date.now();
    const timeSinceLastAttempt = (now - this.lastAttemptTime) / 1000;
    return Math.ceil(EMAIL_CONSTANTS.COOLDOWN_PERIOD - timeSinceLastAttempt);
  }

  private handleRateLimit() {
    this.rateLimitedUntil = Date.now() + (EMAIL_CONSTANTS.RATE_LIMIT_PERIOD * 1000);
    this.attempts = 0;
  }

  async sendVerificationCode(email: string): Promise<{ success: boolean; message?: string }> {
    try {
      if (this.isRateLimited()) {
        return {
          success: false,
          message: `${EMAIL_MESSAGES.RATE_LIMIT} (${this.getRateLimitRemaining()}s remaining)`
        };
      }

      if (!this.canSendCode()) {
        return {
          success: false,
          message: `${EMAIL_MESSAGES.COOLDOWN} (${this.getRemainingCooldown()}s)`
        };
      }

      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          shouldCreateUser: false
        }
      });

      if (error) {
        if (error.message.includes('rate limit')) {
          this.handleRateLimit();
          return { 
            success: false, 
            message: EMAIL_MESSAGES.RATE_LIMIT 
          };
        }
        throw error;
      }

      this.lastAttemptTime = Date.now();
      this.attempts++;
      
      if (this.attempts >= EMAIL_CONSTANTS.MAX_RETRIES) {
        this.handleRateLimit();
      }

      return { success: true };
    } catch (error) {
      console.error('Send verification code error:', error);
      return { success: false, message: error.message };
    }
  }

  async verifyCode(email: string, code: string): Promise<{ success: boolean; message?: string }> {
    try {
      if (this.isRateLimited()) {
        return {
          success: false,
          message: `${EMAIL_MESSAGES.RATE_LIMIT} (${this.getRateLimitRemaining()}s remaining)`
        };
      }

      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: code,
        type: 'email'
      });

      if (error) {
        if (error.message.includes('rate limit')) {
          this.handleRateLimit();
          return { 
            success: false, 
            message: EMAIL_MESSAGES.RATE_LIMIT 
          };
        }
        if (error.message.includes('expired')) {
          return { success: false, message: EMAIL_MESSAGES.CODE_EXPIRED };
        }
        return { success: false, message: EMAIL_MESSAGES.INVALID_CODE };
      }

      if (!data.user) {
        return { success: false, message: EMAIL_MESSAGES.VERIFICATION_FAILED };
      }

      // Reset attempts on successful verification
      this.attempts = 0;
      this.rateLimitedUntil = 0;

      return { success: true, message: EMAIL_MESSAGES.VERIFICATION_SUCCESS };
    } catch (error) {
      console.error('Verify code error:', error);
      return { success: false, message: error.message };
    }
  }
}