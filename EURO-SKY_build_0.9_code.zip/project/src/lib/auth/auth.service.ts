import { SupabaseService } from './supabase.service';
import type { SignUpCredentials, SignInCredentials } from './types';

export class AuthService {
  private static instance: AuthService;
  private supabaseService: SupabaseService;

  private constructor() {
    this.supabaseService = SupabaseService.getInstance();
  }

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  async signUp(credentials: SignUpCredentials) {
    return this.supabaseService.signUp(credentials);
  }

  async signIn(credentials: SignInCredentials) {
    return this.supabaseService.signIn(credentials);
  }

  async signOut() {
    return this.supabaseService.signOut();
  }

  async getSession() {
    return this.supabaseService.getSession();
  }
}