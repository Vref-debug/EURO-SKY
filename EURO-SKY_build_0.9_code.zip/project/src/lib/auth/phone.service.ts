import { supabase } from '../supabase';
import { PHONE_ERRORS } from './phone/errors';

export class PhoneAuthService {
  private static instance: PhoneAuthService;
  private cooldownPeriod = 60000; // 1 minute
  private lastAttemptTime = 0;

  private constructor() {}

  static getInstance(): PhoneAuthService {
    if (!PhoneAuthService.instance) {
      PhoneAuthService.instance = new PhoneAuthService();
    }
    return PhoneAuthService.instance;
  }

  private async checkCooldown(): Promise<void> {
    const now = Date.now();
    const timeSinceLastAttempt = now - this.lastAttemptTime;
    
    if (timeSinceLastAttempt < this.cooldownPeriod) {
      const remainingTime = Math.ceil((this.cooldownPeriod - timeSinceLastAttempt) / 1000);
      throw new Error(`Please wait ${remainingTime} seconds before requesting another code`);
    }
  }

  async sendVerificationCode(phoneNumber: string): Promise<void> {
    try {
      await this.checkCooldown();
      this.lastAttemptTime = Date.now();

      const { error } = await supabase.auth.signInWithOtp({
        phone: phoneNumber
      });

      if (error) {
        if (error.message.includes('rate limit')) {
          throw new Error(PHONE_ERRORS.TOO_MANY_REQUESTS);
        }
        throw new Error(PHONE_ERRORS.SEND_FAILED);
      }
    } catch (error: any) {
      console.error('Phone verification error:', error);
      throw error;
    }
  }

  async verifyCode(phoneNumber: string, code: string): Promise<boolean> {
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        phone: phoneNumber,
        token: code,
        type: 'sms'
      });

      if (error) {
        if (error.message.includes('Invalid')) {
          throw new Error(PHONE_ERRORS.INVALID_CODE);
        }
        throw error;
      }

      return !!data.user;
    } catch (error: any) {
      console.error('Code verification error:', error);
      throw error;
    }
  }
}