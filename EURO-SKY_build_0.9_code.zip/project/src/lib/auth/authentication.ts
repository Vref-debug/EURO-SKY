import { AuthService } from './auth.service';
import { validateSignUp } from './validation';
import type { SignUpCredentials } from './types';

export async function signUp(userData: SignUpCredentials) {
  const validationError = validateSignUp(userData);
  if (validationError) {
    throw new Error(validationError);
  }

  try {
    const authService = AuthService.getInstance();
    const user = await authService.signUp(userData);
    return user;
  } catch (error: any) {
    console.error('Signup error:', error);
    throw new Error(error.message || 'Failed to create account');
  }
}