export const TOTP_ERRORS = {
  SETUP_FAILED: 'Failed to setup 2FA. Please try again.',
  INVALID_CODE: 'Invalid verification code. Please try again.',
  MISSING_FACTOR: 'Setup incomplete. Please restart the setup process.',
  ALREADY_ENROLLED: 'You are already enrolled in 2FA. Please try again in a few moments.',
  NETWORK_ERROR: 'Network error occurred. Please check your connection and try again.',
  SERVER_ERROR: 'Server error occurred. Please try again in a few moments.',
  USER_NOT_FOUND: 'User not found. Please log in again.',
  INVALID_RESPONSE: 'Invalid response from server. Please try again.',
  TOO_MANY_ATTEMPTS: 'Too many attempts. Please wait a few moments and try again.',
  SETUP_IN_PROGRESS: 'Setup is already in progress. Please wait...'
} as const;