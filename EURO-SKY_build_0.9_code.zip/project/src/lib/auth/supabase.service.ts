import { supabase } from '../supabase';
import type { SignUpCredentials, SignInCredentials } from './types';
import { validateSignIn, validateSignUp } from './validation';

export class SupabaseService {
  private static instance: SupabaseService;

  private constructor() {}

  static getInstance(): SupabaseService {
    if (!SupabaseService.instance) {
      SupabaseService.instance = new SupabaseService();
    }
    return SupabaseService.instance;
  }

  async signUp(credentials: SignUpCredentials) {
    const validationError = validateSignUp(credentials);
    if (validationError) {
      throw new Error(validationError);
    }

    const { data, error } = await supabase.auth.signUp({
      email: credentials.email.trim(),
      password: credentials.password,
      options: {
        data: {
          first_name: credentials.firstName.trim(),
          last_name: credentials.lastName.trim(),
          phone_number: credentials.phoneNumber.trim(),
          company: credentials.company?.trim(),
          role: credentials.role
        },
        emailRedirectTo: `${window.location.origin}/auth`
      }
    });

    if (error) throw error;
    if (!data.user) throw new Error('Failed to create user');

    return { user: data.user, session: data.session };
  }

  async signIn(credentials: SignInCredentials) {
    const validationError = validateSignIn(credentials);
    if (validationError) {
      throw new Error(validationError);
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email: credentials.email.trim(),
      password: credentials.password
    });

    if (error) {
      if (error.message === 'Invalid login credentials') {
        throw new Error('Invalid email or password');
      }
      throw error;
    }
    
    return data;
  }

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }

  async getSession() {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) throw error;
    return session;
  }
}