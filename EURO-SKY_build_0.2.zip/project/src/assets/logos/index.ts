// Base64 encoded SVG logos for optimal loading and availability
export const logos = {
  textron: 'https://d21buns5ku92am.cloudfront.net/69280/images/374163-logo-textronaviation-2f9a4a-original-1608800893.png',
  piper: 'https://www.piper.com/wp-content/uploads/2019/01/piper-aircraft-logo-white.png',
  rotax: 'https://www.rotax.com/assets/rotax-logo-white.png'
};