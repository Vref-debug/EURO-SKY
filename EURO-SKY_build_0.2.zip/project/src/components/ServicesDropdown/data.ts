import { ServiceCategory } from './types';

export const serviceCategories: ServiceCategory[] = [
  {
    title: 'Inspections',
    items: [
      '50-Hour Inspection',
      '100-Hour Inspection',
      'Annual Inspection',
      'Pre-Purchase Inspection'
    ]
  },
  {
    title: 'Maintenance',
    items: [
      'Scheduled Maintenance',
      'Aircraft Repairs',
      'Engine Overhaul',
      'Avionics Services'
    ]
  },
  {
    title: 'Documentation',
    items: [
      'CAMO Services',
      'Maintenance Records',
      'Airworthiness Review'
    ]
  }
];