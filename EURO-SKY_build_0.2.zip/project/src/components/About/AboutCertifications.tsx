import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';

const certifications = [
  'EASA Part 145 Maintenance Organization',
  'CAMO (Continuing Airworthiness Management Organization)',
  'ISO 9001:2015 Certified'
];

export function AboutCertifications() {
  const { t } = useLanguage();
  
  return (
    <section>
      <h2 className="text-2xl font-semibold mb-4">{t('about.certifications.title')}</h2>
      <ul className="list-disc list-inside space-y-2 text-gray-700">
        {certifications.map((cert, index) => (
          <li key={index}>{cert}</li>
        ))}
      </ul>
    </section>
  );
}