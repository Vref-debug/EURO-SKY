import React from 'react';

interface LocationProps {
  name: string;
  address: string;
  city: string;
}

export function Location({ name, address, city }: LocationProps) {
  return (
    <div>
      <h3 className="font-semibold text-sky-800">{name}</h3>
      <p className="text-gray-700">{address}</p>
      <p className="text-gray-700">{city}</p>
    </div>
  );
}