/*
  # Add MFA Status Tracking
  
  1. Changes
    - Add mfa_status column to profiles table
    - Add mfa_verified column to profiles table
    - Add trigger to update mfa status
  
  2. Security
    - Maintain existing RLS policies
*/

-- Add MFA status columns
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS mfa_status text DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS mfa_verified boolean DEFAULT false;

-- Create enum type for MFA status if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type WHERE typname = 'mfa_status_type'
  ) THEN
    CREATE TYPE mfa_status_type AS ENUM ('pending', 'enrolled', 'disabled');
    
    -- Convert existing column to use enum
    ALTER TABLE profiles 
    ALTER COLUMN mfa_status TYPE mfa_status_type 
    USING mfa_status::mfa_status_type;
  END IF;
END $$;