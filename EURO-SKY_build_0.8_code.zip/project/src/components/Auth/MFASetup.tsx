import React, { useState } from 'react';
import { Shield } from 'lucide-react';
import { AuthService } from '../../lib/auth/auth.service';
import toast from 'react-hot-toast';

interface MFASetupProps {
  onComplete: () => void;
  mfaData: {
    qrCode: string;
    secret: string;
    factorId: string;
  };
}

export function MFASetup({ onComplete, mfaData }: MFASetupProps) {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const authService = AuthService.getInstance();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await authService.verifyMFA(code);
      toast.success('MFA setup complete');
      onComplete();
    } catch (err: any) {
      toast.error('Invalid verification code');
      setCode('');
    } finally {
      setLoading(false);
    }
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
    setCode(value);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="flex justify-center mb-6">
        <Shield className="w-12 h-12 text-sky-600" />
      </div>

      <h2 className="text-xl font-bold text-center mb-4">Set Up Two-Factor Authentication</h2>
      
      <div className="mb-6">
        <p className="text-sm text-gray-600 mb-4">
          1. Scan this QR code with your authenticator app (e.g., Google Authenticator, Authy)
        </p>
        <div className="flex justify-center mb-4">
          <div className="p-2 bg-white border border-gray-200 rounded">
            <img 
              src={mfaData.qrCode} 
              alt="MFA QR Code" 
              className="w-48 h-48"
            />
          </div>
        </div>
        <div className="text-sm text-gray-600 mb-4">
          <p className="font-medium mb-2">Manual Setup:</p>
          <p>If you can't scan the QR code, enter this code manually:</p>
          <code className="block bg-gray-50 p-2 rounded mt-1 text-center select-all font-mono">
            {mfaData.secret}
          </code>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            2. Enter the 6-digit code from your authenticator app
          </label>
          <input
            type="text"
            value={code}
            onChange={handleCodeChange}
            className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500 text-center text-2xl tracking-wider font-mono"
            placeholder="000000"
            required
            pattern="[0-9]{6}"
            maxLength={6}
            autoComplete="off"
          />
        </div>

        <button
          type="submit"
          disabled={loading || code.length !== 6}
          className="w-full bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
        >
          {loading ? 'Verifying...' : 'Complete Setup'}
        </button>
      </form>
    </div>
  );
}