import React, { useState } from 'react';
import { AuthForm } from './AuthForm';
import { EmailVerification } from './EmailVerification';
import { RoleSelection } from './RoleSelection';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';

interface AuthStepsProps {
  onComplete: () => void;
}

export function AuthSteps({ onComplete }: AuthStepsProps) {
  const [step, setStep] = useState<'auth' | 'role' | 'verify'>('auth');
  const { user } = useAuth();

  const handleAuthComplete = () => {
    setStep('role');
  };

  const handleRoleSelect = async (role: string) => {
    if (user) {
      await supabase
        .from('profiles')
        .update({ role })
        .eq('id', user.id);
    }
    setStep('verify');
  };

  const handleVerificationComplete = () => {
    onComplete();
  };

  switch (step) {
    case 'role':
      return <RoleSelection onSelect={handleRoleSelect} onComplete={() => setStep('verify')} />;
    case 'verify':
      return user ? (
        <EmailVerification 
          email={user.email} 
          onComplete={handleVerificationComplete} 
        />
      ) : null;
    default:
      return <AuthForm onComplete={handleAuthComplete} />;
  }
}