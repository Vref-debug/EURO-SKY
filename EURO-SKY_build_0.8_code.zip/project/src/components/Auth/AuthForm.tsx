import React, { useState } from 'react';
import { Mail, Shield } from 'lucide-react';
import { AuthService } from '../../lib/auth/auth.service';
import { validateSignIn } from '../../lib/auth/validation';
import toast from 'react-hot-toast';
import { SignUpForm } from './SignUpForm';

interface AuthFormProps {
  onComplete: () => void;
}

export function AuthForm({ onComplete }: AuthFormProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const authService = AuthService.getInstance();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const validationError = validateSignIn({ email, password });
      if (validationError) {
        toast.error(validationError);
        return;
      }

      const { session } = await authService.signIn({ email, password });
      if (session) {
        onComplete();
      }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSignUpComplete = () => {
    setIsSignUp(false);
    toast.success('Account created! Please check your email to confirm your account.');
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <div className="flex justify-center mb-6">
        <Shield className="w-12 h-12 text-sky-600" />
      </div>
      
      <h2 className="text-2xl font-bold text-center mb-6">
        {isSignUp ? 'Create Account' : 'Log In'}
      </h2>

      {isSignUp ? (
        <SignUpForm 
          onComplete={handleSignUpComplete}
          onCancel={() => setIsSignUp(false)} 
        />
      ) : (
        <>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
            >
              {loading ? 'Processing...' : 'Log In'}
            </button>
          </form>

          <div className="mt-4 text-center">
            <button
              onClick={() => setIsSignUp(true)}
              className="text-sky-600 hover:text-sky-700"
            >
              Need an account? Sign up
            </button>
          </div>
        </>
      )}
    </div>
  );
}