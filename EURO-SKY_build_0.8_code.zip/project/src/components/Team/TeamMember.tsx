import React from 'react';
import type { TeamMemberType } from './types';

export function TeamMember({ name, role, image, certifications }: TeamMemberType) {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <img 
        src={image} 
        alt={name} 
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900">{name}</h3>
        <p className="text-sky-600">{role}</p>
        {certifications && (
          <div className="mt-2">
            <p className="text-sm text-gray-600">Certifications:</p>
            <ul className="mt-1 text-sm text-gray-500">
              {certifications.map((cert, index) => (
                <li key={index}>{cert}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}