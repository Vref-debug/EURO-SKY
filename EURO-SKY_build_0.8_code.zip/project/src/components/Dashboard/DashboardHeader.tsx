import React from 'react';
import { User } from '../../lib/auth/types';

interface DashboardHeaderProps {
  user: User | null;
}

export function DashboardHeader({ user }: DashboardHeaderProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-2">
        Your EURO-SKY Dashboard
      </h1>
      <div className="flex items-center space-x-4">
        <div className="bg-sky-100 p-2 rounded-full">
          <span className="text-sky-700 font-semibold">
            {user?.firstName?.[0]}{user?.lastName?.[0]}
          </span>
        </div>
        <div>
          <p className="text-gray-600">
            Welcome back, {user?.firstName} {user?.lastName}
          </p>
          <p className="text-sm text-gray-500">{user?.email}</p>
        </div>
      </div>
    </div>
  );
}