import { useState, useCallback } from 'react';
import { TOTPService } from '../lib/auth/totp/totp.service';
import { TOTP_ERRORS } from '../lib/auth/totp/errors';
import type { TOTPState } from '../lib/auth/totp/types';

export function useTOTP() {
  const [state, setState] = useState<TOTPState>({
    factorId: null,
    qrCode: null,
    secret: null,
    error: null,
    loading: false
  });

  const totpService = TOTPService.getInstance();

  const setupTOTP = useCallback(async () => {
    if (state.loading) return;

    setState(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const { id, qrCode, secret } = await totpService.enrollTOTP();
      
      setState({
        factorId: id,
        qrCode,
        secret,
        error: null,
        loading: false
      });
    } catch (error: any) {
      console.error('TOTP setup error:', error);
      setState(prev => ({
        ...prev,
        error: { 
          message: error.message || TOTP_ERRORS.SETUP_FAILED
        },
        loading: false,
        factorId: null,
        qrCode: null,
        secret: null
      }));
    }
  }, [state.loading]);

  const verifyTOTP = useCallback(async (code: string): Promise<boolean> => {
    if (!state.factorId) {
      setState(prev => ({
        ...prev,
        error: { message: TOTP_ERRORS.MISSING_FACTOR }
      }));
      return false;
    }

    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const success = await totpService.verifyTOTP(state.factorId, code);
      setState(prev => ({ ...prev, loading: false, error: null }));
      return success;
    } catch (error: any) {
      setState(prev => ({
        ...prev,
        error: { message: error.message || TOTP_ERRORS.INVALID_CODE },
        loading: false
      }));
      return false;
    }
  }, [state.factorId]);

  const resetError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  return {
    ...state,
    setupTOTP,
    verifyTOTP,
    resetError
  };
}