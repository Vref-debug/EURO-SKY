import { useState, useEffect } from 'react';
import { AuthService } from '../lib/auth/auth.service';
import { supabase } from '../lib/supabase';
import type { User } from '../lib/auth/types';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const authService = AuthService.getInstance();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const session = await authService.getSession();
        if (session?.user) {
          setUser({
            id: session.user.id,
            email: session.user.email!,
            firstName: session.user.user_metadata.first_name,
            lastName: session.user.user_metadata.last_name,
            phoneNumber: session.user.user_metadata.phone_number,
            company: session.user.user_metadata.company
          });
        } else {
          setUser(null);
        }
      } catch (error) {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email!,
          firstName: session.user.user_metadata.first_name,
          lastName: session.user.user_metadata.last_name,
          phoneNumber: session.user.user_metadata.phone_number,
          company: session.user.user_metadata.company
        });
      } else {
        setUser(null);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return { user, loading };
}