export const PHONE_ERRORS = {
  INVALID_PHONE: 'Please enter a valid phone number',
  SEND_FAILED: 'Failed to send verification code. Please try again.',
  INVALID_CODE: 'Invalid verification code. Please try again.',
  TOO_MANY_REQUESTS: 'Too many attempts. Please try again later.',
  VERIFICATION_FAILED: 'Verification failed. Please try again.',
  NETWORK_ERROR: 'Network error. Please check your connection.',
} as const;