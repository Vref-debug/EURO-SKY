import { supabase } from '../supabase';
import { EMAIL_ERRORS } from './email/errors';

export class EmailVerificationService {
  private static instance: EmailVerificationService;
  private cooldownPeriod = 60000; // 1 minute
  private lastAttemptTime = 0;

  private constructor() {}

  static getInstance(): EmailVerificationService {
    if (!EmailVerificationService.instance) {
      EmailVerificationService.instance = new EmailVerificationService();
    }
    return EmailVerificationService.instance;
  }

  private async checkCooldown(): Promise<void> {
    const now = Date.now();
    const timeSinceLastAttempt = now - this.lastAttemptTime;
    
    if (timeSinceLastAttempt < this.cooldownPeriod) {
      const remainingTime = Math.ceil((this.cooldownPeriod - timeSinceLastAttempt) / 1000);
      throw new Error(`Please wait ${remainingTime} seconds before requesting another code`);
    }
  }

  async sendVerificationEmail(email: string): Promise<void> {
    try {
      await this.checkCooldown();
      this.lastAttemptTime = Date.now();

      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          shouldCreateUser: false,
          data: {
            verification_type: 'otp',
            code_length: 6,
            code_type: 'numeric'
          }
        }
      });

      if (error) {
        if (error.message.includes('rate limit')) {
          throw new Error(EMAIL_ERRORS.TOO_MANY_REQUESTS);
        }
        throw new Error(EMAIL_ERRORS.SEND_FAILED);
      }
    } catch (error: any) {
      console.error('Email verification error:', error);
      throw error;
    }
  }

  async verifyCode(email: string, code: string): Promise<boolean> {
    try {
      if (!/^\d{6}$/.test(code)) {
        throw new Error(EMAIL_ERRORS.INVALID_CODE);
      }

      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: code,
        type: 'email'
      });

      if (error) {
        if (error.message.includes('Invalid')) {
          throw new Error(EMAIL_ERRORS.INVALID_CODE);
        }
        throw error;
      }

      return !!data.user;
    } catch (error: any) {
      console.error('Code verification error:', error);
      throw error;
    }
  }
}