export const EMAIL_ERRORS = {
  INVALID_EMAIL: 'Please enter a valid email address',
  SEND_FAILED: 'Failed to send verification code. Please try again.',
  INVALID_CODE: 'Invalid verification code. Please try again.',
  TOO_MANY_REQUESTS: 'Too many attempts. Please try again later.',
  VERIFICATION_FAILED: 'Verification failed. Please try again.',
  NETWORK_ERROR: 'Network error. Please check your connection.',
} as const;