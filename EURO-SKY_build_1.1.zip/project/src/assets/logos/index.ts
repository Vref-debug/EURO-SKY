// Base64 encoded SVG logos for optimal loading and availability
export const logos = {
  textron: 'https://d21buns5ku92am.cloudfront.net/69280/images/374163-logo-textronaviation-2f9a4a-original-1608800893.png',
  piper: 'https://upload.wikimedia.org/wikipedia/commons/b/b0/Piper_Aircraft_logo.svg',
  rotax: 'https://lightaviation.co.nz/wp-content/uploads/2016/02/rotax-logo-980x300.jpg',
  hawker: ''
}