import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ProfileFieldProps {
  label: string;
  value: string;
  icon: LucideIcon;
  isRole?: boolean;
}

export function ProfileField({ label, value, icon: Icon, isRole }: ProfileFieldProps) {
  if (!value) return null;

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700">{label}</label>
      {isRole ? (
        <div className="mt-1 px-3 py-1 bg-sky-100 text-sky-800 rounded-full inline-block">
          {value}
        </div>
      ) : (
        <div className="mt-1 flex items-center space-x-2 text-gray-900">
          <Icon className="w-5 h-5 text-gray-400" />
          <span>{value}</span>
        </div>
      )}
    </div>
  );
}