import React from 'react';
import { User } from '../../lib/auth/types';
import { DashboardTitle } from './DashboardTitle';

interface DashboardHeaderProps {
  user: User | null;
}

export function DashboardHeader({ user }: DashboardHeaderProps) {
  const userName = user ? `${user.firstName} ${user.lastName}` : undefined;
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between">
        <DashboardTitle 
          role={user?.role}
          userName={userName}
        />
        <div className="flex items-center space-x-4">
          <div className="bg-sky-100 p-2 rounded-full">
            <span className="text-sky-700 font-semibold">
              {user?.firstName?.[0]}{user?.lastName?.[0]}
            </span>
          </div>
          <div>
            <p className="text-sm text-gray-500">{user?.email}</p>
          </div>
        </div>
      </div>
    </div>
  );
}