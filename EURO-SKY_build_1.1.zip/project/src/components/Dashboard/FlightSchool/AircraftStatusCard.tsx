import React from 'react';
import { Plane, Clock, AlertCircle, Calendar, TrendingUp } from 'lucide-react';
import type { AircraftStatus } from '../../../types/aircraft';

interface AircraftStatusCardProps {
  aircraft: AircraftStatus;
}

export function AircraftStatusCard({ aircraft }: AircraftStatusCardProps) {
  const getMaintenanceStatusColor = () => {
    if (aircraft.hoursUntilMaintenance <= 10) return 'text-red-500';
    if (aircraft.hoursUntilMaintenance <= 25) return 'text-yellow-500';
    return 'text-green-500';
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Plane className="w-6 h-6 text-sky-600" />
          <h3 className="text-xl font-semibold">{aircraft.registration}</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Calendar className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-600">{aircraft.lastUpdated}</span>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <span className="px-3 py-1 rounded-full text-sm font-medium bg-sky-100 text-sky-800">
          {aircraft.type}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <p className="text-sm text-gray-600">Total Hours</p>
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-gray-400" />
            <span className="text-lg font-semibold">{aircraft.totalHours.toFixed(1)}</span>
          </div>
        </div>
        <div>
          <p className="text-sm text-gray-600">Average Monthly Hours</p>
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-sky-600" />
            <span className="text-lg font-semibold">{aircraft.averageMonthlyHours.toFixed(1)}</span>
          </div>
        </div>
      </div>

      <div className="border-t pt-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Est. Next Maintenance</p>
            <p className="font-medium">{aircraft.estimatedNextMaintenanceDate}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Hours Remaining</p>
            <div className="flex items-center space-x-1">
              <AlertCircle className={`w-4 h-4 ${getMaintenanceStatusColor()}`} />
              <span className={`font-medium ${getMaintenanceStatusColor()}`}>
                {aircraft.hoursUntilMaintenance} hours
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}