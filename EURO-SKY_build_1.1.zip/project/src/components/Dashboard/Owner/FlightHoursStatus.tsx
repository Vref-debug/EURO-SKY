import React from 'react';
import { Clock } from 'lucide-react';

interface FlightHoursStatusProps {
  totalFlightHours: number;
  engineHours: number;
  lastUpdated: string;
}

export function FlightHoursStatus({ totalFlightHours, engineHours, lastUpdated }: FlightHoursStatusProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Flight Hours</h2>
        <Clock className="w-6 h-6 text-sky-600" />
      </div>
      <div className="space-y-4">
        <div>
          <p className="text-sm text-gray-600">Total Flight Hours</p>
          <p className="text-2xl font-bold">{totalFlightHours.toFixed(1)}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Engine Hours</p>
          <p className="text-2xl font-bold">{engineHours.toFixed(1)}</p>
        </div>
        <div className="pt-2 border-t">
          <p className="text-sm text-gray-500">Last Updated: {lastUpdated}</p>
        </div>
      </div>
    </div>
  );
}