import React from 'react';
import { Wrench, AlertCircle, CheckCircle } from 'lucide-react';

interface MaintenanceStatusProps {
  lastMaintenanceDate: string;
  nextMaintenanceDate: string;
  status: 'ok' | 'warning' | 'due';
  hoursRemaining: number;
}

export function MaintenanceStatus({ 
  lastMaintenanceDate, 
  nextMaintenanceDate, 
  status, 
  hoursRemaining 
}: MaintenanceStatusProps) {
  const getStatusColor = () => {
    switch (status) {
      case 'ok': return 'text-green-500';
      case 'warning': return 'text-yellow-500';
      case 'due': return 'text-red-500';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'ok': return <CheckCircle className={`w-6 h-6 ${getStatusColor()}`} />;
      case 'warning': return <AlertCircle className={`w-6 h-6 ${getStatusColor()}`} />;
      case 'due': return <Wrench className={`w-6 h-6 ${getStatusColor()}`} />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Maintenance Status</h2>
        {getStatusIcon()}
      </div>
      <div className="space-y-4">
        <div>
          <p className="text-sm text-gray-600">Last Maintenance</p>
          <p className="text-lg font-semibold">{lastMaintenanceDate}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Next Due</p>
          <p className="text-lg font-semibold">{nextMaintenanceDate}</p>
        </div>
        <div className="pt-2 border-t">
          <p className="text-sm text-gray-600">Hours Until Next Service</p>
          <p className={`text-lg font-bold ${getStatusColor()}`}>
            {hoursRemaining} hours
          </p>
        </div>
      </div>
    </div>
  );
}