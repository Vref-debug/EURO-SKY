import React from 'react';
import { formatRole } from '../../utils/textUtils';

interface DashboardTitleProps {
  role?: string;
  userName?: string;
}

export function DashboardTitle({ role, userName }: DashboardTitleProps) {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-2">
        {role ? `${formatRole(role)} Dashboard` : 'Dashboard'}
      </h1>
      {userName && (
        <p className="text-gray-600">
          Welcome back, {userName}
        </p>
      )}
    </div>
  );
}