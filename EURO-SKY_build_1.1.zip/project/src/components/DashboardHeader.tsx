import React from 'react';
import { Link } from 'react-router-dom';
import { Home, UserCircle, LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { DummyAuthService } from '../lib/auth/dummyAuth.service';
import { formatRole } from '../utils/textUtils';

export function DashboardHeader() {
  const { user } = useAuth();
  const authService = DummyAuthService.getInstance();

  const handleSignOut = async () => {
    try {
      await authService.signOut();
      localStorage.removeItem('dummyUser');
      window.location.href = '/auth';
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <header className="bg-sky-900 text-white">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link to="/" className="hover:text-sky-200 transition-colors">
              <Home className="w-6 h-6" />
            </Link>
            {user?.role && (
              <span className="text-sky-200 font-medium">
                {formatRole(user.role)} Dashboard
              </span>
            )}
          </div>

          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-3">
              <UserCircle className="w-8 h-8" />
              <div className="text-sm">
                <div className="font-medium">{user?.firstName} {user?.lastName}</div>
                <div className="text-sky-200">{user?.email}</div>
              </div>
            </div>
            <button
              onClick={handleSignOut}
              className="hover:text-sky-200 transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}