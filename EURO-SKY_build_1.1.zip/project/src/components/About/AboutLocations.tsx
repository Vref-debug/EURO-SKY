import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { Location } from './Location';

export function AboutLocations() {
  const { t } = useLanguage();
  
  return (
    <section>
      <h2 className="text-2xl font-semibold mb-4">{t('about.locations.title')}</h2>
      <div className="space-y-4">
        <Location 
          name="Grimbergen (EBGB)"
          address="Humbeeksesteenweg 313"
          city="1850 Grimbergen, Belgium"
        />
        <Location 
          name="Temploux (EBNM)"
          address="Route de Hannut 40"
          city="5020 Temploux, Belgium"
        />
      </div>
    </section>
  );
}