import React, { useState } from 'react';
import { Shield } from 'lucide-react';
import { AuthService } from '../../lib/auth/auth.service';
import toast from 'react-hot-toast';

interface TOTPVerificationProps {
  onComplete: () => void;
}

export function TOTPVerification({ onComplete }: TOTPVerificationProps) {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const authService = AuthService.getInstance();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const success = await authService.verifyTOTP(code);
      if (success) {
        toast.success('Authentication successful');
        onComplete();
      } else {
        toast.error('Invalid verification code');
        setCode('');
      }
    } catch (error: any) {
      toast.error(error.message || 'Verification failed');
      setCode('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <div className="flex justify-center mb-6">
        <Shield className="w-12 h-12 text-sky-600" />
      </div>

      <h2 className="text-xl font-bold text-center mb-4">Two-Factor Authentication</h2>
      <p className="text-sm text-gray-600 text-center mb-6">
        Enter the 6-digit code from your authenticator app
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <input
            type="text"
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
            className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500 text-center text-2xl tracking-wider font-mono"
            placeholder="000000"
            maxLength={6}
            required
            disabled={loading}
          />
        </div>

        <button
          type="submit"
          disabled={loading || code.length !== 6}
          className="w-full bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
        >
          {loading ? 'Verifying...' : 'Verify'}
        </button>
      </form>
    </div>
  );
}