import React, { useState } from 'react';
import { Shield, Phone } from 'lucide-react';
import { PhoneAuthService } from '../../lib/auth/phone.service';
import toast from 'react-hot-toast';

interface PhoneVerificationProps {
  phoneNumber: string;
  onComplete: () => void;
}

export function PhoneVerification({ phoneNumber, onComplete }: PhoneVerificationProps) {
  const [verificationCode, setVerificationCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [codeSent, setCodeSent] = useState(false);
  const phoneService = PhoneAuthService.getInstance();

  const handleSendCode = async () => {
    setLoading(true);
    try {
      await phoneService.sendVerificationCode(phoneNumber);
      setCodeSent(true);
      toast.success('Verification code sent to your phone');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const success = await phoneService.verifyCode(phoneNumber, verificationCode);
      if (success) {
        toast.success('Phone number verified successfully');
        onComplete();
      }
    } catch (error: any) {
      toast.error(error.message);
      setVerificationCode('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto">
      <div className="text-center mb-6">
        <Shield className="w-12 h-12 text-sky-600 mx-auto mb-4" />
        <h2 className="text-xl font-bold">Phone Verification</h2>
      </div>

      <div className="space-y-6">
        <div className="flex items-center space-x-2 bg-gray-50 p-3 rounded">
          <Phone className="w-5 h-5 text-gray-500" />
          <span className="text-gray-700">{phoneNumber}</span>
        </div>

        {!codeSent ? (
          <button
            onClick={handleSendCode}
            disabled={loading}
            className="w-full bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
          >
            {loading ? 'Sending...' : 'Send Verification Code'}
          </button>
        ) : (
          <form onSubmit={handleVerify} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Enter the verification code sent to your phone
              </label>
              <input
                type="text"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500 text-center text-2xl tracking-wider font-mono"
                placeholder="000000"
                maxLength={6}
                required
              />
            </div>

            <div className="flex space-x-4">
              <button
                type="submit"
                disabled={loading || verificationCode.length !== 6}
                className="flex-1 bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
              >
                {loading ? 'Verifying...' : 'Verify Code'}
              </button>
              <button
                type="button"
                onClick={handleSendCode}
                disabled={loading}
                className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded hover:bg-gray-200 disabled:opacity-50"
              >
                Resend Code
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}