import React from 'react';
import { FileText } from 'lucide-react';
import type { WorkOrder } from '../../types/workOrder';

interface WorkOrderSelectionProps {
  workOrders: WorkOrder[];
  selectedWorkOrder: string;
  onSelect: (workOrderId: string) => void;
}

export function WorkOrderSelection({
  workOrders,
  selectedWorkOrder,
  onSelect
}: WorkOrderSelectionProps) {
  const pendingWorkOrders = workOrders.filter(wo => 
    wo.status !== 'completed' && 
    wo.tasks.some(t => t.status === 'pending')
  );

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold">Select Work Order</h2>
        <FileText className="w-5 h-5 text-gray-400" />
      </div>

      <div className="space-y-4">
        {pendingWorkOrders.map((workOrder) => (
          <button
            key={workOrder.id}
            onClick={() => onSelect(workOrder.id)}
            className={`w-full text-left p-4 rounded-lg border ${
              selectedWorkOrder === workOrder.id
                ? 'border-sky-500 bg-sky-50'
                : 'border-gray-200 hover:bg-gray-50'
            }`}
          >
            <div className="flex justify-between items-start">
              <div>
                <p className="font-medium">{workOrder.id}</p>
                <p className="text-sm text-gray-600">{workOrder.description}</p>
                <p className="text-sm text-gray-500 mt-1">
                  Aircraft: {workOrder.aircraftRegistration}
                </p>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                workOrder.priority === 'high'
                  ? 'bg-red-100 text-red-800'
                  : workOrder.priority === 'medium'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-green-100 text-green-800'
              }`}>
                {workOrder.priority}
              </span>
            </div>
          </button>
        ))}

        {pendingWorkOrders.length === 0 && (
          <p className="text-center text-gray-500 py-4">
            No pending work orders available
          </p>
        )}
      </div>
    </div>
  );
}