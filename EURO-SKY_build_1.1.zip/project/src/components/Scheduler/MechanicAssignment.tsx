import React from 'react';
import { User, Wrench } from 'lucide-react';
import type { Mechanic } from '../../types/scheduler';

interface MechanicAssignmentProps {
  mechanics: Mechanic[];
  selectedDate: string;
  selectedTime: string;
  onAssign: (mechanicId: string) => void;
}

export function MechanicAssignment({ 
  mechanics, 
  selectedDate, 
  selectedTime,
  onAssign 
}: MechanicAssignmentProps) {
  const availableMechanics = mechanics.filter(mechanic =>
    mechanic.availability.some(slot =>
      slot.date === selectedDate &&
      slot.startTime === selectedTime &&
      slot.available
    )
  );

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold">Available Mechanics</h2>
        <Wrench className="w-5 h-5 text-gray-400" />
      </div>

      <div className="space-y-4">
        {availableMechanics.map((mechanic) => (
          <button
            key={mechanic.id}
            onClick={() => onAssign(mechanic.id)}
            className="w-full flex items-center justify-between p-4 rounded-lg border border-gray-200 hover:bg-sky-50"
          >
            <div className="flex items-center space-x-3">
              <User className="w-5 h-5 text-gray-400" />
              <div className="text-left">
                <p className="font-medium">{mechanic.name}</p>
                <p className="text-sm text-gray-500">
                  {mechanic.specializations.join(', ')}
                </p>
              </div>
            </div>
          </button>
        ))}

        {availableMechanics.length === 0 && (
          <p className="text-center text-gray-500 py-4">
            No mechanics available for this time slot
          </p>
        )}
      </div>
    </div>
  );
}