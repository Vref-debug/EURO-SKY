import React from 'react';
import { TaskCard } from './TaskCard';
import type { DetailedTask } from '../../types/task';

interface TaskListProps {
  tasks: DetailedTask[];
}

export function TaskList({ tasks }: TaskListProps) {
  return (
    <div className="space-y-4">
      {tasks.map((task) => (
        <TaskCard key={task.id} task={task} />
      ))}
    </div>
  );
}