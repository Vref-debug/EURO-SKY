import React from 'react';
import type { DetailedTask, TaskFilter } from '../../types/task';

interface TaskFiltersProps {
  filters: TaskFilter;
  onFilterChange: (filters: TaskFilter) => void;
  tasks: DetailedTask[];
}

export function TaskFilters({ filters, onFilterChange, tasks }: TaskFiltersProps) {
  const uniqueAircraft = [...new Set(tasks.map(t => t.aircraftInfo.registration))];
  const uniquePriorities = [...new Set(tasks.map(t => t.priority))];
  const uniqueStatuses = [...new Set(tasks.map(t => t.status))];
  const uniqueAssignees = [...new Set(tasks.map(t => t.assignedTo?.id).filter(Boolean))];

  const handleFilterChange = (type: keyof TaskFilter, value: string) => {
    const newFilters = { ...filters };
    const array = newFilters[type];
    const index = array.indexOf(value);
    
    if (index === -1) {
      array.push(value);
    } else {
      array.splice(index, 1);
    }
    
    onFilterChange(newFilters);
  };

  return (
    <div className="flex space-x-4">
      <select
        className="rounded-md border-gray-300 shadow-sm focus:border-sky-500 focus:ring-sky-500"
        onChange={(e) => handleFilterChange('aircraft', e.target.value)}
        value={filters.aircraft[0] || ''}
      >
        <option value="">All Aircraft</option>
        {uniqueAircraft.map(reg => (
          <option key={reg} value={reg}>{reg}</option>
        ))}
      </select>

      <select
        className="rounded-md border-gray-300 shadow-sm focus:border-sky-500 focus:ring-sky-500"
        onChange={(e) => handleFilterChange('status', e.target.value)}
        value={filters.status[0] || ''}
      >
        <option value="">All Statuses</option>
        {uniqueStatuses.map(status => (
          <option key={status} value={status}>{status}</option>
        ))}
      </select>

      <select
        className="rounded-md border-gray-300 shadow-sm focus:border-sky-500 focus:ring-sky-500"
        onChange={(e) => handleFilterChange('priority', e.target.value)}
        value={filters.priority[0] || ''}
      >
        <option value="">All Priorities</option>
        {uniquePriorities.map(priority => (
          <option key={priority} value={priority}>{priority}</option>
        ))}
      </select>
    </div>
  );
}