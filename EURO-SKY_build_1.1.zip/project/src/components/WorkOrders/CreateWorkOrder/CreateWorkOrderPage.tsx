import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, ArrowLeft } from 'lucide-react';
import { DashboardLayout } from '../../DashboardLayout';
import { CreateWorkOrderHeader } from './CreateWorkOrderHeader';
import { useAuth } from '../../../hooks/useAuth';
import { formatDate } from '../../../utils/dateUtils';

export function CreateWorkOrderPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isImporting, setIsImporting] = useState(false);

  // Generate a new work order ID (format: WO-YYYY-XXXX)
  const generateWorkOrderId = () => {
    const year = new Date().getFullYear();
    const random = Math.floor(1000 + Math.random() * 9000);
    return `WO-${year}-${random}`;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Handle CSV import
      const reader = new FileReader();
      reader.onload = (e) => {
        // Process CSV data
        console.log('CSV Data:', e.target?.result);
      };
      reader.readAsText(file);
    }
  };

  const handleReturn = () => {
    navigate('/scheduler-dashboard');
  };

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Return Button */}
          <button
            onClick={handleReturn}
            className="mb-4 flex items-center text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Scheduler Dashboard
          </button>

          <CreateWorkOrderHeader
            workOrderId={generateWorkOrderId()}
            createdBy={`${user?.firstName} ${user?.lastName}`}
            createdAt={formatDate(new Date())}
          />

          <div className="mt-8 bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">Create Work Order</h2>
              <div>
                <input
                  type="file"
                  id="csvUpload"
                  accept=".csv"
                  className="hidden"
                  onChange={handleFileUpload}
                />
                <label
                  htmlFor="csvUpload"
                  className="flex items-center space-x-2 bg-sky-100 text-sky-700 px-4 py-2 rounded-lg cursor-pointer hover:bg-sky-200"
                >
                  <Upload className="w-5 h-5" />
                  <span>Import CSV</span>
                </label>
              </div>
            </div>

            {/* Content area for future implementation */}
            <div className="h-96 flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
              <p className="text-gray-500">Work Order form content will be implemented here</p>
            </div>

            {/* Action Buttons */}
            <div className="mt-6 flex justify-end space-x-4">
              <button
                onClick={handleReturn}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 bg-sky-600 text-white rounded-lg hover:bg-sky-700"
                disabled={true} // Enable when form is implemented
              >
                Create Work Order
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}