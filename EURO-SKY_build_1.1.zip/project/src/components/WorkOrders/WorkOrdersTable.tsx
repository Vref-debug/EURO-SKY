import React, { useState } from 'react';
import { AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { WorkOrderRow } from './WorkOrderRow';
import { TaskCard } from './TaskCard';
import type { WorkOrder, Task } from '../../types/workOrder';

interface WorkOrdersTableProps {
  workOrders: WorkOrder[];
}

export function WorkOrdersTable({ workOrders }: WorkOrdersTableProps) {
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const sortedWorkOrders = [...workOrders].sort((a, b) => {
    // Sort by priority first
    const priorityOrder = { high: 0, medium: 1, low: 2 };
    if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    }
    // Then by due date
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
  };

  return (
    <div className="relative">
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50">
            <tr>
              <th className="px-6 py-3">Aircraft</th>
              <th className="px-6 py-3">Work Order</th>
              <th className="px-6 py-3">Tasks</th>
              <th className="px-6 py-3">Status</th>
              <th className="px-6 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedWorkOrders.map((workOrder) => (
              <WorkOrderRow
                key={workOrder.id}
                workOrder={workOrder}
                onTaskClick={handleTaskClick}
              />
            ))}
          </tbody>
        </table>
      </div>

      {selectedTask && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <TaskCard task={selectedTask} onClose={() => setSelectedTask(null)} />
        </div>
      )}
    </div>
  );
}