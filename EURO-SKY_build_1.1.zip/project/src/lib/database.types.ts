export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          first_name: string
          last_name: string
          phone_number: string
          company: string | null
          created_at: string
          mfa_enabled: boolean
        }
        Insert: {
          id: string
          email: string
          first_name: string
          last_name: string
          phone_number: string
          company?: string | null
          created_at?: string
          mfa_enabled?: boolean
        }
        Update: {
          id?: string
          email?: string
          first_name?: string
          last_name?: string
          phone_number?: string
          company?: string | null
          created_at?: string
          mfa_enabled?: boolean
        }
      }
    }
  }
}