export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  company?: string;
  role?: string;
}

export interface SignUpCredentials {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  company?: string;
  role: string;
}

export interface SignInCredentials {
  email: string;
  password: string;
}

export interface UserRole {
  id: string;
  role: string;
  description: string;
}