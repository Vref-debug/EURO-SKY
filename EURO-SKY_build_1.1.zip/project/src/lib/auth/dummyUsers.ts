// Dummy users for testing
export const dummyUsers = [
  {
    email: 'school-admin@demo.com',
    password: 'demo1234',
    firstName: 'Emma',
    lastName: 'Davis',
    role: 'flight-school-admin'
  },
  {
    email: 'mechanic@demo.com',
    password: 'demo1234',
    firstName: 'Mike',
    lastName: 'Johnson',
    role: 'mechanic'
  },
  {
    email: 'owner@demo.com',
    password: 'demo1234',
    firstName: 'David',
    lastName: 'Brown',
    role: 'owner'
  },
  {
    email: 'admin@demo.com',
    password: 'demo1234',
    firstName: 'Sarah',
    lastName: 'Wilson',
    role: 'admin'
  },
  {
    email: 'multi@demo.com',
    password: 'demo1234',
    firstName: 'James',
    lastName: 'Miller',
    role: 'mechanic',
    roles: ['mechanic', 'scheduler']
  },
  // Duplicate entry for the second role
  {
    email: 'multi@demo.com',
    password: 'demo1234',
    firstName: 'James',
    lastName: 'Miller',
    role: 'scheduler',
    roles: ['mechanic', 'scheduler']
  }
];