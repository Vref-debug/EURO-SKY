export type TaskType = 'inspection' | 'ad' | 'sb' | 'engine' | 'airframe';
export type TaskStatus = 'pending' | 'in-progress' | 'completed';
export type WorkOrderPriority = 'high' | 'medium' | 'low';

export interface Task {
  id: string;
  type: TaskType;
  description: string;
  status: TaskStatus;
  dueDate: string;
}

export interface WorkOrder {
  id: string;
  aircraftRegistration: string;
  description: string;
  priority: WorkOrderPriority;
  dueDate: string;
  tasks: Task[];
  status: TaskStatus;
}