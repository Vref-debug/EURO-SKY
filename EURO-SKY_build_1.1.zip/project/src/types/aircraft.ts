export interface AircraftStatus {
  registration: string;
  type: string;
  totalHours: number;
  engineHours: number;
  lastMaintenanceDate: string;
  estimatedNextMaintenanceDate: string;
  hoursUntilMaintenance: number;
  status: 'active' | 'maintenance' | 'grounded';
  lastUpdated: string;
  averageMonthlyHours: number;
}