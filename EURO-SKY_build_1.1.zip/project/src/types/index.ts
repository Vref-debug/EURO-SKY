export interface Aircraft {
  id: string;
  registration: string;
  model: string;
  serialNumber: string;
  yearOfManufacture: number;
  totalFlightHours: number;
  engineHours: number;
  lastMaintenanceDate: string;
  nextMaintenanceDate: string;
  owner: string;
  type: 'private' | 'school';
}

export interface MaintenanceRequest {
  id: string;
  aircraftId: string;
  type: 'repair' | 'maintenance' | 'inspection';
  description: string;
  status: 'pending' | 'approved' | 'in-progress' | 'completed';
  requestDate: string;
  completionDate?: string;
}

export interface FlightLog {
  id: string;
  aircraftId: string;
  date: string;
  flightHours: number;
  engineHours: number;
  pilotName: string;
}