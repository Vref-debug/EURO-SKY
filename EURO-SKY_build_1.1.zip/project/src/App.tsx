import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './i18n/LanguageContext';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { TeamPage } from './pages/TeamPage';
import { AuthPage } from './pages/AuthPage';
import { ProtectedRoute } from './components/Auth/ProtectedRoute';
import { CreateWorkOrderPage } from './components/WorkOrders/CreateWorkOrder/CreateWorkOrderPage';
import { WorkOrderTasksPage } from './pages/WorkOrderTasksPage';
import { PilotDashboard } from './pages/dashboards/PilotDashboard';
import { InstructorDashboard } from './pages/dashboards/InstructorDashboard';
import { MechanicDashboard } from './pages/dashboards/MechanicDashboard';
import { InspectorDashboard } from './pages/dashboards/InspectorDashboard';
import { ManagerDashboard } from './pages/dashboards/ManagerDashboard';
import { SchedulerDashboard } from './pages/dashboards/SchedulerDashboard';
import { StudentDashboard } from './pages/dashboards/StudentDashboard';
import { OwnerDashboard } from './pages/dashboards/OwnerDashboard';
import { AdminDashboard } from './pages/dashboards/AdminDashboard';
import { FlightSchoolAdminDashboard } from './pages/dashboards/FlightSchoolAdminDashboard';

export default function App() {
  return (
    <LanguageProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/team" element={<TeamPage />} />
          <Route path="/auth" element={<AuthPage />} />
          
          {/* Protected Dashboard Routes */}
          <Route path="/pilot-dashboard" element={
            <ProtectedRoute>
              <PilotDashboard />
            </ProtectedRoute>
          } />
          <Route path="/instructor-dashboard" element={
            <ProtectedRoute>
              <InstructorDashboard />
            </ProtectedRoute>
          } />
          <Route path="/mechanic-dashboard" element={
            <ProtectedRoute>
              <MechanicDashboard />
            </ProtectedRoute>
          } />
          <Route path="/inspector-dashboard" element={
            <ProtectedRoute>
              <InspectorDashboard />
            </ProtectedRoute>
          } />
          <Route path="/manager-dashboard" element={
            <ProtectedRoute>
              <ManagerDashboard />
            </ProtectedRoute>
          } />
          <Route path="/scheduler-dashboard" element={
            <ProtectedRoute>
              <SchedulerDashboard />
            </ProtectedRoute>
          } />
          <Route path="/student-dashboard" element={
            <ProtectedRoute>
              <StudentDashboard />
            </ProtectedRoute>
          } />
          <Route path="/owner-dashboard" element={
            <ProtectedRoute>
              <OwnerDashboard />
            </ProtectedRoute>
          } />
          <Route path="/admin-dashboard" element={
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          } />
          <Route path="/flight-school-admin-dashboard" element={
            <ProtectedRoute>
              <FlightSchoolAdminDashboard />
            </ProtectedRoute>
          } />
          
          {/* Work Order Routes */}
          <Route path="/work-orders/create" element={
            <ProtectedRoute>
              <CreateWorkOrderPage />
            </ProtectedRoute>
          } />
          <Route path="/work-orders/:workOrderId/tasks" element={
            <ProtectedRoute>
              <WorkOrderTasksPage />
            </ProtectedRoute>
          } />
        </Routes>
      </Router>
    </LanguageProvider>
  );
}