import React from 'react';
import { Layout } from '../../components/Layout';
import { AircraftStatusCard } from '../../components/Dashboard/FlightSchool/AircraftStatusCard';
import type { AircraftStatus } from '../../types/aircraft';

export function OwnerDashboard() {
  // Mock data for a single aircraft
  const aircraftData: AircraftStatus = {
    registration: 'OO-ABC',
    type: 'Cessna 172S',
    totalHours: 1234.5,
    engineHours: 1234.5,
    lastMaintenanceDate: '15/02/2024',
    estimatedNextMaintenanceDate: '15/04/2024',
    hoursUntilMaintenance: 48.5,
    status: 'active',
    lastUpdated: '15/03/2024',
    averageMonthlyHours: 32.5
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Aircraft Owner Dashboard</h1>
          </div>

          <div className="max-w-3xl mx-auto">
            <AircraftStatusCard aircraft={aircraftData} />
          </div>
        </div>
      </div>
    </Layout>
  );
}