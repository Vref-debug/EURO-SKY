import React from 'react';
import { Users, BookOpen, BarChart } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout';
import { AircraftList } from '../../components/Dashboard/FlightSchool/AircraftList';
import { formatDate } from '../../utils/dateUtils';
import type { AircraftStatus } from '../../types/aircraft';

export function FlightSchoolAdminDashboard() {
  // Mock data for the fleet status
  const fleetStatus: AircraftStatus[] = [
    {
      registration: 'OO-ABC',
      type: 'Cessna 172S',
      totalHours: 1234.5,
      engineHours: 1234.5,
      lastMaintenanceDate: '15/02/2024',
      estimatedNextMaintenanceDate: '15/04/2024',
      hoursUntilMaintenance: 48.5,
      status: 'active',
      lastUpdated: '15/03/2024',
      averageMonthlyHours: 32.5
    },
    {
      registration: 'OO-DEF',
      type: 'Piper PA-28',
      totalHours: 2456.8,
      engineHours: 2456.8,
      lastMaintenanceDate: '01/03/2024',
      estimatedNextMaintenanceDate: '01/05/2024',
      hoursUntilMaintenance: 22.3,
      status: 'active',
      lastUpdated: '14/03/2024',
      averageMonthlyHours: 28.7
    }
  ];

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Active Aircraft</h3>
                <Users className="w-6 h-6 text-sky-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">12</div>
              <p className="text-gray-600">Aircraft in fleet</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Training Hours</h3>
                <BookOpen className="w-6 h-6 text-yellow-500" />
              </div>
              <div className="text-xl font-semibold">245.5</div>
              <p className="text-gray-600">This month</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Maintenance</h3>
                <BarChart className="w-6 h-6 text-green-500" />
              </div>
              <div className="text-xl font-semibold text-green-600">2</div>
              <p className="text-gray-600">Due this week</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-semibold mb-6">Fleet Status</h2>
            <AircraftList aircraft={fleetStatus} />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}