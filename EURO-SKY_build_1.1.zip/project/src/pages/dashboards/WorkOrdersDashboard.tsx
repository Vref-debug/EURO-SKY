import React from 'react';
import { Layout } from '../../components/Layout';
import { WorkOrdersTable } from '../../components/WorkOrders/WorkOrdersTable';
import type { WorkOrder } from '../../types/workOrder';

export function WorkOrdersDashboard() {
  // Mock data - in a real app, this would come from your API
  const mockWorkOrders: WorkOrder[] = [
    {
      id: 'WO-2024-001',
      aircraftRegistration: 'OO-ABC',
      description: '50 Hour Inspection',
      priority: 'high',
      dueDate: '20/03/2024',
      status: 'pending',
      tasks: [
        {
          id: 'T1',
          type: 'inspection',
          description: 'Engine oil check and change',
          status: 'pending',
          dueDate: '20/03/2024'
        },
        {
          id: 'T2',
          type: 'ad',
          description: 'AD 2024-02: Fuel system inspection',
          status: 'pending',
          dueDate: '20/03/2024'
        }
      ]
    },
    {
      id: 'WO-2024-002',
      aircraftRegistration: 'OO-DEF',
      description: 'Annual Maintenance',
      priority: 'medium',
      dueDate: '25/03/2024',
      status: 'in-progress',
      tasks: [
        {
          id: 'T3',
          type: 'inspection',
          description: '100 Hour Inspection',
          status: 'in-progress',
          dueDate: '25/03/2024'
        },
        {
          id: 'T4',
          type: 'engine',
          description: 'Cylinder compression test',
          status: 'pending',
          dueDate: '25/03/2024'
        }
      ]
    }
  ];

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Work Orders Dashboard</h1>
          </div>

          <div className="bg-white rounded-lg shadow-md">
            <WorkOrdersTable workOrders={mockWorkOrders} />
          </div>
        </div>
      </div>
    </Layout>
  );
}