import React, { useState } from 'react';
import { DashboardLayout } from '../components/DashboardLayout';
import { SchedulerCalendar } from '../components/Scheduler/SchedulerCalendar';
import { MechanicAssignment } from '../components/Scheduler/MechanicAssignment';
import type { MaintenanceSchedule, Mechanic } from '../types/scheduler';

export function SchedulerDashboard() {
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');

  // Mock data - replace with API calls
  const mockSchedules: MaintenanceSchedule[] = [
    {
      workOrderId: 'WO-2024-001',
      aircraftRegistration: 'OO-ABC',
      tasks: [
        {
          id: 'ST1',
          workOrderId: 'WO-2024-001',
          taskId: 'T1',
          mechanicId: 'M1',
          scheduledDate: '2024-03-20',
          scheduledTime: '09:00',
          estimatedDuration: 120,
          status: 'assigned'
        }
      ],
      startDate: '20/03/2024',
      endDate: '20/03/2024',
      status: 'scheduled'
    }
  ];

  const mockMechanics: Mechanic[] = [
    {
      id: 'M1',
      name: 'John Smith',
      specializations: ['Engine', 'Airframe'],
      availability: [
        {
          id: 'A1',
          date: '2024-03-20',
          startTime: '08:00',
          endTime: '17:00',
          available: true
        }
      ]
    }
  ];

  const handleSlotSelect = (date: string, time: string) => {
    setSelectedDate(date);
    setSelectedTime(time);
  };

  const handleMechanicAssign = async (mechanicId: string) => {
    // Implement mechanic assignment logic
    console.log('Assigning mechanic:', mechanicId, 'to', selectedDate, selectedTime);
  };

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Maintenance Scheduler</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <SchedulerCalendar
              schedules={mockSchedules}
              onSlotSelect={handleSlotSelect}
            />
            {selectedDate && selectedTime && (
              <MechanicAssignment
                mechanics={mockMechanics}
                selectedDate={selectedDate}
                selectedTime={selectedTime}
                onAssign={handleMechanicAssign}
              />
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}