/*
  # Add MFA requirement flag

  1. Changes
    - Add mfa_required column to user_roles table
    - Update existing roles to require MFA
*/

-- Add mfa_required column to user_roles
ALTER TABLE user_roles 
ADD COLUMN IF NOT EXISTS mfa_required boolean DEFAULT true;

-- Update existing roles to require MFA
UPDATE user_roles 
SET mfa_required = true 
WHERE role IN ('pilot', 'instructor', 'maintenance', 'admin');