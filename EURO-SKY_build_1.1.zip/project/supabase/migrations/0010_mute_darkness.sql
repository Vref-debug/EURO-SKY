/*
  # Update User Roles

  1. Changes
    - Add more specific aviation-related roles
    - Update role descriptions
    - Keep MFA requirement for all roles
*/

-- First, delete existing roles to avoid conflicts
DELETE FROM user_roles;

-- Insert updated roles
INSERT INTO user_roles (role, description, mfa_required)
VALUES 
  ('pilot', 'Licensed pilot authorized to operate aircraft', true),
  ('instructor', 'Certified flight instructor with teaching privileges', true),
  ('mechanic', 'Aircraft maintenance technician with repair privileges', true),
  ('inspector', 'Quality control inspector for maintenance operations', true),
  ('manager', 'Maintenance operations manager', true),
  ('scheduler', 'Maintenance scheduling coordinator', true),
  ('student', 'Student pilot in training', true),
  ('owner', 'Aircraft owner or operator', true),
  ('admin', 'System administrator with full privileges', true)
ON CONFLICT (role) DO UPDATE 
SET 
  description = EXCLUDED.description,
  mfa_required = EXCLUDED.mfa_required;