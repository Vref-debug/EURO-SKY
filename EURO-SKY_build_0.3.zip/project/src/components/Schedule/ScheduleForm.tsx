import React, { useState } from 'react';
import { Calendar, Clock } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export function ScheduleForm() {
  const { t } = useLanguage();
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [serviceType, setServiceType] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log({ date, time, serviceType, description });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-6">Request Maintenance Appointment</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Date
          </label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Preferred Time
          </label>
          <div className="relative">
            <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Service Type
          </label>
          <select
            value={serviceType}
            onChange={(e) => setServiceType(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
            required
          >
            <option value="">Select a service</option>
            <option value="inspection">Inspection</option>
            <option value="maintenance">Maintenance</option>
            <option value="repair">Repair</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
            rows={4}
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700"
        >
          Request Appointment
        </button>
      </form>
    </div>
  );
}