import type { ExecutiveMemberType, TechnicalMemberType } from './types';

export const executiveTeamMembers: ExecutiveMemberType[] = [
  {
    name: 'Geert Vanden Berk',
    role: 'CEO / Accountable Manager',
    description: 'Leading EuroSky\'s strategic vision and ensuring regulatory compliance across all operations. ',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=2787'
  },
  {
    name: 'Luc Vermeulen',
    role: 'COO',
    description: 'Overseeing daily operations and maintenance activities to ensure service excellence.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=2940'
  },
  {
    name: 'Bea De Smet',
    role: 'CFO',
    description: 'Managing financial strategy and ensuring sustainable growth for EuroSky.',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=2787'
  },
  {
    name: 'Martin Peeters',
    role: 'CAMO Officer',
    description: 'Ensuring continued airworthiness and maintaining highest safety standards.',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=2787'
  }
];

export const technicalTeamMembers: TechnicalMemberType[] = [
  {
    name: 'John De Smet',
    role: 'Lead Aircraft Engineer',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=2940',
    certifications: ['EASA Part-66 B1', 'FAA A&P']
  },
  {
    name: 'Marie Dubois',
    role: 'Avionics Specialist',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=2787',
    certifications: ['EASA Part-66 B2']
  },
  {
    name: 'Thomas Peeters',
    role: 'Quality Inspector',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=2787',
    certifications: ['EASA Part-66 C']
  }
];