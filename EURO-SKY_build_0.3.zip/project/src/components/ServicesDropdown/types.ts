export interface ServiceCategory {
  title: string;
  items: string[];
}