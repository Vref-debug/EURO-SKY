import React from 'react';
import { Layout } from '../components/Layout';
import { Hero } from '../components/Hero';
import { Services } from '../components/Services';
import { Contact } from '../components/Contact/Contact';
import { PartnerLogos } from '../components/PartnerLogos';

export function HomePage() {
  return (
    <Layout>
      <Hero />
      <Services />
      <div className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">We Work With</h2>
          <PartnerLogos />
        </div>
      </div>
      <Contact />
    </Layout>
  );
}