import React, { useState } from 'react';
import { Mail, Shield, Phone, Building2, User } from 'lucide-react';
import { AuthService } from '../../lib/auth/auth.service';
import { validateSignUp } from '../../lib/auth/validation';
import toast from 'react-hot-toast';
import type { SignUpCredentials } from '../../lib/auth/types';

interface SignUpFormProps {
  onCancel: () => void;
}

export function SignUpForm({ onCancel }: SignUpFormProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<SignUpCredentials>({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    company: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const validationError = validateSignUp(formData);
      if (validationError) {
        toast.error(validationError);
        return;
      }

      const authService = AuthService.getInstance();
      await authService.signUp(formData);
      toast.success('Account created successfully!');
      onCancel();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            First Name <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Last Name <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
              required
            />
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Email <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Password <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
            required
            minLength={8}
          />
        </div>
        <p className="mt-1 text-sm text-gray-500">Must be at least 8 characters</p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Phone Number <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="tel"
            name="phoneNumber"
            value={formData.phoneNumber}
            onChange={handleChange}
            className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Company
        </label>
        <div className="relative">
          <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            name="company"
            value={formData.company}
            onChange={handleChange}
            className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
          />
        </div>
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          disabled={loading}
          className="flex-1 bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
        >
          {loading ? 'Creating Account...' : 'Create Account'}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded hover:bg-gray-200"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}