import React, { useState } from 'react';
import { AuthForm } from './AuthForm';
import { MFASetup } from './MFASetup';
import { MFAVerification } from './MFAVerification';

type AuthStep = 'credentials' | 'mfa-setup' | 'mfa-verify';

interface AuthStepsProps {
  onComplete: () => void;
}

export function AuthSteps({ onComplete }: AuthStepsProps) {
  const [currentStep, setCurrentStep] = useState<AuthStep>('credentials');
  const [mfaData, setMfaData] = useState<{ qrCode: string } | null>(null);

  const handleCredentialsComplete = (data: { mfaData?: any }) => {
    if (data.mfaData) {
      setMfaData(data.mfaData);
      setCurrentStep('mfa-setup');
    } else {
      setCurrentStep('mfa-verify');
    }
  };

  const handleMFASetupComplete = () => {
    onComplete();
  };

  const handleMFAVerifyComplete = () => {
    onComplete();
  };

  return (
    <>
      {currentStep === 'credentials' && (
        <AuthForm onComplete={handleCredentialsComplete} />
      )}
      
      {currentStep === 'mfa-setup' && mfaData && (
        <MFASetup 
          qrCode={mfaData.qrCode} 
          onComplete={handleMFASetupComplete} 
        />
      )}
      
      {currentStep === 'mfa-verify' && (
        <MFAVerification onComplete={handleMFAVerifyComplete} />
      )}
    </>
  );
}