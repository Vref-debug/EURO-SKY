import { SupabaseService } from './supabase.service';
import type { SignUpCredentials, SignInCredentials } from './types';

export class AuthService {
  private static instance: AuthService;
  private supabaseService: SupabaseService;

  private constructor() {
    this.supabaseService = SupabaseService.getInstance();
  }

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  async signUp(credentials: SignUpCredentials) {
    const { user, session } = await this.supabaseService.signUp(credentials);
    
    if (user) {
      // Setup MFA after successful signup
      const mfaData = await this.supabaseService.setupMFA();
      return { user, session, mfaData };
    }
    
    throw new Error('Failed to create account');
  }

  async signIn(credentials: SignInCredentials) {
    return this.supabaseService.signIn(credentials);
  }

  async signOut() {
    return this.supabaseService.signOut();
  }

  async getSession() {
    return this.supabaseService.getSession();
  }

  async verifyMFA(code: string) {
    return this.supabaseService.verifyMFA(code);
  }
}