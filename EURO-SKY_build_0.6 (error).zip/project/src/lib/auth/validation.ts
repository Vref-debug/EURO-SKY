import { SignUpCredentials, SignInCredentials } from './types';

export function validateSignUp(data: SignUpCredentials): string | null {
  const email = data.email.trim();
  
  if (!email || !data.password || !data.firstName || !data.lastName || !data.phoneNumber) {
    return 'All required fields must be filled';
  }
  
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return 'Please enter a valid email address';
  }
  
  if (data.password.length < 8) {
    return 'Password must be at least 8 characters';
  }
  
  return null;
}

export function validateSignIn(data: SignInCredentials): string | null {
  const email = data.email.trim();
  
  if (!email || !data.password) {
    return 'Email and password are required';
  }
  
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return 'Please enter a valid email address';
  }
  
  return null;
}