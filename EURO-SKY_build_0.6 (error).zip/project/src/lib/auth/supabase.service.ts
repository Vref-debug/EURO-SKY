import { supabase } from '../supabase';
import type { SignUpCredentials, SignInCredentials } from './types';

export class SupabaseService {
  private static instance: SupabaseService;

  private constructor() {}

  static getInstance(): SupabaseService {
    if (!SupabaseService.instance) {
      SupabaseService.instance = new SupabaseService();
    }
    return SupabaseService.instance;
  }

  async signUp(credentials: SignUpCredentials) {
    const { data, error } = await supabase.auth.signUp({
      email: credentials.email.trim(),
      password: credentials.password,
      options: {
        data: {
          first_name: credentials.firstName,
          last_name: credentials.lastName,
          phone_number: credentials.phoneNumber,
          company: credentials.company,
          mfa_enabled: true
        }
      }
    });

    if (error) throw error;
    return data;
  }

  async signIn(credentials: SignInCredentials) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email: credentials.email.trim(),
      password: credentials.password
    });

    if (error) throw error;
    return data;
  }

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }

  async getSession() {
    const { data: { session } } = await supabase.auth.getSession();
    return session;
  }

  async setupMFA() {
    const { data, error } = await supabase.auth.mfa.enroll({
      factorType: 'totp'
    });
    
    if (error) throw error;
    return data;
  }

  async verifyMFA(code: string) {
    const { data, error } = await supabase.auth.mfa.verify({
      factorId: 'totp',
      code
    });
    
    if (error) throw error;
    return data;
  }
}