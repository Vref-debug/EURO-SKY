import React from 'react';
import { Layout } from '../components/Layout';
import { ExecutiveTeam } from '../components/Team/ExecutiveTeam';
import { TechnicalTeam } from '../components/Team/TechnicalTeam';

export function TeamPage() {
  return (
    <Layout>
      <div className="py-12 md:py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Leadership Team</h1>
          <ExecutiveTeam />
          <div className="mt-20">
            <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">Technical Experts</h2>
            <TechnicalTeam />
          </div>
        </div>
      </div>
    </Layout>
  );
}