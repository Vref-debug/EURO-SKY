import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { AuthSteps } from '../components/Auth/AuthSteps';

export function AuthPage() {
  const navigate = useNavigate();

  const handleAuthComplete = () => {
    navigate('/schedule');
  };

  return (
    <Layout>
      <div className="min-h-[calc(100vh-80px)] bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto">
            <AuthSteps onComplete={handleAuthComplete} />
          </div>
        </div>
      </div>
    </Layout>
  );
}