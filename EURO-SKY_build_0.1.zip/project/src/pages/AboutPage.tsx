import React from 'react';
import { Layout } from '../components/Layout';
import { useLanguage } from '../i18n/LanguageContext';
import { AboutHistory } from '../components/About/AboutHistory';
import { AboutLocations } from '../components/About/AboutLocations';
import { AboutCertifications } from '../components/About/AboutCertifications';

export function AboutPage() {
  const { t } = useLanguage();
  
  return (
    <Layout>
      <div className="py-12 md:py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-8">{t('about.title')}</h1>
            
            <div className="bg-white rounded-lg shadow-lg p-6 md:p-8 space-y-6">
              <AboutHistory />
              <AboutLocations />
              <AboutCertifications />
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}