import React from 'react';
import { Layout } from '../components/Layout';
import { AuthForm } from '../components/Auth/AuthForm';

export function AuthPage() {
  return (
    <Layout>
      <div className="min-h-[calc(100vh-80px)] bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto">
            <AuthForm />
          </div>
        </div>
      </div>
    </Layout>
  );
}