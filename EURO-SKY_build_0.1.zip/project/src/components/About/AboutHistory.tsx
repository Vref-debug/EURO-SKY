import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';

export function AboutHistory() {
  const { t } = useLanguage();
  
  return (
    <section>
      <h2 className="text-2xl font-semibold mb-4">{t('about.history.title')}</h2>
      <p className="text-gray-700">{t('about.history.content')}</p>
    </section>
  );
}