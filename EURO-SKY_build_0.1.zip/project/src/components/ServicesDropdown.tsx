import React from 'react';

export function ServicesDropdown({ isOpen }: { isOpen: boolean }) {
  if (!isOpen) return null;

  return (
    <div className="absolute top-full mt-2 w-64 bg-white rounded-lg shadow-lg py-2 z-50">
      <ul className="text-gray-800">
        <li className="px-4 py-2 hover:bg-sky-50 cursor-pointer">CAMO Services</li>
        <li className="px-4 py-2 hover:bg-sky-50 cursor-pointer">Aircraft Repairs</li>
        <li className="px-4 py-2 hover:bg-sky-50 cursor-pointer">Scheduled Maintenance</li>
        <li className="px-4 py-2 hover:bg-sky-50 cursor-pointer">Documentation Services</li>
        <li className="px-4 py-2 hover:bg-sky-50 cursor-pointer">Pre-Purchase Inspections</li>
        <li className="px-4 py-2 hover:bg-sky-50 cursor-pointer">Avionics Services</li>
        <li className="px-4 py-2 hover:bg-sky-50 cursor-pointer">Engine Overhaul</li>
        <li className="px-4 py-2 hover:bg-sky-50 cursor-pointer">Interior Refurbishment</li>
      </ul>
    </div>
  );
}