import React from 'react';
import { useLanguage } from '../i18n/LanguageContext';
import { Globe } from 'lucide-react';

export function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center space-x-2">
      <Globe className="w-4 h-4 text-sky-300" />
      <select
        value={language}
        onChange={(e) => setLanguage(e.target.value as 'en' | 'fr' | 'nl')}
        className="bg-transparent text-white border-none focus:ring-0 cursor-pointer text-sm"
      >
        <option value="en" className="text-gray-900">English</option>
        <option value="fr" className="text-gray-900">Français</option>
        <option value="nl" className="text-gray-900">Nederlands</option>
      </select>
    </div>
  );
}