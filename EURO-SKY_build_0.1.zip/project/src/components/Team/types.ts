export interface ExecutiveMemberType {
  name: string;
  role: string;
  description: string;
  image: string;
}

export interface TechnicalMemberType {
  name: string;
  role: string;
  image: string;
  certifications?: string[];
}