import React from 'react';
import { Link } from 'react-router-dom';

export function Hero() {
  return (
    <div className="relative h-[400px] md:h-[600px] bg-cover bg-center" 
         style={{ backgroundImage: 'url("https://www.piper.com/wp-content/uploads/2019/01/19_M350_A2A_Clouds_Small_Web-e1559672081529-1650x877.jpg")' }}>
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-black/40">
        <div className="container mx-auto px-4 h-full flex items-center">
          <div className="max-w-2xl text-white">
            <h1 className="text-3xl md:text-5xl font-bold mb-4 md:mb-6">General Aviation Aircraft Maintenance Services</h1>
            <p className="text-lg md:text-xl mb-6 md:mb-8">Specialized in private aircraft and flight school fleet maintenance</p>
            <Link 
              to="/auth" 
              className="inline-block bg-sky-600 hover:bg-sky-700 text-white px-6 md:px-8 py-2 md:py-3 rounded-lg font-semibold transition-colors"
            >
              Schedule Maintenance
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}