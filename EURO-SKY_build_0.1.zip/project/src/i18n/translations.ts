export const translations = {
  en: {
    nav: {
      home: 'Home',
      about: 'About',
      services: 'Services',
      team: 'Team',
      contact: 'Contact'
    },
    about: {
      title: 'About Euro-Sky',
      history: {
        title: 'Our History',
        content: 'Euro-Sky BV is a leading aircraft maintenance organization in Belgium, specializing in general aviation maintenance since 1990. With over 30 years of experience, we have built a reputation for excellence in aircraft maintenance and continuing airworthiness management.'
      },
      locations: {
        title: 'Our Locations'
      },
      certifications: {
        title: 'Certifications & Approvals'
      }
    },
    // ... rest of the translations
  },
  fr: {
    nav: {
      home: 'Accueil',
      about: 'À Propos',
      services: 'Services',
      team: 'Équipe',
      contact: 'Contact'
    },
    about: {
      title: 'À Propos de Euro-Sky',
      history: {
        title: 'Notre Histoire',
        content: 'Euro-Sky BV est une organisation de maintenance d\'aéronefs de premier plan en Belgique, spécialisée dans la maintenance de l\'aviation générale depuis 1990. Avec plus de 30 ans d\'expérience, nous avons bâti une réputation d\'excellence dans la maintenance des aéronefs et la gestion du maintien de la navigabilité.'
      },
      locations: {
        title: 'Nos Emplacements'
      },
      certifications: {
        title: 'Certifications et Agréments'
      }
    },
    // ... rest of the translations
  },
  nl: {
    nav: {
      home: 'Home',
      about: 'Over Ons',
      services: 'Diensten',
      team: 'Team',
      contact: 'Contact'
    },
    about: {
      title: 'Over Euro-Sky',
      history: {
        title: 'Onze Geschiedenis',
        content: 'Euro-Sky BV is een toonaangevende vliegtuigonderhoudsorganisatie in België, gespecialiseerd in onderhoud van general aviation sinds 1990. Met meer dan 30 jaar ervaring hebben we een reputatie opgebouwd voor uitmuntendheid in vliegtuigonderhoud en continuing airworthiness management.'
      },
      locations: {
        title: 'Onze Locaties'
      },
      certifications: {
        title: 'Certificeringen & Goedkeuringen'
      }
    },
    // ... rest of the translations
  }
};