/*
  # Authentication Schema Setup

  1. New Tables
    - `auth_settings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `mfa_enabled` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `auth_settings` table
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS auth_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  mfa_enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE auth_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own auth settings"
  ON auth_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own auth settings"
  ON auth_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);