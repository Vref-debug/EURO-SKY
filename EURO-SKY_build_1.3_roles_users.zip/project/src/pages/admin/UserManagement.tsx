import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '../../components/DashboardLayout';
import { UserList } from '../../components/Admin/UserList';
import { RoleManagement } from '../../components/Admin/RoleManagement';
import { UserDetails } from '../../components/Admin/UserDetails';
import { supabase } from '../../lib/supabase';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/Tabs';
import { toast } from 'react-hot-toast';
import type { Profile } from '../../types/admin';

export function UserManagementPage() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUsers();
  }, []);

  async function fetchUsers() {
    try {
      setLoading(true);

      // First get all profiles
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Then get role assignments and activity for each profile
      const usersWithDetails = await Promise.all(
        (profiles || []).map(async (profile) => {
          const [
            { data: roleAssignments },
            { data: activity }
          ] = await Promise.all([
            supabase
              .from('role_assignments')
              .select('role, valid_from, valid_until')
              .eq('user_id', profile.id),
            supabase
              .from('user_activity')
              .select('status, last_login, last_active')
              .eq('user_id', profile.id)
          ]);

          return {
            ...profile,
            role_assignments: roleAssignments || [],
            user_activity: activity || []
          };
        })
      );

      setUsers(usersWithDetails);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  }

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Tabs defaultValue="users" className="w-full">
                <TabsList>
                  <TabsTrigger value="users">Users</TabsTrigger>
                  <TabsTrigger value="roles">Roles</TabsTrigger>
                </TabsList>

                <TabsContent value="users">
                  <UserList
                    users={users}
                    loading={loading}
                    onUserSelect={setSelectedUser}
                    onUserUpdate={fetchUsers}
                  />
                </TabsContent>

                <TabsContent value="roles">
                  <RoleManagement onUpdate={fetchUsers} />
                </TabsContent>
              </Tabs>
            </div>

            <div>
              {selectedUser && (
                <UserDetails
                  user={selectedUser}
                  onUpdate={fetchUsers}
                  onClose={() => setSelectedUser(null)}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}