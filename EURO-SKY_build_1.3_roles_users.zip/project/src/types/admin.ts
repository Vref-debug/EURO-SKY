export interface Profile {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
  created_at: string;
  role_assignments?: {
    role: string;
    valid_from: string;
    valid_until: string | null;
  }[];
  user_activity?: {
    status: 'active' | 'disabled' | 'pending_approval';
    last_login: string;
    last_active: string;
  }[];
}