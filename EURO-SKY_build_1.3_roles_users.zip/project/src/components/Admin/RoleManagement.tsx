import React, { useState, useEffect } from 'react';
import { Shield, Plus } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';

interface Role {
  role: string;
  description: string;
}

interface RoleManagementProps {
  onUpdate: () => void;
}

export function RoleManagement({ onUpdate }: RoleManagementProps) {
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [newRole, setNewRole] = useState({
    role_name: '',
    role_description: ''
  });
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    fetchRoles();
  }, []);

  async function fetchRoles() {
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('*');

      if (error) throw error;
      setRoles(data || []);
    } catch (error) {
      console.error('Error fetching roles:', error);
      toast.error('Failed to load roles');
    } finally {
      setLoading(false);
    }
  }

  async function handleAddRole() {
    try {
      if (!newRole.role_name || !newRole.role_description) {
        toast.error('Please fill in all fields');
        return;
      }

      const { error } = await supabase
        .from('user_roles')
        .insert({
          role: newRole.role_name.toLowerCase(),
          description: newRole.role_description
        });

      if (error) throw error;

      toast.success('Role added successfully');
      setNewRole({ role_name: '', role_description: '' });
      setShowAddForm(false);
      fetchRoles();
      onUpdate();
    } catch (error: any) {
      console.error('Error adding role:', error);
      toast.error(error.message || 'Failed to add role');
    }
  }

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-center h-32">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Role Management</h2>
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center space-x-2 px-3 py-2 bg-sky-600 text-white rounded-lg hover:bg-sky-700"
          >
            <Plus className="w-4 h-4" />
            <span>Add Role</span>
          </button>
        </div>
      </div>

      {showAddForm && (
        <div className="p-4 border-b bg-gray-50">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Role Name
              </label>
              <input
                type="text"
                value={newRole.role_name}
                onChange={(e) => setNewRole(prev => ({ ...prev, role_name: e.target.value }))}
                className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
                placeholder="Enter role name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <input
                type="text"
                value={newRole.role_description}
                onChange={(e) => setNewRole(prev => ({ ...prev, role_description: e.target.value }))}
                className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
                placeholder="Enter role description"
              />
            </div>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded"
              >
                Cancel
              </button>
              <button
                onClick={handleAddRole}
                className="px-4 py-2 bg-sky-600 text-white rounded hover:bg-sky-700"
              >
                Add Role
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="divide-y">
        {roles.map((role) => (
          <div key={role.role} className="p-4 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">{role.role}</h3>
                <p className="text-sm text-gray-600">{role.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}