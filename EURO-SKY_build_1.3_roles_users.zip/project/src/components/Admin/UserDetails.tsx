import React from 'react';
import { X, UserCheck, UserX, Shield } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';
import type { Profile } from '../../types/admin';

interface UserDetailsProps {
  user: Profile;
  onUpdate: () => void;
  onClose: () => void;
}

export function UserDetails({ user, onUpdate, onClose }: UserDetailsProps) {
  const handleStatusChange = async (status: 'active' | 'disabled') => {
    try {
      const { error } = await supabase
        .from('user_activity')
        .upsert({
          user_id: user.id,
          status,
          last_active: new Date().toISOString()
        });

      if (error) throw error;
      
      toast.success(`User ${status === 'active' ? 'activated' : 'disabled'} successfully`);
      onUpdate();
    } catch (error) {
      console.error('Error updating user status:', error);
      toast.error('Failed to update user status');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold">User Details</h2>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="space-y-6">
        <div>
          <h3 className="text-sm font-medium text-gray-500">Basic Information</h3>
          <div className="mt-2 space-y-2">
            <p className="text-sm">
              <span className="font-medium">Name:</span>{' '}
              {user.first_name} {user.last_name}
            </p>
            <p className="text-sm">
              <span className="font-medium">Email:</span> {user.email}
            </p>
            <p className="text-sm">
              <span className="font-medium">Member since:</span>{' '}
              {new Date(user.created_at).toLocaleDateString()}
            </p>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-500">Roles</h3>
          <div className="mt-2 space-y-2">
            {user.role_assignments?.map((ra, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-sky-500" />
                <span className="text-sm">{ra.role}</span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-gray-500">Actions</h3>
          <div className="mt-2 space-y-2">
            <button
              onClick={() => handleStatusChange('active')}
              className="flex items-center space-x-2 px-3 py-2 text-sm text-green-700 hover:bg-green-50 rounded-md w-full"
            >
              <UserCheck className="w-4 h-4" />
              <span>Activate User</span>
            </button>
            <button
              onClick={() => handleStatusChange('disabled')}
              className="flex items-center space-x-2 px-3 py-2 text-sm text-red-700 hover:bg-red-50 rounded-md w-full"
            >
              <UserX className="w-4 h-4" />
              <span>Disable User</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}