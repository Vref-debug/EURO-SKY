/*
  # User Role Management System

  1. New Tables
    - `role_permissions` - Stores available permissions
    - `role_assignments` - Tracks user-role assignments with time constraints
    - `role_hierarchies` - Manages role inheritance
    - `audit_logs` - Tracks all role-related changes
    - `permission_sets` - Groups of permissions that can be assigned
    - `user_activity` - Tracks user actions and status

  2. Security
    - Enable RLS on all tables
    - Add policies for admin access
    - Add policies for user self-view

  3. Changes
    - Add audit logging triggers
    - Add validation functions
*/

-- Create enum for audit action types
CREATE TYPE audit_action AS ENUM (
  'role_assigned',
  'role_removed',
  'permission_granted',
  'permission_revoked',
  'user_disabled',
  'user_enabled',
  'role_created',
  'role_modified',
  'role_deleted'
);

-- Create enum for user status
CREATE TYPE user_status AS ENUM (
  'active',
  'disabled',
  'pending_approval'
);

-- Store available permissions
CREATE TABLE role_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Track role assignments
CREATE TABLE role_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  role text REFERENCES user_roles(role) ON DELETE CASCADE,
  assigned_by uuid REFERENCES auth.users(id),
  valid_from timestamptz DEFAULT now(),
  valid_until timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Manage role inheritance
CREATE TABLE role_hierarchies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_role text REFERENCES user_roles(role) ON DELETE CASCADE,
  child_role text REFERENCES user_roles(role) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(parent_role, child_role),
  CHECK (parent_role != child_role)
);

-- Track all changes
CREATE TABLE audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action audit_action NOT NULL,
  actor_id uuid REFERENCES auth.users(id),
  target_id uuid REFERENCES auth.users(id),
  role text REFERENCES user_roles(role),
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Track user activity
CREATE TABLE user_activity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  status user_status DEFAULT 'active',
  last_login timestamptz,
  last_active timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_hierarchies ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activity ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can manage role permissions"
  ON role_permissions
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can manage role assignments"
  ON role_assignments
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can view their own role assignments"
  ON role_assignments
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can view audit logs"
  ON audit_logs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can view their own activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Create updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_role_permissions_updated_at
  BEFORE UPDATE ON role_permissions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_activity_updated_at
  BEFORE UPDATE ON user_activity
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create audit logging function
CREATE OR REPLACE FUNCTION log_role_change()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO audit_logs (action, actor_id, target_id, role, details)
    VALUES (
      'role_assigned',
      auth.uid(),
      NEW.user_id,
      NEW.role,
      jsonb_build_object(
        'valid_from', NEW.valid_from,
        'valid_until', NEW.valid_until
      )
    );
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO audit_logs (action, actor_id, target_id, role)
    VALUES (
      'role_removed',
      auth.uid(),
      OLD.user_id,
      OLD.role
    );
  END IF;
  RETURN NULL;
END;
$$ language 'plpgsql' SECURITY DEFINER;

-- Create trigger for role assignment logging
CREATE TRIGGER log_role_assignments
  AFTER INSERT OR DELETE ON role_assignments
  FOR EACH ROW
  EXECUTE FUNCTION log_role_change();

-- Insert default permissions
INSERT INTO role_permissions (name, description) VALUES
  ('user.read', 'View user information'),
  ('user.create', 'Create new users'),
  ('user.update', 'Update user information'),
  ('user.delete', 'Delete users'),
  ('role.assign', 'Assign roles to users'),
  ('role.create', 'Create new roles'),
  ('role.update', 'Update role information'),
  ('role.delete', 'Delete roles')
ON CONFLICT (name) DO NOTHING;