/*
  # Insert Demo Data
  
  1. Changes
    - Insert demo users into auth.users
    - Create corresponding profiles
    - Add role assignments and activity records
    - Handle conflicts properly with email uniqueness
*/

-- First, insert users into auth.users
INSERT INTO auth.users (id, email, created_at)
SELECT 
  uuid, email, created_date
FROM (
  VALUES 
    ('d7bed82c-5f89-4d6e-89d9-e4c4e3236689'::uuid, 'john.smith@demo.com', NOW() - INTERVAL '30 days'),
    ('b9d5e138-7a42-4c5e-9a1d-874c5d68d488'::uuid, 'sarah.wilson@demo.com', NOW() - INTERVAL '60 days'),
    ('f6d8a56c-2d89-4b9e-8f4a-9d2c6f38d123'::uuid, 'mike.johnson@demo.com', NOW() - INTERVAL '45 days'),
    ('e5c7b49a-3f12-4d6b-b1e5-8a9d7f25c456'::uuid, 'emma.davis@demo.com', NOW() - INTERVAL '15 days')
) AS data(uuid, email, created_date)
WHERE NOT EXISTS (
  SELECT 1 FROM auth.users WHERE email = data.email
);

-- Then insert into profiles
INSERT INTO profiles (id, email, first_name, last_name, role, created_at, phone_number)
SELECT 
  uuid, email, first_name, last_name, role, created_date, '+1234567890'
FROM (
  VALUES 
    ('d7bed82c-5f89-4d6e-89d9-e4c4e3236689'::uuid, 'john.smith@demo.com', 'John', 'Smith', 'mechanic', NOW() - INTERVAL '30 days'),
    ('b9d5e138-7a42-4c5e-9a1d-874c5d68d488'::uuid, 'sarah.wilson@demo.com', 'Sarah', 'Wilson', 'admin', NOW() - INTERVAL '60 days'),
    ('f6d8a56c-2d89-4b9e-8f4a-9d2c6f38d123'::uuid, 'mike.johnson@demo.com', 'Mike', 'Johnson', 'pilot', NOW() - INTERVAL '45 days'),
    ('e5c7b49a-3f12-4d6b-b1e5-8a9d7f25c456'::uuid, 'emma.davis@demo.com', 'Emma', 'Davis', 'instructor', NOW() - INTERVAL '15 days')
) AS data(uuid, email, first_name, last_name, role, created_date)
WHERE NOT EXISTS (
  SELECT 1 FROM profiles WHERE email = data.email
);

-- Insert role assignments
INSERT INTO role_assignments (user_id, role, valid_from, assigned_by)
SELECT 
  user_id, role, valid_from, assigned_by
FROM (
  VALUES 
    ('d7bed82c-5f89-4d6e-89d9-e4c4e3236689'::uuid, 'mechanic', NOW() - INTERVAL '30 days', 'b9d5e138-7a42-4c5e-9a1d-874c5d68d488'::uuid),
    ('b9d5e138-7a42-4c5e-9a1d-874c5d68d488'::uuid, 'admin', NOW() - INTERVAL '60 days', 'b9d5e138-7a42-4c5e-9a1d-874c5d68d488'::uuid),
    ('f6d8a56c-2d89-4b9e-8f4a-9d2c6f38d123'::uuid, 'pilot', NOW() - INTERVAL '45 days', 'b9d5e138-7a42-4c5e-9a1d-874c5d68d488'::uuid),
    ('e5c7b49a-3f12-4d6b-b1e5-8a9d7f25c456'::uuid, 'instructor', NOW() - INTERVAL '15 days', 'b9d5e138-7a42-4c5e-9a1d-874c5d68d488'::uuid)
) AS data(user_id, role, valid_from, assigned_by)
WHERE NOT EXISTS (
  SELECT 1 FROM role_assignments 
  WHERE user_id = data.user_id AND role = data.role
);

-- Insert user activity records
INSERT INTO user_activity (user_id, status, last_login, last_active)
SELECT 
  user_id, status::user_status, last_login, last_active
FROM (
  VALUES 
    ('d7bed82c-5f89-4d6e-89d9-e4c4e3236689'::uuid, 'active', NOW() - INTERVAL '2 days', NOW() - INTERVAL '1 day'),
    ('b9d5e138-7a42-4c5e-9a1d-874c5d68d488'::uuid, 'active', NOW() - INTERVAL '1 day', NOW() - INTERVAL '2 hours'),
    ('f6d8a56c-2d89-4b9e-8f4a-9d2c6f38d123'::uuid, 'active', NOW() - INTERVAL '5 days', NOW() - INTERVAL '5 days'),
    ('e5c7b49a-3f12-4d6b-b1e5-8a9d7f25c456'::uuid, 'pending_approval', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days')
) AS data(user_id, status, last_login, last_active)
WHERE NOT EXISTS (
  SELECT 1 FROM user_activity WHERE user_id = data.user_id
);