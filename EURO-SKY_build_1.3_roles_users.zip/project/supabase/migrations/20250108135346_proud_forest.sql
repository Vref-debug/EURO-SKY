/*
  # Fix User Activity Policies

  1. Updates
    - Add INSERT/UPDATE policies for user_activity table
    - Ensure admins can manage user activity
    - Maintain existing read policies
  
  2. Security
    - Proper access control for admins
    - Maintains data integrity
*/

-- Drop existing policies for user_activity
DROP POLICY IF EXISTS "Anyone can read user activity" ON user_activity;

-- Create comprehensive policies for user_activity
CREATE POLICY "Anyone can read user activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage user activity"
  ON user_activity
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can manage own activity"
  ON user_activity
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());