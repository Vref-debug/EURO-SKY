/*
  # Fix RLS Policy Recursion

  1. Changes
    - Remove recursive policy checks
    - Simplify RLS policies to use direct role checks
    - Add admin access policies without recursion

  2. Security
    - Maintains security model
    - Prevents infinite recursion
    - Preserves admin privileges
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Users can view activity" ON user_activity;
DROP POLICY IF EXISTS "Users can view role assignments" ON role_assignments;

-- Create new non-recursive policies for profiles
CREATE POLICY "Allow users to read profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR
    role = 'admin'
  );

CREATE POLICY "Allow users to update profiles"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR
    role = 'admin'
  );

-- Create new policies for user_activity
CREATE POLICY "Allow users to view activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 
      FROM auth.users 
      WHERE auth.users.id = auth.uid() 
      AND user_id = auth.uid()
    )
  );

-- Create new policies for role_assignments
CREATE POLICY "Allow users to view role assignments"
  ON role_assignments
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 
      FROM auth.users 
      WHERE auth.users.id = auth.uid() 
      AND user_id = auth.uid()
    )
  );