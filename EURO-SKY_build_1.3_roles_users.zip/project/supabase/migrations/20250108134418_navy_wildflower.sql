-- Grant necessary permissions to authenticated users
CREATE OR REPLACE FUNCTION auth.get_auth_user_info()
RETURNS TABLE (
  id uuid,
  email text,
  created_at timestamptz
) 
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, email::text, created_at
  FROM auth.users;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION auth.get_auth_user_info TO authenticated;

-- Update profiles policy to use the function
CREATE OR REPLACE POLICY "Allow users to read profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.get_auth_user_info()
      WHERE id = auth.uid()
    )
    OR role = 'admin'
  );

-- Update user_activity policy
CREATE OR REPLACE POLICY "Allow users to view activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- Update role_assignments policy
CREATE OR REPLACE POLICY "Allow users to view role assignments"
  ON role_assignments
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );