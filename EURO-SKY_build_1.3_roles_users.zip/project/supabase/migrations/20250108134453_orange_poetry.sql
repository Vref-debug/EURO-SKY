-- Create secure function to access auth user info
CREATE OR REPLACE FUNCTION get_auth_user_info()
RETURNS TABLE (
  id uuid,
  email text,
  created_at timestamptz
) 
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id, email::text, created_at
  FROM auth.users;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_auth_user_info TO authenticated;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow users to read profiles" ON profiles;
DROP POLICY IF EXISTS "Allow users to view activity" ON user_activity;
DROP POLICY IF EXISTS "Allow users to view role assignments" ON role_assignments;

-- Create simplified policies
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all users to read profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow users to update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (id = auth.uid());

ALTER TABLE user_activity ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all users to view activity"
  ON user_activity FOR SELECT
  TO authenticated
  USING (true);

ALTER TABLE role_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all users to view assignments"
  ON role_assignments FOR SELECT
  TO authenticated
  USING (true);