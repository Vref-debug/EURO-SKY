/*
  # Fix User Management Relationships

  1. Changes
    - Add foreign key from role_assignments to profiles
    - Add foreign key from user_activity to profiles
    - Update RLS policies for better access control
*/

-- Add foreign key from role_assignments to profiles
ALTER TABLE role_assignments
ADD CONSTRAINT fk_role_assignments_profile
FOREIGN KEY (user_id) REFERENCES profiles(id)
ON DELETE CASCADE;

-- Add foreign key from user_activity to profiles
ALTER TABLE user_activity
ADD CONSTRAINT fk_user_activity_profile
FOREIGN KEY (user_id) REFERENCES profiles(id)
ON DELETE CASCADE;

-- Update RLS policies for better access
CREATE POLICY "Admins can read all role assignments"
  ON role_assignments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can read all user activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );