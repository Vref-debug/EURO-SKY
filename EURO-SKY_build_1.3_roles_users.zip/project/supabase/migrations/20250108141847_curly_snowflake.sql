-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can read active roles" ON user_roles_master;
DROP POLICY IF EXISTS "Admins can manage roles" ON user_roles_master;

-- Create more specific policies
CREATE POLICY "Anyone can read roles"
  ON user_roles_master
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert roles"
  ON user_roles_master
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update roles"
  ON user_roles_master
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can delete roles"
  ON user_roles_master
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Create function to safely add roles
CREATE OR REPLACE FUNCTION add_role(
  p_role_name text,
  p_role_description text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_role_id uuid;
BEGIN
  INSERT INTO user_roles_master (
    role_name,
    role_description,
    created_by,
    status
  )
  VALUES (
    p_role_name,
    p_role_description,
    auth.uid(),
    'active'
  )
  RETURNING role_id INTO v_role_id;
  
  RETURN v_role_id;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION add_role TO authenticated;