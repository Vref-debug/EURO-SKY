-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can read user activity" ON user_activity;
DROP POLICY IF EXISTS "Admins can manage user activity" ON user_activity;
DROP POLICY IF EXISTS "Users can manage own activity" ON user_activity;

-- Create new simplified policies
CREATE POLICY "Anyone can read user activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert user activity"
  ON user_activity
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update user activity"
  ON user_activity
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Ensure the table has RLS enabled
ALTER TABLE user_activity ENABLE ROW LEVEL SECURITY;