/*
  # Fix User Activity RLS Policies

  1. Changes
    - Drop existing policies
    - Add new comprehensive policies for user_activity table
    - Ensure proper admin access for all operations
  
  2. Security
    - Maintains read access for all authenticated users
    - Allows admins to perform all operations
    - Allows users to manage their own activity
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can read user activity" ON user_activity;
DROP POLICY IF EXISTS "Admins can manage all user activity" ON user_activity;
DROP POLICY IF EXISTS "Users can manage own activity" ON user_activity;

-- Create new policies
CREATE POLICY "Anyone can read user activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage user activity"
  ON user_activity
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can manage own activity"
  ON user_activity
  FOR ALL
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());