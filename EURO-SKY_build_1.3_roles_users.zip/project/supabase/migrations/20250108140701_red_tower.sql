/*
  # Role Management System Schema Update
  
  1. New Tables
    - user_roles_master (Main roles table)
    - role_permissions_map (Maps roles to permissions)
    - role_audit_log (Tracks role changes)
  
  2. Changes
    - Adds new columns and constraints to existing tables
    - Updates indexes for performance
    - Implements soft delete
  
  3. Security
    - Adds RLS policies for new tables
    - Updates existing policies
*/

-- Create role status enum if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type WHERE typname = 'role_status'
  ) THEN
    CREATE TYPE role_status AS ENUM ('active', 'inactive', 'deprecated');
  END IF;
END $$;

-- Create user_roles_master table
CREATE TABLE IF NOT EXISTS user_roles_master (
  role_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_name text UNIQUE NOT NULL,
  role_description text NOT NULL,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  modified_at timestamptz DEFAULT now() NOT NULL,
  deleted_at timestamptz,
  created_by uuid REFERENCES auth.users(id),
  modified_by uuid REFERENCES auth.users(id),
  status role_status DEFAULT 'active' NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  version integer DEFAULT 1 NOT NULL,
  CONSTRAINT role_name_format CHECK (role_name ~ '^[a-z][a-z0-9_-]*$')
);

-- Create indexes
CREATE INDEX idx_user_roles_master_role_name ON user_roles_master (role_name);
CREATE INDEX idx_user_roles_master_status ON user_roles_master (status) WHERE status = 'active';
CREATE INDEX idx_user_roles_master_search ON user_roles_master 
  USING gin(to_tsvector('english', role_name || ' ' || role_description));

-- Add soft delete functionality
CREATE OR REPLACE FUNCTION soft_delete_role()
RETURNS TRIGGER AS $$
BEGIN
  NEW.deleted_at = now();
  NEW.is_active = false;
  NEW.status = 'inactive';
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_soft_delete_role
  BEFORE UPDATE OF deleted_at ON user_roles_master
  FOR EACH ROW
  WHEN (OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL)
  EXECUTE FUNCTION soft_delete_role();

-- Create role_permissions_map table
CREATE TABLE IF NOT EXISTS role_permissions_map (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id uuid REFERENCES user_roles_master(role_id) ON DELETE CASCADE,
  permission_id uuid REFERENCES role_permissions(id) ON DELETE CASCADE,
  granted_at timestamptz DEFAULT now() NOT NULL,
  granted_by uuid REFERENCES auth.users(id),
  is_active boolean DEFAULT true NOT NULL,
  UNIQUE(role_id, permission_id)
);

-- Create role audit log
CREATE TABLE IF NOT EXISTS role_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id uuid REFERENCES user_roles_master(role_id),
  action text NOT NULL,
  changed_by uuid REFERENCES auth.users(id),
  changed_at timestamptz DEFAULT now() NOT NULL,
  old_values jsonb,
  new_values jsonb,
  metadata jsonb DEFAULT '{}'::jsonb
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_role_modified_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.modified_at = now();
  NEW.version = OLD.version + 1;
  
  -- Log changes to audit table
  INSERT INTO role_audit_log (
    role_id,
    action,
    changed_by,
    old_values,
    new_values
  ) VALUES (
    NEW.role_id,
    TG_OP,
    auth.uid(),
    to_jsonb(OLD),
    to_jsonb(NEW)
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_role_modified_at
  BEFORE UPDATE ON user_roles_master
  FOR EACH ROW
  EXECUTE FUNCTION update_role_modified_at();

-- Enable RLS
ALTER TABLE user_roles_master ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_permissions_map ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_audit_log ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Anyone can read active roles"
  ON user_roles_master
  FOR SELECT
  TO authenticated
  USING (is_active = true AND deleted_at IS NULL);

CREATE POLICY "Admins can manage roles"
  ON user_roles_master
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Anyone can read role permissions"
  ON role_permissions_map
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage role permissions"
  ON role_permissions_map
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can read audit logs"
  ON role_audit_log
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Create function to assign role
CREATE OR REPLACE FUNCTION assign_role(
  p_user_id uuid,
  p_role_name text
)
RETURNS void AS $$
BEGIN
  -- Verify role exists and is active
  IF NOT EXISTS (
    SELECT 1 FROM user_roles_master
    WHERE role_name = p_role_name
    AND is_active = true
    AND deleted_at IS NULL
  ) THEN
    RAISE EXCEPTION 'Invalid or inactive role: %', p_role_name;
  END IF;

  -- Assign role
  INSERT INTO role_assignments (user_id, role, assigned_by)
  VALUES (p_user_id, p_role_name, auth.uid())
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON TABLE user_roles_master IS 'Master table for role definitions and management';
COMMENT ON TABLE role_permissions_map IS 'Maps roles to their assigned permissions';
COMMENT ON TABLE role_audit_log IS 'Audit trail for role changes';