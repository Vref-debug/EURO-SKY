-- Drop existing policies
DROP POLICY IF EXISTS "Allow admin and self to read profiles" ON profiles;
DROP POLICY IF EXISTS "Allow admin and self to update profiles" ON profiles;
DROP POLICY IF EXISTS "Allow admin and self to view activity" ON user_activity;
DROP POLICY IF EXISTS "Allow admin and self to view assignments" ON role_assignments;

-- Create simplified but secure policies
CREATE POLICY "Anyone can read profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid());

CREATE POLICY "Anyone can read user activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can read role assignments"
  ON role_assignments
  FOR SELECT
  TO authenticated
  USING (true);

-- Insert demo data if not exists
INSERT INTO profiles (id, email, first_name, last_name, phone_number, role, created_at)
VALUES 
  ('d7bed82c-5f89-4d6e-89d9-e4c4e3236689', 'john.smith@demo.com', 'John', 'Smith', '+1234567890', 'mechanic', NOW() - INTERVAL '30 days'),
  ('b9d5e138-7a42-4c5e-9a1d-874c5d68d488', 'sarah.wilson@demo.com', 'Sarah', 'Wilson', '+1234567891', 'admin', NOW() - INTERVAL '60 days'),
  ('f6d8a56c-2d89-4b9e-8f4a-9d2c6f38d123', 'mike.johnson@demo.com', 'Mike', 'Johnson', '+1234567892', 'pilot', NOW() - INTERVAL '45 days'),
  ('e5c7b49a-3f12-4d6b-b1e5-8a9d7f25c456', 'emma.davis@demo.com', 'Emma', 'Davis', '+1234567893', 'instructor', NOW() - INTERVAL '15 days')
ON CONFLICT (id) DO NOTHING;

-- Insert role assignments
INSERT INTO role_assignments (user_id, role, valid_from, assigned_by)
VALUES
  ('d7bed82c-5f89-4d6e-89d9-e4c4e3236689', 'mechanic', NOW() - INTERVAL '30 days', 'b9d5e138-7a42-4c5e-9a1d-874c5d68d488'),
  ('b9d5e138-7a42-4c5e-9a1d-874c5d68d488', 'admin', NOW() - INTERVAL '60 days', 'b9d5e138-7a42-4c5e-9a1d-874c5d68d488'),
  ('f6d8a56c-2d89-4b9e-8f4a-9d2c6f38d123', 'pilot', NOW() - INTERVAL '45 days', 'b9d5e138-7a42-4c5e-9a1d-874c5d68d488'),
  ('e5c7b49a-3f12-4d6b-b1e5-8a9d7f25c456', 'instructor', NOW() - INTERVAL '15 days', 'b9d5e138-7a42-4c5e-9a1d-874c5d68d488')
ON CONFLICT (user_id, role) DO NOTHING;

-- Insert user activity
INSERT INTO user_activity (user_id, status, last_login, last_active)
VALUES
  ('d7bed82c-5f89-4d6e-89d9-e4c4e3236689', 'active', NOW() - INTERVAL '2 days', NOW() - INTERVAL '1 day'),
  ('b9d5e138-7a42-4c5e-9a1d-874c5d68d488', 'active', NOW() - INTERVAL '1 day', NOW() - INTERVAL '2 hours'),
  ('f6d8a56c-2d89-4b9e-8f4a-9d2c6f38d123', 'active', NOW() - INTERVAL '5 days', NOW() - INTERVAL '5 days'),
  ('e5c7b49a-3f12-4d6b-b1e5-8a9d7f25c456', 'pending_approval', NOW() - INTERVAL '15 days', NOW() - INTERVAL '15 days')
ON CONFLICT (user_id) DO UPDATE SET
  status = EXCLUDED.status,
  last_login = EXCLUDED.last_login,
  last_active = EXCLUDED.last_active;