-- Drop existing policies
DROP POLICY IF EXISTS "Allow all users to read profiles" ON profiles;
DROP POLICY IF EXISTS "Allow users to update own profile" ON profiles;
DROP POLICY IF EXISTS "Allow all users to view activity" ON user_activity;
DROP POLICY IF EXISTS "Allow all users to view assignments" ON role_assignments;

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = user_id AND role = 'admin'
  );
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION is_admin TO authenticated;

-- Create new policies with proper access control
CREATE POLICY "Allow admin and self to read profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR
    is_admin(auth.uid())
  );

CREATE POLICY "Allow admin and self to update profiles"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR
    is_admin(auth.uid())
  );

CREATE POLICY "Allow admin and self to view activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    is_admin(auth.uid())
  );

CREATE POLICY "Allow admin and self to view assignments"
  ON role_assignments
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    is_admin(auth.uid())
  );