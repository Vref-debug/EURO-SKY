/*
  # Fix RLS Policies for Admin Access

  1. Changes
    - Add policy for admins to view all profiles
    - Add policy for admins to update all profiles
    - Add policy for admins to view all user activity
    - Add policy for admins to view all role assignments

  2. Security
    - Maintains existing RLS
    - Adds specific admin privileges
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;

-- Create new policies for profiles
CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = id
    OR EXISTS (
      SELECT 1 FROM profiles admin
      WHERE admin.id = auth.uid()
      AND admin.role = 'admin'
    )
  );

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id
    OR EXISTS (
      SELECT 1 FROM profiles admin
      WHERE admin.id = auth.uid()
      AND admin.role = 'admin'
    )
  );

-- Update user_activity policies
DROP POLICY IF EXISTS "Users can view their own activity" ON user_activity;
DROP POLICY IF EXISTS "Admins can read all user activity" ON user_activity;

CREATE POLICY "Users can view activity"
  ON user_activity
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles admin
      WHERE admin.id = auth.uid()
      AND admin.role = 'admin'
    )
  );

-- Update role_assignments policies
DROP POLICY IF EXISTS "Users can view their own role assignments" ON role_assignments;
DROP POLICY IF EXISTS "Admins can read all role assignments" ON role_assignments;

CREATE POLICY "Users can view role assignments"
  ON role_assignments
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles admin
      WHERE admin.id = auth.uid()
      AND admin.role = 'admin'
    )
  );