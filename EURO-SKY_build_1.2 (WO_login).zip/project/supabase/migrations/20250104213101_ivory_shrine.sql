-- Create MFA status enum if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type WHERE typname = 'mfa_status'
  ) THEN
    CREATE TYPE mfa_status AS ENUM ('pending', 'enrolled', 'disabled');
  END IF;
END $$;

-- Add MFA status columns to profiles if they don't exist
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS mfa_status mfa_status NOT NULL DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS mfa_verified boolean NOT NULL DEFAULT false;

-- Create function to update MFA status
CREATE OR REPLACE FUNCTION update_mfa_status()
RETURNS trigger AS $$
BEGIN
  -- When MFA is verified, update the status
  IF NEW.mfa_verified = true AND OLD.mfa_verified = false THEN
    NEW.mfa_status = 'enrolled';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for MFA status updates
DROP TRIGGER IF EXISTS trigger_update_mfa_status ON profiles;
CREATE TRIGGER trigger_update_mfa_status
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_mfa_status();

-- Update existing profiles to have proper MFA status
UPDATE profiles 
SET mfa_status = 'pending' 
WHERE mfa_status IS NULL;