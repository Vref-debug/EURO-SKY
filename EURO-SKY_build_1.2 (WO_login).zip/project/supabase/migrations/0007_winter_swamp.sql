/*
  # Add user roles and profile role column

  1. New Tables
    - `user_roles`: Stores available user roles
      - id: UUID primary key
      - role: Text, unique identifier for the role
      - description: Text, role description
      - created_at: Timestamp with timezone

  2. Changes
    - Add role column to profiles table
    - Add foreign key constraint to user_roles

  3. Security
    - Enable RLS
    - Allow authenticated users to read roles
*/

-- Create the table first
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text UNIQUE NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Add the description column explicitly if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_roles' AND column_name = 'description'
  ) THEN
    ALTER TABLE user_roles ADD COLUMN description text;
  END IF;
END $$;

-- Add role to profiles with foreign key reference
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'role'
  ) THEN
    ALTER TABLE profiles ADD COLUMN role text;
    ALTER TABLE profiles ADD CONSTRAINT fk_profiles_role 
      FOREIGN KEY (role) REFERENCES user_roles(role);
  END IF;
END $$;

-- Enable RLS
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Add read policy for authenticated users
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'user_roles' AND policyname = 'Anyone can read roles'
  ) THEN
    CREATE POLICY "Anyone can read roles"
      ON user_roles
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Insert default roles
INSERT INTO user_roles (role, description)
VALUES 
  ('pilot', 'Licensed pilot with flight privileges'),
  ('instructor', 'Flight instructor with teaching privileges'),
  ('maintenance', 'Maintenance staff member'),
  ('admin', 'Administrative staff member')
ON CONFLICT (role) DO UPDATE 
SET description = EXCLUDED.description;