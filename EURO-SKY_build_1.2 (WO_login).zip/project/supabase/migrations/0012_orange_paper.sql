/*
  # Create Aircraft_IDs table

  1. New Tables
    - `Aircraft_IDs`
      - `tail_number` (text, primary key) - Aircraft registration/tail number
      - `manufacturer` (text) - Aircraft manufacturer
      - `model` (text) - Aircraft model
      - `serial_number` (text, unique) - Aircraft serial number
      - `year_manufactured` (integer) - Year of manufacture
      - `created_at` (timestamptz) - Record creation timestamp
      - `updated_at` (timestamptz) - Record update timestamp

  2. Security
    - Enable RLS on `Aircraft_IDs` table
    - Add policies for authenticated users to:
      - Read aircraft data
      - Create/update aircraft data (admin and maintenance roles only)

  3. Triggers
    - Add trigger to automatically update `updated_at` timestamp
*/

-- Create Aircraft_IDs table
CREATE TABLE IF NOT EXISTS Aircraft_IDs (
  tail_number text PRIMARY KEY,
  manufacturer text NOT NULL,
  model text NOT NULL,
  serial_number text UNIQUE NOT NULL,
  year_manufactured integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE Aircraft_IDs ENABLE ROW LEVEL SECURITY;

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_Aircraft_IDs_updated_at
  BEFORE UPDATE ON Aircraft_IDs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add RLS Policies
-- Allow all authenticated users to read
CREATE POLICY "Allow authenticated read access"
  ON Aircraft_IDs
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow admin and maintenance roles to insert
CREATE POLICY "Allow admin and maintenance insert"
  ON Aircraft_IDs
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'maintenance', 'mechanic', 'inspector')
    )
  );

-- Allow admin and maintenance roles to update
CREATE POLICY "Allow admin and maintenance update"
  ON Aircraft_IDs
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'maintenance', 'mechanic', 'inspector')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role IN ('admin', 'maintenance', 'mechanic', 'inspector')
    )
  );