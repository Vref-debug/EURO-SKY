/*
  # Add MFA Status Tracking
  
  1. Changes
    - Add MFA status enum type
    - Add MFA status columns to profiles table
    - Set up default values and constraints
  
  2. Security
    - Maintain existing RLS policies
*/

-- Create the enum type first
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type WHERE typname = 'mfa_status_type'
  ) THEN
    CREATE TYPE mfa_status_type AS ENUM ('pending', 'enrolled', 'disabled');
  END IF;
END $$;

-- Add MFA status columns with temporary text type
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS mfa_status text,
ADD COLUMN IF NOT EXISTS mfa_verified boolean DEFAULT false;

-- Update existing rows to have a valid status before conversion
UPDATE profiles 
SET mfa_status = 'pending' 
WHERE mfa_status IS NULL;

-- Convert the column to use the enum type
ALTER TABLE profiles 
ALTER COLUMN mfa_status TYPE mfa_status_type 
USING mfa_status::mfa_status_type;

-- Set the default value after conversion
ALTER TABLE profiles 
ALTER COLUMN mfa_status SET DEFAULT 'pending'::mfa_status_type;