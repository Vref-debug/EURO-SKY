/*
  # Add user profile fields

  1. Changes
    - Add first_name column (required)
    - Add last_name column (required)
    - Add phone_number column (required)
    - Add company column (optional)

  2. Security
    - Maintain existing RLS policies
*/

ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS first_name text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS last_name text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS phone_number text NOT NULL DEFAULT '',
ADD COLUMN IF NOT EXISTS company text;