/*
  # Role Management System Update

  1. Changes
    - Drop existing policies if they exist
    - Create or update user_roles table
    - Create or update role_dashboards table
    - Set up proper RLS policies
    - Add role validation

  2. Security
    - Enable RLS on all tables
    - Add appropriate policies for role management
*/

-- Drop existing policy if it exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'user_roles' AND policyname = 'Anyone can read roles'
  ) THEN
    DROP POLICY "Anyone can read roles" ON user_roles;
  END IF;
END $$;

-- Create or update user_roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text UNIQUE NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on user_roles
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Create new read policy
CREATE POLICY "Anyone can read roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Insert default roles
INSERT INTO user_roles (role, description)
VALUES 
  ('pilot', 'Licensed pilot authorized to operate aircraft'),
  ('instructor', 'Certified flight instructor with teaching privileges'),
  ('mechanic', 'Aircraft maintenance technician with repair privileges'),
  ('inspector', 'Quality control inspector for maintenance operations'),
  ('manager', 'Maintenance operations manager'),
  ('scheduler', 'Maintenance scheduling coordinator'),
  ('student', 'Student pilot in training'),
  ('owner', 'Aircraft owner or operator'),
  ('admin', 'System administrator with full privileges')
ON CONFLICT (role) DO UPDATE 
SET description = EXCLUDED.description;

-- Create function to validate roles
CREATE OR REPLACE FUNCTION validate_user_role()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.role IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM user_roles WHERE role = NEW.role
  ) THEN
    RAISE EXCEPTION 'Invalid role: %', NEW.role;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for role validation
DROP TRIGGER IF EXISTS validate_role_trigger ON profiles;
CREATE TRIGGER validate_role_trigger
  BEFORE INSERT OR UPDATE OF role ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION validate_user_role();

-- Create role_dashboards table
CREATE TABLE IF NOT EXISTS role_dashboards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text REFERENCES user_roles(role) ON DELETE CASCADE,
  dashboard_path text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(role)
);

-- Enable RLS on role_dashboards
ALTER TABLE role_dashboards ENABLE ROW LEVEL SECURITY;

-- Create read policy for role_dashboards
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'role_dashboards' AND policyname = 'Allow authenticated read access'
  ) THEN
    DROP POLICY "Allow authenticated read access" ON role_dashboards;
  END IF;
END $$;

CREATE POLICY "Allow authenticated read access"
  ON role_dashboards
  FOR SELECT
  TO authenticated
  USING (true);

-- Insert dashboard routes
INSERT INTO role_dashboards (role, dashboard_path)
VALUES 
  ('pilot', '/pilot-dashboard'),
  ('instructor', '/instructor-dashboard'),
  ('mechanic', '/mechanic-dashboard'),
  ('inspector', '/inspector-dashboard'),
  ('manager', '/manager-dashboard'),
  ('scheduler', '/scheduler-dashboard'),
  ('student', '/student-dashboard'),
  ('owner', '/owner-dashboard'),
  ('admin', '/admin-dashboard')
ON CONFLICT (role) 
DO UPDATE SET dashboard_path = EXCLUDED.dashboard_path;