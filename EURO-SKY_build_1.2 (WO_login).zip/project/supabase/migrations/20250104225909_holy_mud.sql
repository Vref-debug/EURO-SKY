/*
  # Add Flight School Admin Role and Update User Roles

  1. Changes
    - Add 'flight-school-admin' role
    - Update existing roles
    - Update role_dashboards table
    
  2. Security
    - Maintain referential integrity with user_roles table
*/

-- First, clean up and insert all roles
TRUNCATE user_roles CASCADE;

INSERT INTO user_roles (role, description)
VALUES 
  ('pilot', 'Licensed pilot authorized to operate aircraft'),
  ('instructor', 'Certified flight instructor with teaching privileges'),
  ('mechanic', 'Aircraft maintenance technician with repair privileges'),
  ('inspector', 'Quality control inspector for maintenance operations'),
  ('manager', 'Maintenance operations manager'),
  ('scheduler', 'Maintenance scheduling coordinator'),
  ('owner', 'Aircraft owner or operator'),
  ('admin', 'System administrator with full privileges'),
  ('flight-school-admin', 'Flight school administrator with oversight of training operations');

-- Now that we have all roles, update the dashboard paths
INSERT INTO role_dashboards (role, dashboard_path)
VALUES 
  ('pilot', '/pilot-dashboard'),
  ('instructor', '/instructor-dashboard'),
  ('mechanic', '/mechanic-dashboard'),
  ('inspector', '/inspector-dashboard'),
  ('manager', '/manager-dashboard'),
  ('scheduler', '/scheduler-dashboard'),
  ('owner', '/owner-dashboard'),
  ('admin', '/admin-dashboard'),
  ('flight-school-admin', '/flight-school-admin-dashboard')
ON CONFLICT (role) 
DO UPDATE SET 
  dashboard_path = EXCLUDED.dashboard_path,
  updated_at = now();