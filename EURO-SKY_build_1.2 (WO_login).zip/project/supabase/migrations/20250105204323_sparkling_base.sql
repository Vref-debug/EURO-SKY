/*
  # Fix User Preferences Table

  1. Changes
    - Drop and recreate user_preferences table with proper constraints
    - Add ON CONFLICT handling for upsert operations
    - Update RLS policies
    - Add function to handle preference updates

  2. Security
    - Maintain RLS policies
    - Ensure users can only access their own preferences
*/

-- First drop existing table and its dependencies
DROP TABLE IF EXISTS user_preferences CASCADE;

-- Recreate user_preferences table with proper constraints
CREATE TABLE user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role text REFERENCES user_roles(role) ON DELETE CASCADE NOT NULL,
  default_dashboard text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT unique_user_role UNIQUE(user_id, role)
);

-- Enable RLS
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_user_preferences_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_user_preferences_timestamp
  BEFORE UPDATE ON user_preferences
  FOR EACH ROW
  EXECUTE FUNCTION update_user_preferences_timestamp();

-- Add RLS policies
CREATE POLICY "Users can view own preferences"
  ON user_preferences
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own preferences"
  ON user_preferences
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create function to safely update preferences
CREATE OR REPLACE FUNCTION update_user_preference(
  p_user_id uuid,
  p_role text,
  p_default_dashboard text
)
RETURNS user_preferences AS $$
DECLARE
  v_preference user_preferences;
BEGIN
  INSERT INTO user_preferences (user_id, role, default_dashboard)
  VALUES (p_user_id, p_role, p_default_dashboard)
  ON CONFLICT (user_id, role)
  DO UPDATE SET
    default_dashboard = EXCLUDED.default_dashboard,
    updated_at = now()
  RETURNING * INTO v_preference;
  
  RETURN v_preference;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;