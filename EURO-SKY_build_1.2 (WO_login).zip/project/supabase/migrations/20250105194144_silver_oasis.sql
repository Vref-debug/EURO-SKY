/*
  # Aircraft Search Implementation

  1. New Features
    - Adds search indexes for aircraft_ids table
    - Implements full text search capabilities
    - Creates secure search function for authenticated users

  2. Changes
    - Adds search vector column for full text search
    - Creates indexes for efficient searching
    - Adds search function with proper security

  3. Security
    - Maintains RLS policies
    - Restricts function access to authenticated users
*/

-- Add indexes for search performance
CREATE INDEX IF NOT EXISTS idx_aircraft_tail_number 
ON aircraft_ids (tail_number);

CREATE INDEX IF NOT EXISTS idx_aircraft_model 
ON aircraft_ids (model);

CREATE INDEX IF NOT EXISTS idx_aircraft_manufacturer_model 
ON aircraft_ids (manufacturer, model);

-- Add full text search capabilities
ALTER TABLE aircraft_ids 
ADD COLUMN IF NOT EXISTS search_vector tsvector 
GENERATED ALWAYS AS (
  to_tsvector('english', 
    coalesce(tail_number, '') || ' ' || 
    coalesce(manufacturer, '') || ' ' || 
    coalesce(model, '') || ' ' || 
    coalesce(serial_number, '')
  )
) STORED;

CREATE INDEX IF NOT EXISTS idx_aircraft_search 
ON aircraft_ids USING GIN (search_vector);

-- Function to search aircraft
CREATE OR REPLACE FUNCTION search_aircraft(search_term text)
RETURNS SETOF aircraft_ids AS $$
BEGIN
  RETURN QUERY
  SELECT *
  FROM aircraft_ids
  WHERE 
    search_vector @@ plainto_tsquery('english', search_term)
    OR tail_number ILIKE '%' || search_term || '%'
    OR manufacturer ILIKE '%' || search_term || '%'
    OR model ILIKE '%' || search_term || '%'
  ORDER BY tail_number ASC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant access to authenticated users
GRANT EXECUTE ON FUNCTION search_aircraft TO authenticated;