import { useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Aircraft } from '../types/aircraft';

export function useAircraftSearch() {
  const [results, setResults] = useState<Aircraft[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const searchAircraft = useCallback(async (searchTerm: string) => {
    if (!searchTerm.trim()) {
      setResults([]);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error } = await supabase
        .rpc('search_aircraft', {
          search_term: searchTerm.trim()
        });

      if (error) throw error;
      setResults(data || []);
    } catch (err) {
      console.error('Aircraft search error:', err);
      setError(err as Error);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    results,
    loading,
    error,
    searchAircraft
  };
}