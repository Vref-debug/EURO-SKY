import { useState, useEffect } from 'react';
import { RolesService } from '../lib/auth/roles.service';
import type { UserRole } from '../lib/auth/types';

export function useRoles() {
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const rolesService = RolesService.getInstance();

  useEffect(() => {
    async function fetchRoles() {
      try {
        const data = await rolesService.getRoles();
        setRoles(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchRoles();
  }, []);

  return { roles, loading, error };
}