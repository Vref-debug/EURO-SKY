import { useState } from 'react';
import { DummyAuthService } from '../lib/auth/dummyAuth.service';
import { useNavigate } from 'react-router-dom';

export function useRoleManagement() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const authService = DummyAuthService.getInstance();
  const navigate = useNavigate();

  const handleRoleChange = async (newRole: string) => {
    try {
      const updatedUser = await authService.switchRole(newRole);
      navigate(`/${newRole}-dashboard`);
      return updatedUser;
    } catch (error) {
      console.error('Role switch error:', error);
      throw error;
    }
  };

  return {
    isModalOpen,
    openModal: () => setIsModalOpen(true),
    closeModal: () => setIsModalOpen(false),
    handleRoleChange
  };
}