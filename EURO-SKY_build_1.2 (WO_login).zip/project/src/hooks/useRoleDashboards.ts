import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface Dashboard {
  name: string;
  path: string;
  isDefault?: boolean;
}

export function useRoleDashboards(role: string) {
  const [dashboards, setDashboards] = useState<Dashboard[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    async function fetchDashboards() {
      try {
        const { data, error } = await supabase
          .from('role_dashboards')
          .select('*')
          .eq('role', role);

        if (error) throw error;

        const formattedDashboards = data.map(d => ({
          name: formatDashboardName(d.dashboard_path),
          path: d.dashboard_path,
          isDefault: d.is_default
        }));

        setDashboards(formattedDashboards);
      } catch (err) {
        console.error('Error fetching dashboards:', err);
        setError(err as Error);
      } finally {
        setLoading(false);
      }
    }

    if (role) {
      fetchDashboards();
    }
  }, [role]);

  const setDefaultDashboard = async (dashboardPath: string) => {
    try {
      const { error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: (await supabase.auth.getUser()).data.user?.id,
          role,
          default_dashboard: dashboardPath
        });

      if (error) throw error;
    } catch (err) {
      console.error('Error setting default dashboard:', err);
      throw err;
    }
  };

  return {
    dashboards,
    loading,
    error,
    setDefaultDashboard
  };
}

function formatDashboardName(path: string): string {
  return path
    .split('/')
    .filter(Boolean)
    .map(part => part.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' '))
    .join(' - ');
}