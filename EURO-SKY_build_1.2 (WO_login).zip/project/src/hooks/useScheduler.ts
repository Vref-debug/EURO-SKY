import { useState, useEffect } from 'react';
import { getMechanics, getWorkOrders, assignMechanic } from '../lib/api/scheduler';
import type { Mechanic, MaintenanceSchedule } from '../types/scheduler';
import type { WorkOrder } from '../types/workOrder';
import toast from 'react-hot-toast';

export function useScheduler() {
  const [mechanics, setMechanics] = useState<Mechanic[]>([]);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchData() {
      try {
        const [mechanicsData, workOrdersData] = await Promise.all([
          getMechanics(),
          getWorkOrders()
        ]);
        setMechanics(mechanicsData);
        setWorkOrders(workOrdersData);
      } catch (err: any) {
        setError(err.message);
        toast.error('Failed to load scheduler data');
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  const handleAssignment = async (
    taskId: string,
    mechanicId: string,
    scheduledDate: string,
    scheduledTime: string
  ) => {
    try {
      await assignMechanic(taskId, mechanicId, scheduledDate, scheduledTime);
      toast.success('Task assigned successfully');
      
      // Refresh work orders to show updated assignment
      const updatedWorkOrders = await getWorkOrders();
      setWorkOrders(updatedWorkOrders);
    } catch (err: any) {
      toast.error('Failed to assign task');
      throw err;
    }
  };

  return {
    mechanics,
    workOrders,
    loading,
    error,
    assignTask: handleAssignment
  };
}