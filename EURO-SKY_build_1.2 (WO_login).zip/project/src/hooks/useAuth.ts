import { useState, useEffect } from 'react';
import type { User } from '../lib/auth/types';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [userRoles, setUserRoles] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for user in localStorage
    const storedUser = localStorage.getItem('dummyUser');
    if (storedUser) {
      const userData = JSON.parse(storedUser);
      setUser(userData);
      setUserRoles(userData.roles || []);
    }
    setLoading(false);

    // Listen for storage events (for multi-tab support)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'dummyUser') {
        if (e.newValue) {
          const userData = JSON.parse(e.newValue);
          setUser(userData);
          setUserRoles(userData.roles || []);
        } else {
          setUser(null);
          setUserRoles([]);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  return { user, userRoles, loading };
}