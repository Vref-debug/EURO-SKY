```typescript
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Aircraft } from '../types/aircraft';

export function useAircraftData() {
  const [aircraft, setAircraft] = useState<Aircraft[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    async function fetchAircraft() {
      try {
        const { data, error } = await supabase
          .from('aircraft_ids')
          .select('*')
          .order('tail_number');

        if (error) throw error;

        setAircraft(data || []);
      } catch (err) {
        console.error('Error fetching aircraft:', err);
        setError(err as Error);
      } finally {
        setLoading(false);
      }
    }

    fetchAircraft();
  }, []);

  return { aircraft, loading, error };
}
```