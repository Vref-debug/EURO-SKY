import { format, parse } from 'date-fns';

export function formatDate(date: Date | string): string {
  if (typeof date === 'string') {
    // Handle both formats: yyyy-MM-dd and dd/mm/yyyy
    const parsedDate = date.includes('-') 
      ? parse(date, 'yyyy-MM-dd', new Date())
      : parse(date, 'dd/MM/yyyy', new Date());
    return format(parsedDate, 'dd/MM/yyyy');
  }
  return format(date, 'dd/MM/yyyy');
}

export function isDateValid(dateString: string): boolean {
  const date = new Date(dateString);
  return date instanceof Date && !isNaN(date.getTime());
}

export function parseDate(dateString: string): Date {
  // Handle both formats
  return dateString.includes('-')
    ? parse(dateString, 'yyyy-MM-dd', new Date())
    : parse(dateString, 'dd/MM/yyyy', new Date());
}