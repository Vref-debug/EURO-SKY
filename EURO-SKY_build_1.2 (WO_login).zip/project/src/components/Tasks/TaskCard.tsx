import React from 'react';
import { Clock, User, Plane } from 'lucide-react';
import type { DetailedTask } from '../../types/task';

interface TaskCardProps {
  task: DetailedTask;
}

export function TaskCard({ task }: TaskCardProps) {
  const getStatusColor = () => {
    switch (task.status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = () => {
    switch (task.priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold">{task.title}</h3>
          <p className="text-gray-600">{task.description}</p>
        </div>
        <div className="flex space-x-2">
          <span className={`px-2 py-1 rounded-full text-sm font-medium ${getStatusColor()}`}>
            {task.status}
          </span>
          <span className={`px-2 py-1 rounded-full text-sm font-medium ${getPriorityColor()}`}>
            {task.priority}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="flex items-center space-x-2">
          <Plane className="w-4 h-4 text-gray-400" />
          <div>
            <p className="text-sm text-gray-500">Aircraft</p>
            <p className="font-medium">{task.aircraftInfo.registration}</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Clock className="w-4 h-4 text-gray-400" />
          <div>
            <p className="text-sm text-gray-500">Timeline</p>
            <p className="font-medium">
              {task.startDate} - {task.endDate}
            </p>
          </div>
        </div>

        {task.assignedTo && (
          <div className="flex items-center space-x-2">
            <User className="w-4 h-4 text-gray-400" />
            <div>
              <p className="text-sm text-gray-500">Assigned to</p>
              <p className="font-medium">{task.assignedTo.name}</p>
              <p className="text-sm text-gray-500">{task.assignedTo.role}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}