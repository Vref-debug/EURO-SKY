import React from 'react';
import { ArrowUpDown } from 'lucide-react';
import type { SortField, SortDirection } from '../../types/task';

interface TaskSortProps {
  field: SortField;
  direction: SortDirection;
  onSortChange: (field: SortField, direction: SortDirection) => void;
}

export function TaskSort({ field, direction, onSortChange }: TaskSortProps) {
  const handleSortChange = (newField: SortField) => {
    const newDirection = newField === field
      ? direction === 'asc' ? 'desc' : 'asc'
      : 'desc';
    onSortChange(newField, newDirection);
  };

  return (
    <div className="flex items-center space-x-4">
      <span className="text-sm text-gray-500">Sort by:</span>
      <div className="flex items-center space-x-2">
        {(['priority', 'startDate', 'status', 'aircraft'] as SortField[]).map((sortField) => (
          <button
            key={sortField}
            onClick={() => handleSortChange(sortField)}
            className={`flex items-center space-x-1 px-3 py-1 rounded-md text-sm ${
              field === sortField
                ? 'bg-sky-100 text-sky-800'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <span>{sortField}</span>
            {field === sortField && (
              <ArrowUpDown className="w-4 h-4" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}