import React, { useState } from 'react';
import { TaskList } from './TaskList';
import { TaskFilters } from './TaskFilters';
import { TaskSort } from './TaskSort';
import type { DetailedTask, TaskFilter, SortField, SortDirection } from '../../types/task';

interface TaskOverviewProps {
  workOrderId: string;
  tasks: DetailedTask[];
}

export function TaskOverview({ workOrderId, tasks }: TaskOverviewProps) {
  const [filters, setFilters] = useState<TaskFilter>({
    aircraft: [],
    status: [],
    priority: [],
    assignedTo: []
  });
  const [sortField, setSortField] = useState<SortField>('priority');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  const filteredTasks = tasks.filter(task => {
    if (filters.aircraft.length && !filters.aircraft.includes(task.aircraftInfo.registration)) {
      return false;
    }
    if (filters.status.length && !filters.status.includes(task.status)) {
      return false;
    }
    if (filters.priority.length && !filters.priority.includes(task.priority)) {
      return false;
    }
    if (filters.assignedTo.length && !task.assignedTo?.id) {
      return false;
    }
    return true;
  });

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    const direction = sortDirection === 'asc' ? 1 : -1;
    switch (sortField) {
      case 'priority':
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        return (priorityOrder[a.priority] - priorityOrder[b.priority]) * direction;
      case 'startDate':
        return (new Date(a.startDate).getTime() - new Date(b.startDate).getTime()) * direction;
      case 'status':
        const statusOrder = { pending: 0, 'in-progress': 1, completed: 2 };
        return (statusOrder[a.status] - statusOrder[b.status]) * direction;
      case 'aircraft':
        return a.aircraftInfo.registration.localeCompare(b.aircraftInfo.registration) * direction;
      default:
        return 0;
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <TaskFilters
          filters={filters}
          onFilterChange={setFilters}
          tasks={tasks}
        />
        <TaskSort
          field={sortField}
          direction={sortDirection}
          onSortChange={(field, direction) => {
            setSortField(field);
            setSortDirection(direction);
          }}
        />
      </div>
      <TaskList tasks={sortedTasks} />
    </div>
  );
}