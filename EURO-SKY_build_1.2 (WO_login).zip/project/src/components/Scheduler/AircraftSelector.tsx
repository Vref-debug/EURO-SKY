import React, { useState, useEffect } from 'react';
import { Plane, Search, Loader2, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAircraftSearch } from '../../hooks/useAircraftSearch';
import type { Aircraft } from '../../types/aircraft';

interface AircraftSelectorProps {
  onSelect: (aircraft: Aircraft | null) => void;
  selectedAircraft: Aircraft | null;
  showCreateWorkOrder?: boolean;
}

export function AircraftSelector({ onSelect, selectedAircraft, showCreateWorkOrder = false }: AircraftSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const { results, loading, error, searchAircraft } = useAircraftSearch();

  useEffect(() => {
    if (searchTerm.trim()) {
      searchAircraft(searchTerm);
    }
  }, [searchTerm, searchAircraft]);

  const handleAircraftSelect = (aircraft: Aircraft) => {
    onSelect(aircraft);
    setIsOpen(false);
    setSearchTerm('');
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <div 
          onClick={() => setIsOpen(true)}
          className={`cursor-pointer flex items-center justify-between px-4 py-2 border rounded-lg ${
            selectedAircraft 
              ? 'border-sky-300 bg-sky-50' 
              : 'border-gray-300 hover:border-sky-300 hover:bg-sky-50'
          }`}
        >
          <div className="flex items-center">
            <Plane className={`w-5 h-5 mr-2 ${selectedAircraft ? 'text-sky-600' : 'text-gray-400'}`} />
            {selectedAircraft ? (
              <div className="text-left">
                <div className="font-medium text-sky-900">{selectedAircraft.tail_number}</div>
                <div className="text-sm text-sky-700">
                  {selectedAircraft.manufacturer} {selectedAircraft.model}
                </div>
              </div>
            ) : (
              <span className="text-gray-500">Select Aircraft</span>
            )}
          </div>
          {selectedAircraft && (
            <div className="flex items-center space-x-2">
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  onSelect(null);
                }}
                className="text-sky-600 hover:text-sky-800 px-2 py-1 rounded"
              >
                Clear
              </div>
            </div>
          )}
        </div>

        {isOpen && (
          <div className="absolute z-50 w-full mt-1 bg-white rounded-lg shadow-lg border border-gray-200">
            <div className="p-2 border-b">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                  placeholder="Search by tail number..."
                  autoFocus
                />
              </div>
            </div>

            <div className="max-h-60 overflow-y-auto">
              {loading ? (
                <div className="p-4 text-center">
                  <Loader2 className="w-6 h-6 animate-spin text-sky-600 mx-auto" />
                  <p className="mt-2 text-sm text-gray-600">Searching aircraft...</p>
                </div>
              ) : error ? (
                <div className="p-4 text-center text-red-600">
                  <p>Error searching aircraft. Please try again.</p>
                </div>
              ) : results.length > 0 ? (
                <div className="py-2">
                  {results.map((aircraft) => (
                    <div
                      key={aircraft.tail_number}
                      onClick={() => handleAircraftSelect(aircraft)}
                      className="px-4 py-2 hover:bg-sky-50 cursor-pointer"
                    >
                      <div className="font-medium">{aircraft.tail_number}</div>
                      <div className="text-sm text-gray-600">
                        {aircraft.manufacturer} {aircraft.model}
                      </div>
                    </div>
                  ))}
                </div>
              ) : searchTerm ? (
                <div className="p-4 text-center text-gray-500">
                  No aircraft found
                </div>
              ) : null}
            </div>
          </div>
        )}
      </div>

      {showCreateWorkOrder && (
        <Link
          to="/work-orders/create"
          className="w-full flex items-center justify-center space-x-2 bg-sky-600 text-white px-4 py-2 rounded-lg hover:bg-sky-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Create Work Order</span>
        </Link>
      )}
    </div>
  );
}