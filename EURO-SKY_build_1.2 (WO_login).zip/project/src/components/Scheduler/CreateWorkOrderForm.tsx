```tsx
import React, { useState } from 'react';
import { AircraftSelector } from './AircraftSelector';
import type { Aircraft } from '../../types/aircraft';

export function CreateWorkOrderForm() {
  const [selectedAircraft, setSelectedAircraft] = useState<Aircraft | null>(null);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-lg font-semibold mb-4">Create Work Order</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Aircraft
          </label>
          <AircraftSelector
            selectedAircraft={selectedAircraft}
            onSelect={setSelectedAircraft}
          />
        </div>

        {/* Additional form fields will go here */}
      </div>
    </div>
  );
}