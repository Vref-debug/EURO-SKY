import React, { useState } from 'react';
import { Calendar, Clock } from 'lucide-react';
import type { MaintenanceSchedule, ScheduledTask } from '../../types/scheduler';

interface SchedulerCalendarProps {
  schedules: MaintenanceSchedule[];
  onSlotSelect: (date: string, time: string) => void;
}

export function SchedulerCalendar({ schedules, onSlotSelect }: SchedulerCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const timeSlots = Array.from({ length: 9 }, (_, i) => {
    const hour = i + 8; // 8 AM to 5 PM
    return `${hour.toString().padStart(2, '0')}:00`;
  });

  const isSlotAvailable = (date: string, time: string) => {
    return !schedules.some(schedule => 
      schedule.tasks.some(task => 
        task.scheduledDate === date && 
        task.scheduledTime === time
      )
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold">Schedule Tasks</h2>
        <div className="flex items-center space-x-2">
          <Calendar className="w-5 h-5 text-gray-400" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="border-gray-300 rounded-md shadow-sm focus:ring-sky-500 focus:border-sky-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-2">
        {timeSlots.map((time) => (
          <button
            key={time}
            onClick={() => onSlotSelect(selectedDate, time)}
            disabled={!isSlotAvailable(selectedDate, time)}
            className={`flex items-center space-x-3 p-3 rounded-lg border ${
              isSlotAvailable(selectedDate, time)
                ? 'hover:bg-sky-50 border-gray-200'
                : 'bg-gray-50 border-gray-200 cursor-not-allowed'
            }`}
          >
            <Clock className="w-4 h-4 text-gray-400" />
            <span className="text-sm">
              {time}
            </span>
            {!isSlotAvailable(selectedDate, time) && (
              <span className="text-xs text-gray-500 ml-2">
                (Booked)
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}