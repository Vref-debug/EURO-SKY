import React, { useState } from 'react';
import { DashboardLayout } from '../DashboardLayout';
import { SchedulerCalendar } from './SchedulerCalendar';
import { MechanicAssignment } from './MechanicAssignment';
import { WorkOrderSelection } from './WorkOrderSelection';
import { useScheduler } from '../../hooks/useScheduler';
import { Loader2 } from 'lucide-react';

export function SchedulerDashboard() {
  const { mechanics, workOrders, loading, error, assignTask } = useScheduler();
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [selectedWorkOrder, setSelectedWorkOrder] = useState<string>('');

  const handleSlotSelect = (date: string, time: string) => {
    setSelectedDate(date);
    setSelectedTime(time);
  };

  const handleMechanicAssign = async (mechanicId: string) => {
    if (!selectedWorkOrder || !selectedDate || !selectedTime) {
      return;
    }

    try {
      await assignTask(selectedWorkOrder, mechanicId, selectedDate, selectedTime);
      // Reset selections after successful assignment
      setSelectedWorkOrder('');
      setSelectedDate('');
      setSelectedTime('');
    } catch (err) {
      console.error('Assignment failed:', err);
    }
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="w-8 h-8 animate-spin text-sky-600 mx-auto" />
            <p className="mt-2 text-gray-600">Loading scheduler...</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  if (error) {
    return (
      <DashboardLayout>
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center text-red-600">
            <p>Failed to load scheduler: {error}</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Maintenance Scheduler</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-8">
              <WorkOrderSelection
                workOrders={workOrders}
                selectedWorkOrder={selectedWorkOrder}
                onSelect={setSelectedWorkOrder}
              />
              <SchedulerCalendar
                schedules={[]}
                onSlotSelect={handleSlotSelect}
              />
            </div>
            {selectedDate && selectedTime && selectedWorkOrder && (
              <MechanicAssignment
                mechanics={mechanics}
                selectedDate={selectedDate}
                selectedTime={selectedTime}
                onAssign={handleMechanicAssign}
              />
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}