import React, { useState } from 'react';
import { X, AlertCircle, CheckCircle, Settings } from 'lucide-react';
import { formatRole } from '../../utils/textUtils';
import { DashboardPreferenceModal } from './DashboardPreferenceModal';
import toast from 'react-hot-toast';

interface RoleManagementModalProps {
  currentRole: string;
  availableRoles: string[];
  onRoleChange: (role: string) => void;
  onClose: () => void;
}

export function RoleManagementModal({
  currentRole,
  availableRoles,
  onRoleChange,
  onClose
}: RoleManagementModalProps) {
  const [selectedRole, setSelectedRole] = useState(currentRole);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);

  const handleRoleSelect = (role: string) => {
    if (role !== currentRole) {
      setSelectedRole(role);
      setShowConfirmation(true);
    }
  };

  const handleConfirm = async () => {
    try {
      await onRoleChange(selectedRole);
      toast.success(`Role switched to ${formatRole(selectedRole)}`);
      onClose();
    } catch (error) {
      toast.error('Failed to switch role. Please try again.');
    }
  };

  if (showPreferences) {
    return (
      <DashboardPreferenceModal
        currentRole={currentRole}
        onClose={() => setShowPreferences(false)}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-lg font-semibold">Your Roles</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!showConfirmation ? (
          <div className="p-4">
            <p className="text-sm text-gray-600 mb-4">
              You have access to the following roles. Select a role to switch to it or configure your preferences.
            </p>
            <div className="space-y-3">
              {availableRoles.map((role) => (
                <div
                  key={role}
                  className={`flex items-center justify-between p-3 rounded-lg border ${
                    role === currentRole
                      ? 'border-sky-200 bg-sky-50'
                      : 'border-gray-200 hover:bg-sky-50/50'
                  }`}
                >
                  <div>
                    <div className="font-medium text-gray-900">{formatRole(role)}</div>
                    {role === currentRole && (
                      <div className="text-sm text-sky-600">Current role</div>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    {role === currentRole && (
                      <button
                        onClick={() => setShowPreferences(true)}
                        className="p-2 text-sky-600 hover:bg-sky-100 rounded-lg"
                        title="Dashboard Preferences"
                      >
                        <Settings className="w-5 h-5" />
                      </button>
                    )}
                    {role === currentRole ? (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-sm font-medium bg-sky-100 text-sky-800">
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Active
                      </span>
                    ) : (
                      <button
                        onClick={() => handleRoleSelect(role)}
                        className="text-sky-600 hover:text-sky-800 font-medium"
                      >
                        Switch to this role
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-4">
            <div className="flex items-start space-x-3 mb-4">
              <AlertCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-gray-900">Confirm Role Switch</h4>
                <p className="text-sm text-gray-600 mt-1">
                  Are you sure you want to switch from {formatRole(currentRole)} to {formatRole(selectedRole)}?
                </p>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowConfirmation(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirm}
                className="px-4 py-2 bg-sky-600 text-white rounded-lg hover:bg-sky-700"
              >
                Confirm Switch
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}