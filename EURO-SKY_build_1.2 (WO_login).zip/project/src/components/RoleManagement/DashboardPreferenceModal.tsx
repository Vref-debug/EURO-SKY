import React, { useState } from 'react';
import { X, Settings } from 'lucide-react';
import { formatRole } from '../../utils/textUtils';
import toast from 'react-hot-toast';
import { useRoleDashboards } from '../../hooks/useRoleDashboards';

interface DashboardPreferenceModalProps {
  currentRole: string;
  onClose: () => void;
}

export function DashboardPreferenceModal({ currentRole, onClose }: DashboardPreferenceModalProps) {
  const { dashboards, loading, error, setDefaultDashboard } = useRoleDashboards(currentRole);
  const [selectedDashboard, setSelectedDashboard] = useState('');

  const handleSave = async () => {
    try {
      await setDefaultDashboard(selectedDashboard);
      toast.success('Default dashboard updated successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to update default dashboard');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-sky-600" />
            <h3 className="text-lg font-semibold">Dashboard Preferences</h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4">
          <p className="text-sm text-gray-600 mb-4">
            Select your default dashboard for the {formatRole(currentRole)} role.
            This is where you'll land after logging in.
          </p>

          {loading ? (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-600 mx-auto"></div>
              <p className="mt-2 text-sm text-gray-600">Loading dashboards...</p>
            </div>
          ) : error ? (
            <div className="text-center text-red-600 py-4">
              <p>Failed to load dashboards</p>
            </div>
          ) : (
            <div className="space-y-3">
              {dashboards.map((dashboard) => (
                <label
                  key={dashboard.path}
                  className="flex items-center p-3 rounded-lg border cursor-pointer hover:bg-sky-50"
                >
                  <input
                    type="radio"
                    name="dashboard"
                    value={dashboard.path}
                    checked={selectedDashboard === dashboard.path}
                    onChange={(e) => setSelectedDashboard(e.target.value)}
                    className="h-4 w-4 text-sky-600 focus:ring-sky-500"
                  />
                  <span className="ml-3">{dashboard.name}</span>
                </label>
              ))}
            </div>
          )}

          <div className="mt-6 flex justify-end space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={!selectedDashboard || loading}
              className="px-4 py-2 bg-sky-600 text-white rounded-lg hover:bg-sky-700 disabled:opacity-50"
            >
              Save Preference
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}