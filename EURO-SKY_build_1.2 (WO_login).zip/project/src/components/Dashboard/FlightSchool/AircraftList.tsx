import React from 'react';
import { AircraftStatusCard } from './AircraftStatusCard';
import type { AircraftStatus } from '../../../types/aircraft';

interface AircraftListProps {
  aircraft: AircraftStatus[];
}

export function AircraftList({ aircraft }: AircraftListProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {aircraft.map((aircraft) => (
        <AircraftStatusCard
          key={aircraft.registration}
          aircraft={aircraft}
        />
      ))}
    </div>
  );
}