import React from 'react';
import { Calendar, CheckCircle } from 'lucide-react';

const activities = [
  {
    id: 1,
    type: 'Inspection',
    date: '2024-03-15',
    status: 'Completed',
    description: '100-hour inspection'
  },
  {
    id: 2,
    type: 'Maintenance',
    date: '2024-03-01',
    status: 'Completed',
    description: 'Oil change'
  }
];

export function RecentActivity() {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
        <Calendar className="w-5 h-5 text-sky-600" />
      </div>
      
      <div className="space-y-4">
        {activities.map(activity => (
          <div 
            key={activity.id}
            className="border-l-4 border-sky-500 pl-4 py-2"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-gray-500">{activity.date}</span>
              <div className="flex items-center space-x-1">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm text-green-600">{activity.status}</span>
              </div>
            </div>
            <h4 className="font-medium">{activity.type}</h4>
            <p className="text-sm text-gray-600">{activity.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}