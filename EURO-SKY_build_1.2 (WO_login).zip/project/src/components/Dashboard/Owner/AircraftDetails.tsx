import React from 'react';
import { Plane } from 'lucide-react';

interface AircraftDetailsProps {
  registration: string;
  type: string;
  serialNumber: string;
  yearManufactured: number;
}

export function AircraftDetails({ registration, type, serialNumber, yearManufactured }: AircraftDetailsProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Aircraft Details</h2>
        <Plane className="w-6 h-6 text-sky-600" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-gray-600">Registration</p>
          <p className="text-lg font-semibold">{registration}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Type</p>
          <p className="text-lg font-semibold">{type}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Serial Number</p>
          <p className="text-lg font-semibold">{serialNumber}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Year</p>
          <p className="text-lg font-semibold">{yearManufactured}</p>
        </div>
      </div>
    </div>
  );
}