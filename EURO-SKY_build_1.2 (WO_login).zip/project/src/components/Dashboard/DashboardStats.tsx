import React, { useState } from 'react';
import { Clock, AlertCircle } from 'lucide-react';
import { AircraftInfo } from './AircraftInfo';
import { FlightHoursInfo } from './FlightHoursInfo';
import { FlightHoursUpdate } from './FlightHoursUpdate';

export function DashboardStats() {
  const [totalHours, setTotalHours] = useState(1234.5);
  const [lastUpdated, setLastUpdated] = useState("15/03/2024");

  const handleFlightHoursUpdate = (hours: number, date: string) => {
    setTotalHours(prev => prev + hours);
    setLastUpdated(date);
  };

  return (
    <div className="space-y-6">
      <AircraftInfo registration="OO-ABC" type="C172S" />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <FlightHoursInfo 
          totalHours={totalHours}
          lastUpdated={lastUpdated}
        />

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Next Service</h3>
            <Clock className="w-6 h-6 text-sky-600" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Due Date</span>
              <span className="font-semibold">15/04/2024</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Hours Remaining</span>
              <span className="font-semibold text-yellow-600">48.5</span>
            </div>
          </div>
        </div>

        <FlightHoursUpdate
          lastUpdated={lastUpdated}
          onUpdate={handleFlightHoursUpdate}
        />
      </div>
    </div>
  );
}