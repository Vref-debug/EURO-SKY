import React from 'react';
import { useNavigate } from 'react-router-dom';
import type { WorkOrder } from '../../types/workOrder';

interface MechanicWorkOrderListProps {
  workOrders: WorkOrder[];
}

export function MechanicWorkOrderList({ workOrders }: MechanicWorkOrderListProps) {
  const navigate = useNavigate();
  
  // Group work orders by aircraft registration
  const groupedOrders = workOrders.reduce((acc, order) => {
    if (!acc[order.aircraftRegistration]) {
      acc[order.aircraftRegistration] = [];
    }
    acc[order.aircraftRegistration].push(order);
    return acc;
  }, {} as Record<string, WorkOrder[]>);

  const getCompletedTasksToday = (tasks: WorkOrder['tasks']) => {
    const today = new Date().toLocaleDateString('en-GB');
    return tasks.filter(task => 
      task.status === 'completed' && 
      task.dueDate === today
    ).length;
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm text-left">
        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
          <tr>
            <th className="px-6 py-3">Aircraft Registration</th>
            <th className="px-6 py-3">Work Order</th>
            <th className="px-6 py-3 text-center">Total Tasks</th>
            <th className="px-6 py-3 text-center">Tasks Completed Today</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(groupedOrders).map(([registration, orders]) => (
            <React.Fragment key={registration}>
              {orders.map((order, index) => (
                <tr key={order.id} className="bg-white border-b hover:bg-gray-50">
                  {index === 0 && (
                    <td 
                      className="px-6 py-4 font-medium text-gray-900"
                      rowSpan={orders.length}
                    >
                      {registration}
                    </td>
                  )}
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      <div className="font-medium">{order.id}</div>
                      <div className="text-sm text-gray-500">{order.description}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button
                      onClick={() => navigate(`/work-orders/${order.id}/tasks`)}
                      className="text-sky-600 hover:text-sky-800 font-medium"
                    >
                      {order.tasks.length}
                    </button>
                  </td>
                  <td className="px-6 py-4 text-center">
                    {getCompletedTasksToday(order.tasks)}
                  </td>
                </tr>
              ))}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}