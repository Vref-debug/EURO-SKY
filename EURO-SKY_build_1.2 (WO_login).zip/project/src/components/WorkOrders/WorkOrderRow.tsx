import React from 'react';
import { AlertCircle, CheckCircle, Clock } from 'lucide-react';
import type { WorkOrder, Task } from '../../types/workOrder';

interface WorkOrderRowProps {
  workOrder: WorkOrder;
  onTaskClick: (task: Task) => void;
}

export function WorkOrderRow({ workOrder, onTaskClick }: WorkOrderRowProps) {
  const getStatusIcon = () => {
    switch (workOrder.status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'in-progress':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-red-500" />;
    }
  };

  const getPriorityClass = () => {
    switch (workOrder.priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
    }
  };

  const groupedTasks = workOrder.tasks.reduce((acc, task) => {
    if (!acc[task.type]) {
      acc[task.type] = [];
    }
    acc[task.type].push(task);
    return acc;
  }, {} as Record<string, Task[]>);

  return (
    <tr className="bg-white border-b hover:bg-gray-50">
      <td className="px-6 py-4 font-medium text-gray-900">
        {workOrder.aircraftRegistration}
      </td>
      <td className="px-6 py-4">
        <div className="space-y-1">
          <div className="font-medium">{workOrder.id}</div>
          <div className="text-sm text-gray-500">{workOrder.description}</div>
          <span className={`text-xs px-2 py-1 rounded-full ${getPriorityClass()}`}>
            {workOrder.priority}
          </span>
        </div>
      </td>
      <td className="px-6 py-4">
        <span className="font-medium">{workOrder.tasks.length} tasks</span>
      </td>
      <td className="px-6 py-4">
        <div className="flex items-center space-x-2">
          {getStatusIcon()}
          <span className="capitalize">{workOrder.status}</span>
        </div>
      </td>
      <td className="px-6 py-4">
        <div className="space-y-2">
          {Object.entries(groupedTasks).map(([type, tasks]) => (
            <div key={type} className="space-y-1">
              <div className="text-xs font-medium text-gray-500 uppercase">
                {type}
              </div>
              {tasks.map((task) => (
                <button
                  key={task.id}
                  onClick={() => onTaskClick(task)}
                  className="block text-sm text-sky-600 hover:text-sky-800"
                >
                  {task.description}
                </button>
              ))}
            </div>
          ))}
        </div>
      </td>
    </tr>
  );
}