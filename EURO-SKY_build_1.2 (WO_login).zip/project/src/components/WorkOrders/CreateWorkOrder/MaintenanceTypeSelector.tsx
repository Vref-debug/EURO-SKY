import React from 'react';
import { Wrench, Clock, AlertTriangle, CheckSquare, AlertOctagon } from 'lucide-react';

interface MaintenanceTypeSelectorProps {
  selectedType: string;
  onSelect: (type: string) => void;
}

export function MaintenanceTypeSelector({ selectedType, onSelect }: MaintenanceTypeSelectorProps) {
  const maintenanceTypes = [
    {
      id: 'corrective',
      title: 'Corrective Maintenance',
      description: 'For immediate repairs of broken or malfunctioning equipment',
      icon: Wrench,
      priority: 'high'
    },
    {
      id: 'preventive',
      title: 'Preventive Maintenance',
      description: 'For scheduled, routine inspections and maintenance',
      icon: Clock,
      priority: 'medium'
    },
    {
      id: 'predictive',
      title: 'Predictive Maintenance',
      description: 'Based on equipment condition monitoring',
      icon: AlertTriangle,
      priority: 'medium'
    },
    {
      id: 'emergency',
      title: 'Emergency Maintenance',
      description: 'For critical issues requiring immediate attention',
      icon: AlertOctagon,
      priority: 'high'
    },
    {
      id: 'routine',
      title: 'Routine Maintenance',
      description: 'For regular, non-urgent upkeep tasks',
      icon: CheckSquare,
      priority: 'low'
    }
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Select Maintenance Type</h3>
      <div className="grid grid-cols-1 gap-4">
        {maintenanceTypes.map((type) => {
          const Icon = type.icon;
          const isSelected = selectedType === type.id;
          
          return (
            <button
              key={type.id}
              onClick={() => onSelect(type.id)}
              className={`flex items-start p-4 rounded-lg border-2 transition-colors ${
                isSelected 
                  ? 'border-sky-500 bg-sky-50'
                  : 'border-gray-200 hover:border-sky-200 hover:bg-sky-50/50'
              }`}
            >
              <div className="flex-shrink-0 mt-1">
                <Icon className={`w-6 h-6 ${
                  isSelected ? 'text-sky-600' : 'text-gray-400'
                }`} />
              </div>
              <div className="ml-4 text-left">
                <div className="flex items-center space-x-2">
                  <h4 className="font-medium text-gray-900">{type.title}</h4>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    type.priority === 'high'
                      ? 'bg-red-100 text-red-800'
                      : type.priority === 'medium'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {type.priority}
                  </span>
                </div>
                <p className="mt-1 text-sm text-gray-600">{type.description}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}