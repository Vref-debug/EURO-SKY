import React from 'react';
import { Plane } from 'lucide-react';

interface CreateWorkOrderHeaderProps {
  workOrderId: string;
  createdBy: string;
  createdAt: string;
}

export function CreateWorkOrderHeader({ workOrderId, createdBy, createdAt }: CreateWorkOrderHeaderProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex flex-col items-center mb-6">
        <Plane className="w-12 h-12 text-sky-600 mb-2" />
        <h1 className="text-2xl font-bold text-center">Euro-Sky BV</h1>
        <p className="text-gray-600 text-center">CAO EASA Approval: BE.CAO.0004</p>
      </div>
      
      <div className="flex justify-end space-y-1">
        <div className="text-right">
          <p className="text-sm text-gray-600">Work Order ID: <span className="font-semibold">{workOrderId}</span></p>
          <p className="text-sm text-gray-600">Created by: {createdBy}</p>
          <p className="text-sm text-gray-600">Date: {createdAt}</p>
        </div>
      </div>
    </div>
  );
}