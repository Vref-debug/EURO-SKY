```tsx
import React, { useState, useEffect } from 'react';
import { Plane, Search, Loader2 } from 'lucide-react';
import { useAircraftData } from '../../../../hooks/useAircraftData';
import { AircraftDropdown } from './AircraftDropdown';
import { SelectedAircraft } from './SelectedAircraft';
import type { Aircraft } from '../../../../types/aircraft';

interface AircraftSelectorProps {
  onSelect: (aircraft: Aircraft | null) => void;
  selectedAircraft: Aircraft | null;
}

export function AircraftSelector({ onSelect, selectedAircraft }: AircraftSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { aircraft, loading, error } = useAircraftData();

  const filteredAircraft = aircraft.filter(a => 
    a.tail_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.model.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelect = (aircraft: Aircraft) => {
    onSelect(aircraft);
    setIsOpen(false);
    setSearchQuery('');
  };

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-600">Failed to load aircraft data</p>
      </div>
    );
  }

  return (
    <div className="relative">
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Aircraft
      </label>

      {selectedAircraft ? (
        <SelectedAircraft
          aircraft={selectedAircraft}
          onClear={() => onSelect(null)}
          onClick={() => setIsOpen(true)}
        />
      ) : (
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="w-full flex items-center justify-between px-4 py-2 border border-gray-300 rounded-lg bg-white hover:bg-gray-50"
        >
          <div className="flex items-center text-gray-500">
            <Plane className="w-5 h-5 mr-2" />
            <span>Select an aircraft</span>
          </div>
        </button>
      )}

      {isOpen && (
        <AircraftDropdown
          loading={loading}
          aircraft={filteredAircraft}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onSelect={handleSelect}
          onClose={() => setIsOpen(false)}
        />
      )}
    </div>
  );
}
```