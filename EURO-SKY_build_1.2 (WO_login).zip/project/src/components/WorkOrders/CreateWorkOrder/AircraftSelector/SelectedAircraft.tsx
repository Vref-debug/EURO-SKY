```tsx
import React from 'react';
import { Plane, X } from 'lucide-react';
import type { Aircraft } from '../../../../types/aircraft';

interface SelectedAircraftProps {
  aircraft: Aircraft;
  onClear: () => void;
  onClick: () => void;
}

export function SelectedAircraft({ aircraft, onClear, onClick }: SelectedAircraftProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full flex items-center justify-between px-4 py-2 border border-sky-300 rounded-lg bg-sky-50 hover:bg-sky-100"
    >
      <div className="flex items-center">
        <Plane className="w-5 h-5 text-sky-600 mr-2" />
        <div className="text-left">
          <div className="font-medium text-sky-900">{aircraft.tail_number}</div>
          <div className="text-sm text-sky-700">
            {aircraft.manufacturer} {aircraft.model}
          </div>
        </div>
      </div>
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onClear();
        }}
        className="p-1 hover:bg-sky-200 rounded-full"
      >
        <X className="w-4 h-4 text-sky-600" />
      </button>
    </button>
  );
}
```