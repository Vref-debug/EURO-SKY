import React, { useState } from 'react';
import { AuthForm } from './AuthForm';
import { RoleSelection } from './RoleSelection';
import { EmailVerification } from './EmailVerification';
import { useAuth } from '../../hooks/useAuth';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';

interface AuthStepsProps {
  onComplete: () => void;
}

export function AuthSteps({ onComplete }: AuthStepsProps) {
  const [step, setStep] = useState<'auth' | 'role' | 'verify'>('auth');
  const { user } = useAuth();

  const handleAuthComplete = async () => {
    if (!user?.id) {
      toast.error('Authentication failed. Please try again.');
      return;
    }

    try {
      // Check if user already has a role
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .maybeSingle(); // Use maybeSingle instead of single to handle no results

      if (error) throw error;

      if (profile?.role) {
        setStep('verify');
      } else {
        setStep('role');
      }
    } catch (err: any) {
      console.error('Profile check error:', err);
      // If we can't check the profile, default to role selection
      setStep('role');
    }
  };

  const handleRoleSelect = async (role: string) => {
    if (!user?.id) {
      toast.error('Session expired. Please log in again.');
      setStep('auth');
      return;
    }

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role })
        .eq('id', user.id);

      if (error) throw error;
      
      toast.success('Role selected successfully');
      setStep('verify');
    } catch (err: any) {
      console.error('Role selection error:', err);
      toast.error('Failed to set role. Please try again.');
    }
  };

  const handleVerificationComplete = () => {
    onComplete();
  };

  switch (step) {
    case 'role':
      return <RoleSelection onSelect={handleRoleSelect} />;
    case 'verify':
      return user ? (
        <EmailVerification 
          email={user.email} 
          onComplete={handleVerificationComplete} 
        />
      ) : null;
    default:
      return <AuthForm onComplete={handleAuthComplete} />;
  }
}