import React, { useState } from 'react';
import { Mail, Shield, Loader2 } from 'lucide-react';
import { AuthService } from '../../lib/auth/auth.service';
import { validateSignIn } from '../../lib/auth/validation';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';
import { SignUpForm } from './SignUpForm';
import { TOTPVerification } from './TOTPVerification';

interface AuthFormProps {
  onComplete: () => void;
}

export function AuthForm({ onComplete }: AuthFormProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showTOTP, setShowTOTP] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const authService = AuthService.getInstance();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const validationError = validateSignIn({ email, password });
      if (validationError) {
        toast.error(validationError);
        return;
      }

      const { data: { user }, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        toast.error('Invalid email or password');
        return;
      }

      if (!user) {
        toast.error('Login failed');
        return;
      }

      const { data: profile } = await supabase
        .from('profiles')
        .select('mfa_status')
        .eq('id', user.id)
        .single();

      if (profile?.mfa_status === 'enrolled') {
        setShowTOTP(true);
      } else {
        onComplete();
      }
    } catch (err: any) {
      console.error('Login error:', err);
      toast.error(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  if (showTOTP) {
    return <TOTPVerification onComplete={onComplete} />;
  }

  if (isSignUp) {
    return (
      <SignUpForm 
        onComplete={() => {
          setIsSignUp(false);
          toast.success('Account created! You can now log in');
        }}
        onCancel={() => setIsSignUp(false)} 
      />
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-2xl p-8">
      <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">Log In</h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
              required
              disabled={loading}
              placeholder="Enter your email"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Password
          </label>
          <div className="relative">
            <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
              required
              disabled={loading}
              placeholder="Enter your password"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 focus:ring-4 focus:ring-sky-500/50 font-medium transition-colors disabled:opacity-50 flex items-center justify-center space-x-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Logging in...</span>
            </>
          ) : (
            <span>Log In</span>
          )}
        </button>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">or</span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsSignUp(true)}
          className="w-full bg-white text-sky-600 py-3 px-4 rounded-lg border-2 border-sky-600 hover:bg-sky-50 font-medium transition-colors"
        >
          Create Account
        </button>
      </form>
    </div>
  );
}