import React from 'react';
import { Shield } from 'lucide-react';
import { useRoles } from '../../hooks/useRoles';
import toast from 'react-hot-toast';

interface RoleSelectionProps {
  onSelect: (role: string) => void;
  onCancel: () => void;
}

export function RoleSelection({ onSelect, onCancel }: RoleSelectionProps) {
  const { roles, loading, error } = useRoles();

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="text-center">
          <Shield className="w-12 h-12 text-sky-600 mx-auto mb-4 animate-pulse" />
          <h2 className="text-xl font-bold mb-4">Loading Available Roles...</h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="text-center">
          <Shield className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-4">Error Loading Roles</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-sky-600 text-white px-4 py-2 rounded hover:bg-sky-700"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <div className="text-center mb-6">
        <Shield className="w-12 h-12 text-sky-600 mx-auto mb-4" />
        <h2 className="text-xl font-bold">Select Your Role</h2>
        <p className="text-sm text-gray-600 mt-2">
          Choose your role to access the appropriate dashboard
        </p>
      </div>

      <div className="space-y-3">
        {roles.map((role) => (
          <button
            key={role.id}
            onClick={() => {
              toast.promise(
                Promise.resolve(onSelect(role.role)),
                {
                  loading: 'Setting role...',
                  success: `Role set to ${role.role}`,
                  error: 'Failed to set role'
                }
              );
            }}
            className="w-full p-4 text-left border rounded-lg hover:bg-sky-50 focus:outline-none focus:ring-2 focus:ring-sky-500 transition-colors"
          >
            <h3 className="font-semibold text-gray-900 capitalize">{role.role}</h3>
            <p className="text-sm text-gray-600">{role.description}</p>
          </button>
        ))}
      </div>

      <button
        onClick={onCancel}
        className="w-full mt-4 py-2 text-gray-600 hover:text-gray-800"
      >
        Cancel
      </button>
    </div>
  );
}