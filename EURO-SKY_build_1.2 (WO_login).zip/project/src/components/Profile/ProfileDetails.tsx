import React from 'react';
import { User, Mail, Phone, Building2, Shield } from 'lucide-react';
import { ProfileField } from './ProfileField';
import { formatRole } from '../../utils/textUtils';
import type { User as UserType } from '../../lib/auth/types';

interface ProfileDetailsProps {
  user: UserType;
}

export function ProfileDetails({ user }: ProfileDetailsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <ProfileField
        label="First Name"
        value={user.firstName}
        icon={User}
      />
      <ProfileField
        label="Last Name"
        value={user.lastName}
        icon={User}
      />
      <ProfileField
        label="Email"
        value={user.email}
        icon={Mail}
      />
      <ProfileField
        label="Phone Number"
        value={user.phoneNumber}
        icon={Phone}
      />
      {user.company && (
        <ProfileField
          label="Company"
          value={user.company}
          icon={Building2}
        />
      )}
      <ProfileField
        label="Role"
        value={formatRole(user.role || '')}
        icon={Shield}
        isRole
      />
    </div>
  );
}