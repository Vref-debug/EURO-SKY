import React from 'react';
import { User } from 'lucide-react';

export function ProfileHeader() {
  return (
    <div className="flex items-center justify-center mb-8">
      <div className="bg-sky-100 rounded-full p-4">
        <User className="w-16 h-16 text-sky-600" />
      </div>
    </div>
  );
}