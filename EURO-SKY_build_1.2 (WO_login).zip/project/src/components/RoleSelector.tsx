import React from 'react';
import { X } from 'lucide-react';
import { formatRole } from '../utils/textUtils';

interface RoleSelectorProps {
  currentRole?: string;
  availableRoles: string[];
  onSelect: (role: string) => void;
  onClose: () => void;
}

export function RoleSelector({ currentRole, availableRoles, onSelect, onClose }: RoleSelectorProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-lg font-semibold">Switch Role</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4">
          <div className="space-y-2">
            {availableRoles.map((role) => (
              <button
                key={role}
                onClick={() => {
                  onSelect(role);
                  onClose();
                }}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-colors ${
                  role === currentRole
                    ? 'bg-sky-100 text-sky-800'
                    : 'hover:bg-gray-50'
                }`}
              >
                <div>
                  <div className="font-medium text-left">{formatRole(role)}</div>
                  {role === currentRole && (
                    <div className="text-sm text-sky-600">Current role</div>
                  )}
                </div>
                {role === currentRole && (
                  <span className="text-sm bg-sky-200 text-sky-800 px-2 py-1 rounded">
                    Active
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}