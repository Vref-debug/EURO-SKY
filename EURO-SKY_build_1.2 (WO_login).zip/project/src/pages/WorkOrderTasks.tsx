import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Layout } from '../components/Layout';
import type { WorkOrder } from '../types/workOrder';

export function WorkOrderTasks() {
  const { workOrderId } = useParams();
  const navigate = useNavigate();

  // Mock data - replace with actual API call
  const workOrder: WorkOrder = {
    id: 'WO-2024-001',
    aircraftRegistration: 'OO-ABC',
    description: '50 Hour Inspection',
    priority: 'high',
    dueDate: '20/03/2024',
    status: 'in-progress',
    tasks: [
      {
        id: 'T1',
        type: 'inspection',
        description: 'Engine oil check and change',
        status: 'completed',
        dueDate: '15/03/2024'
      },
      {
        id: 'T2',
        type: 'inspection',
        description: 'Fuel system inspection',
        status: 'pending',
        dueDate: '20/03/2024'
      }
    ]
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate(-1)}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Tasks for Work Order {workOrderId}
                </h1>
                <p className="text-gray-600">
                  Aircraft: {workOrder.aircraftRegistration}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="space-y-6">
              {workOrder.tasks.map((task, index) => (
                <div 
                  key={task.id}
                  className="border-l-4 border-sky-500 pl-4 py-2"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">Task {index + 1}</h3>
                      <p className="text-gray-600">{task.description}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-sm font-medium ${
                      task.status === 'completed' 
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {task.status}
                    </span>
                  </div>
                  <div className="mt-2 text-sm text-gray-500">
                    Due: {task.dueDate}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}