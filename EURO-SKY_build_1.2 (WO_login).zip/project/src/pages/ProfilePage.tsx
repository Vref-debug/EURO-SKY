import React from 'react';
import { Layout } from '../components/Layout';
import { useAuth } from '../hooks/useAuth';
import { ProfileHeader } from '../components/Profile/ProfileHeader';
import { ProfileDetails } from '../components/Profile/ProfileDetails';

export function ProfilePage() {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8">
            <h1 className="text-2xl font-bold mb-6">Profile Settings</h1>
            <div className="space-y-6">
              <ProfileHeader />
              <ProfileDetails user={user} />
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}