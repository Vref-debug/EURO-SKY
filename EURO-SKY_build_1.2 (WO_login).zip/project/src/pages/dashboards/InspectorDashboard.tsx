import React from 'react';
import { Layout } from '../../components/Layout';
import { ClipboardCheck, AlertTriangle, CheckSquare } from 'lucide-react';

export function InspectorDashboard() {
  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Inspector Dashboard</h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Pending Inspections</h3>
                <ClipboardCheck className="w-6 h-6 text-sky-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">5</div>
              <p className="text-gray-600">Awaiting review</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Critical Issues</h3>
                <AlertTriangle className="w-6 h-6 text-red-500" />
              </div>
              <div className="text-xl font-semibold">2 Items</div>
              <p className="text-gray-600">Require immediate attention</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Completed</h3>
                <CheckSquare className="w-6 h-6 text-green-500" />
              </div>
              <div className="text-xl font-semibold text-green-600">12</div>
              <p className="text-gray-600">Inspections this week</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}