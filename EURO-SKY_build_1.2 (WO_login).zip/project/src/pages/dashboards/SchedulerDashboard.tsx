import React, { useState } from 'react';
import { DashboardLayout } from '../../components/DashboardLayout';
import { Calendar, Clock, CheckCircle } from 'lucide-react';
import { AircraftSelector } from '../../components/Scheduler/AircraftSelector';
import type { Aircraft } from '../../types/aircraft';

export function SchedulerDashboard() {
  const [selectedAircraft, setSelectedAircraft] = useState<Aircraft | null>(null);

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Maintenance Scheduler</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Today's Schedule</h3>
                <Calendar className="w-6 h-6 text-sky-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">8</div>
              <p className="text-gray-600">Maintenance appointments</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Next Available</h3>
                <Clock className="w-6 h-6 text-yellow-500" />
              </div>
              <div className="text-xl font-semibold">Tomorrow</div>
              <p className="text-gray-600">09:00 AM slot</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Completed Today</h3>
                <CheckCircle className="w-6 h-6 text-green-500" />
              </div>
              <div className="text-xl font-semibold text-green-600">5/8</div>
              <p className="text-gray-600">Appointments completed</p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-4">Aircraft Selection</h2>
              <AircraftSelector
                selectedAircraft={selectedAircraft}
                onSelect={setSelectedAircraft}
                showCreateWorkOrder
              />
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}