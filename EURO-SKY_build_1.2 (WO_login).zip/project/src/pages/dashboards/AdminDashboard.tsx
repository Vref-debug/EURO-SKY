import React from 'react';
import { Users, FileText, Settings } from 'lucide-react';
import { DashboardLayout } from '../../components/DashboardLayout';

export function AdminDashboard() {
  return (
    <DashboardLayout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Active Users</h3>
                <Users className="w-6 h-6 text-sky-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">24</div>
              <p className="text-gray-600">Total registered users</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Maintenance Logs</h3>
                <FileText className="w-6 h-6 text-yellow-500" />
              </div>
              <div className="text-xl font-semibold">156 Records</div>
              <p className="text-gray-600">Last 30 days</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">System Status</h3>
                <Settings className="w-6 h-6 text-green-500" />
              </div>
              <div className="text-xl font-semibold text-green-600">Operational</div>
              <p className="text-gray-600">All systems normal</p>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}