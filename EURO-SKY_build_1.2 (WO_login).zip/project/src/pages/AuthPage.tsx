import React from 'react';
import { AuthLayout } from '../components/Auth/AuthLayout';
import { DummyLoginForm } from '../components/Auth/DummyLoginForm';

export function AuthPage() {
  return (
    <AuthLayout>
      <DummyLoginForm />
    </AuthLayout>
  );
}