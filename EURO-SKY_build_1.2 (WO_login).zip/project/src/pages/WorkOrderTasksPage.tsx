import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Layout } from '../components/Layout';
import { TaskOverview } from '../components/Tasks/TaskOverview';
import type { DetailedTask } from '../types/task';

export function WorkOrderTasksPage() {
  const { workOrderId } = useParams<{ workOrderId: string }>();
  const navigate = useNavigate();

  // Mock data - replace with API call
  const mockTasks: DetailedTask[] = [
    {
      id: 'T1',
      title: 'Engine Oil Change',
      description: 'Complete engine oil change and filter replacement',
      type: 'inspection',
      status: 'completed',
      priority: 'high',
      startDate: '15/03/2024',
      endDate: '15/03/2024',
      aircraftInfo: {
        registration: 'OO-ABC',
        type: 'C172'
      },
      assignedTo: {
        id: 'M1',
        name: 'John Smith',
        role: 'Mechanic'
      }
    },
    {
      id: 'T2',
      title: 'Fuel System Inspection',
      description: 'Inspect fuel system components per AD 2024-02',
      type: 'ad',
      status: 'pending',
      priority: 'high',
      startDate: '20/03/2024',
      endDate: '20/03/2024',
      aircraftInfo: {
        registration: 'OO-ABC',
        type: 'C172'
      }
    }
  ];

  if (!workOrderId) return null;

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate(-1)}
                className="text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h1 className="text-2xl font-bold text-gray-900">
                Tasks for Work Order {workOrderId}
              </h1>
            </div>
          </div>

          <TaskOverview 
            workOrderId={workOrderId}
            tasks={mockTasks}
          />
        </div>
      </div>
    </Layout>
  );
}