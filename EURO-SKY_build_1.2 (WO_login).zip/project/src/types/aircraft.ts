```typescript
export interface Aircraft {
  tail_number: string;
  manufacturer: string;
  model: string;
  serial_number: string;
  year_manufactured: number;
  created_at?: string;
  updated_at?: string;
}

export interface AircraftStatus {
  registration: string;
  type: string;
  totalHours: number;
  engineHours: number;
  lastMaintenanceDate: string;
  estimatedNextMaintenanceDate: string;
  hoursUntilMaintenance: number;
  status: 'active' | 'maintenance' | 'grounded';
  lastUpdated: string;
  averageMonthlyHours: number;
}
```