export interface ScheduleSlot {
  id: string;
  startTime: string;
  endTime: string;
  date: string;
  available: boolean;
  assignedTo?: string;
}

export interface MaintenanceSchedule {
  workOrderId: string;
  aircraftRegistration: string;
  tasks: ScheduledTask[];
  startDate: string;
  endDate: string;
  status: 'scheduled' | 'in-progress' | 'completed';
}

export interface ScheduledTask {
  id: string;
  workOrderId: string;
  taskId: string;
  mechanicId?: string;
  scheduledDate: string;
  scheduledTime: string;
  estimatedDuration: number; // in minutes
  status: 'pending' | 'assigned' | 'in-progress' | 'completed';
}

export interface Mechanic {
  id: string;
  name: string;
  specializations: string[];
  availability: ScheduleSlot[];
}