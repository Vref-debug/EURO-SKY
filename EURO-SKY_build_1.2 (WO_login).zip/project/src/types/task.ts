import { TaskType, TaskStatus } from './workOrder';

export interface AssignedPerson {
  id: string;
  name: string;
  role: string;
}

export interface DetailedTask {
  id: string;
  title: string;
  description: string;
  type: TaskType;
  status: TaskStatus;
  priority: 'high' | 'medium' | 'low';
  startDate: string;
  endDate: string;
  assignedTo?: AssignedPerson;
  aircraftInfo: {
    registration: string;
    type: string;
  };
}

export type TaskFilter = {
  aircraft: string[];
  status: TaskStatus[];
  priority: string[];
  assignedTo: string[];
};

export type SortField = 'priority' | 'startDate' | 'status' | 'aircraft';
export type SortDirection = 'asc' | 'desc';