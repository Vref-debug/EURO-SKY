import { supabase } from '../../supabase';
import { EMAIL_CONSTANTS } from './constants';

export class EmailVerificationService {
  private static instance: EmailVerificationService;
  private lastAttemptTime = 0;

  private constructor() {}

  static getInstance(): EmailVerificationService {
    if (!EmailVerificationService.instance) {
      EmailVerificationService.instance = new EmailVerificationService();
    }
    return EmailVerificationService.instance;
  }

  private canSendCode(): boolean {
    const now = Date.now();
    const timeSinceLastAttempt = (now - this.lastAttemptTime) / 1000;
    return timeSinceLastAttempt >= EMAIL_CONSTANTS.COOLDOWN_PERIOD;
  }

  private getRemainingCooldown(): number {
    const now = Date.now();
    const timeSinceLastAttempt = (now - this.lastAttemptTime) / 1000;
    return Math.ceil(EMAIL_CONSTANTS.COOLDOWN_PERIOD - timeSinceLastAttempt);
  }

  async sendVerificationCode(email: string): Promise<{ success: boolean; message?: string }> {
    try {
      if (!this.canSendCode()) {
        return {
          success: false,
          message: `Please wait ${this.getRemainingCooldown()} seconds before requesting another code`
        };
      }

      const { error } = await supabase.auth.signInWithOtp({
        email: email.trim(),
        options: {
          shouldCreateUser: false
        }
      });

      if (error) {
        console.error('OTP send error:', error);
        throw error;
      }

      this.lastAttemptTime = Date.now();
      return { success: true };
    } catch (error: any) {
      console.error('Send verification code error:', error);
      return { 
        success: false, 
        message: error.message || 'Failed to send verification code'
      };
    }
  }

  async verifyCode(email: string, code: string): Promise<{ success: boolean; message?: string }> {
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email: email.trim(),
        token: code,
        type: 'email'
      });

      if (error) throw error;

      return { 
        success: !!data.user,
        message: data.user ? 'Verification successful' : 'Verification failed'
      };
    } catch (error: any) {
      console.error('Verify code error:', error);
      return { 
        success: false, 
        message: error.message || 'Invalid verification code'
      };
    }
  }
}