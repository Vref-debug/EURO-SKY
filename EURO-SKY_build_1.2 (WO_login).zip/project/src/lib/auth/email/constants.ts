export const EMAIL_CONSTANTS = {
  COOLDOWN_PERIOD: 60, // seconds
  CODE_LENGTH: 6
} as const;