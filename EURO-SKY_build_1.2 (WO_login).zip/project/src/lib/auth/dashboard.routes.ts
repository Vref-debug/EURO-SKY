import { PilotDashboard } from '../../pages/dashboards/PilotDashboard';
import { InstructorDashboard } from '../../pages/dashboards/InstructorDashboard';
import { MechanicDashboard } from '../../pages/dashboards/MechanicDashboard';
import { InspectorDashboard } from '../../pages/dashboards/InspectorDashboard';
import { ManagerDashboard } from '../../pages/dashboards/ManagerDashboard';
import { SchedulerDashboard } from '../../pages/dashboards/SchedulerDashboard';
import { StudentDashboard } from '../../pages/dashboards/StudentDashboard';
import { OwnerDashboard } from '../../pages/dashboards/OwnerDashboard';
import { AdminDashboard } from '../../pages/dashboards/AdminDashboard';

export const dashboardRoutes = {
  pilot: {
    path: '/pilot-dashboard',
    component: PilotDashboard
  },
  instructor: {
    path: '/instructor-dashboard',
    component: InstructorDashboard
  },
  mechanic: {
    path: '/mechanic-dashboard',
    component: MechanicDashboard
  },
  inspector: {
    path: '/inspector-dashboard',
    component: InspectorDashboard
  },
  manager: {
    path: '/manager-dashboard',
    component: ManagerDashboard
  },
  scheduler: {
    path: '/scheduler-dashboard',
    component: SchedulerDashboard
  },
  student: {
    path: '/student-dashboard',
    component: StudentDashboard
  },
  owner: {
    path: '/owner-dashboard',
    component: OwnerDashboard
  },
  admin: {
    path: '/admin-dashboard',
    component: AdminDashboard
  }
};