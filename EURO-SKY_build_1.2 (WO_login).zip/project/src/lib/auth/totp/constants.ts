export const MFA_STATUS = {
  PENDING: 'pending',
  ENROLLED: 'enrolled',
  DISABLED: 'disabled'
} as const;

export const MFA_MESSAGES = {
  SETUP_REQUIRED: 'Two-factor authentication setup is required for your role',
  SETUP_COMPLETE: '2FA setup completed successfully',
  VERIFICATION_REQUIRED: 'Please verify your identity using 2FA',
} as const;