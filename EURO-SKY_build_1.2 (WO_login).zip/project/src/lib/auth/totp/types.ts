export interface TOTPEnrollResponse {
  id: string;
  qrCode: string;
  secret: string;
}

export interface TOTPError {
  message: string;
  code?: string;
}

export interface TOTPState {
  factorId: string | null;
  qrCode: string | null;
  secret: string | null;
  error: TOTPError | null;
  loading: boolean;
}