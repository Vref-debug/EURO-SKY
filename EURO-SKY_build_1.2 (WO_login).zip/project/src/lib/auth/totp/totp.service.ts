import { supabase } from '../../supabase';
import { TOTP_ERRORS } from './errors';
import type { TOTPEnrollResponse } from './types';

export class TOTPService {
  private static instance: TOTPService;
  private readonly issuer = 'EURO-SKY';
  private enrollmentInProgress = false;
  private retryAttempts = 0;
  private maxRetries = 3;
  private retryDelay = 2000;

  private constructor() {}

  static getInstance(): TOTPService {
    if (!TOTPService.instance) {
      TOTPService.instance = new TOTPService();
    }
    return TOTPService.instance;
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async enrollTOTP(): Promise<TOTPEnrollResponse> {
    if (this.enrollmentInProgress) {
      throw new Error(TOTP_ERRORS.SETUP_IN_PROGRESS);
    }

    this.enrollmentInProgress = true;
    this.retryAttempts = 0;

    try {
      // First, check if MFA factors exist
      const { data: { factors } } = await supabase.auth.mfa.listFactors();
      
      // If there are unverified factors, clean them up
      if (factors?.totp) {
        for (const factor of factors.totp) {
          if (!factor.verified) {
            await supabase.auth.mfa.unenroll({ factorId: factor.id });
            await this.delay(1000);
          }
        }
      }

      while (this.retryAttempts < this.maxRetries) {
        try {
          const { data, error } = await supabase.auth.mfa.enroll({
            factorType: 'totp',
            issuer: this.issuer,
            friendlyName: `EURO-SKY-${Date.now()}`
          });

          if (error) throw error;
          if (!data?.totp) throw new Error(TOTP_ERRORS.INVALID_RESPONSE);

          return {
            id: data.totp.id,
            qrCode: data.totp.qr_code,
            secret: data.totp.secret
          };
        } catch (error: any) {
          this.retryAttempts++;
          
          if (this.retryAttempts >= this.maxRetries) {
            throw new Error(TOTP_ERRORS.SETUP_FAILED);
          }
          
          await this.delay(this.retryDelay * this.retryAttempts);
        }
      }

      throw new Error(TOTP_ERRORS.SETUP_FAILED);
    } finally {
      this.enrollmentInProgress = false;
    }
  }

  async verifyTOTP(factorId: string, code: string): Promise<boolean> {
    if (!code) throw new Error(TOTP_ERRORS.INVALID_CODE);
    if (!factorId) throw new Error(TOTP_ERRORS.MISSING_FACTOR);

    try {
      const { data, error } = await supabase.auth.mfa.verify({
        factorId,
        code,
        challengeId: factorId
      });

      if (error) throw error;
      
      // Update profile MFA status on successful verification
      if (data) {
        const { user } = await supabase.auth.getUser();
        if (user) {
          await supabase
            .from('profiles')
            .update({ mfa_status: 'enrolled' })
            .eq('id', user.id);
        }
      }

      return !!data;
    } catch (error: any) {
      console.error('TOTP verification error:', error);
      throw new Error(TOTP_ERRORS.INVALID_CODE);
    }
  }

  async challenge(factorId: string): Promise<string> {
    const { data, error } = await supabase.auth.mfa.challenge({ factorId });
    if (error) throw error;
    return data.id;
  }

  async unenrollTOTP(factorId: string): Promise<void> {
    const { error } = await supabase.auth.mfa.unenroll({ factorId });
    if (error) throw error;
  }
}