import { supabase } from '../supabase';
import type { SignUpCredentials, SignInCredentials } from './types';

export class AuthService {
  private static instance: AuthService;

  private constructor() {}

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  async signUp(credentials: SignUpCredentials) {
    try {
      const { data, error } = await supabase.auth.signUp({
        email: credentials.email.trim(),
        password: credentials.password,
        options: {
          data: {
            first_name: credentials.firstName.trim(),
            last_name: credentials.lastName.trim(),
            phone_number: credentials.phoneNumber.trim(),
            company: credentials.company?.trim() || null,
            role: credentials.role
          }
        }
      });

      if (error) throw error;
      if (!data.user) throw new Error('Failed to create user');

      return { user: data.user, session: data.session };
    } catch (error: any) {
      console.error('Sign up error:', error);
      throw error;
    }
  }

  async signIn(credentials: SignInCredentials) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: credentials.email.trim(),
        password: credentials.password
      });

      if (error) throw error;
      return data;
    } catch (error: any) {
      console.error('Sign in error:', error);
      throw error;
    }
  }

  async getSession() {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      return session;
    } catch (error: any) {
      console.error('Get session error:', error);
      throw error;
    }
  }

  async signOut() {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
    } catch (error: any) {
      console.error('Sign out error:', error);
      throw error;
    }
  }

  async getUserProfile(userId: string) {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      return data;
    } catch (error: any) {
      console.error('Get profile error:', error);
      throw error;
    }
  }
}