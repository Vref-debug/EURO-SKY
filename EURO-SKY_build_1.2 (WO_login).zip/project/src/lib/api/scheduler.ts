import { supabase } from '../supabase';
import type { Mechanic, MaintenanceSchedule } from '../../types/scheduler';
import type { WorkOrder } from '../../types/workOrder';

export async function getMechanics(): Promise<Mechanic[]> {
  const { data, error } = await supabase
    .from('mechanics')
    .select(`
      id,
      name,
      specializations,
      availability (
        id,
        date,
        start_time,
        end_time,
        available
      )
    `);

  if (error) throw error;
  return data || [];
}

export async function getWorkOrders(): Promise<WorkOrder[]> {
  const { data, error } = await supabase
    .from('work_orders')
    .select(`
      id,
      aircraft_registration,
      description,
      priority,
      due_date,
      status,
      tasks (
        id,
        type,
        description,
        status,
        due_date
      )
    `);

  if (error) throw error;
  return data || [];
}

export async function assignMechanic(
  taskId: string,
  mechanicId: string,
  scheduledDate: string,
  scheduledTime: string
): Promise<void> {
  const { error } = await supabase
    .from('task_assignments')
    .insert({
      task_id: taskId,
      mechanic_id: mechanicId,
      scheduled_date: scheduledDate,
      scheduled_time: scheduledTime,
      status: 'assigned'
    });

  if (error) throw error;
}