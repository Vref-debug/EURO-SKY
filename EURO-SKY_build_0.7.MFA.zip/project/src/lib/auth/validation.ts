import { SignUpCredentials, SignInCredentials } from './types';

export function validateSignUp(data: SignUpCredentials): string | null {
  // Check for empty or undefined values
  if (!data.email?.trim()) return 'Email is required';
  if (!data.password?.trim()) return 'Password is required';
  if (!data.firstName?.trim()) return 'First name is required';
  if (!data.lastName?.trim()) return 'Last name is required';
  if (!data.phoneNumber?.trim()) return 'Phone number is required';
  
  // Validate email format
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    return 'Please enter a valid email address';
  }
  
  // Validate password length
  if (data.password.length < 8) {
    return 'Password must be at least 8 characters';
  }

  // Validate phone number format
  if (!/^\+?[\d\s-]{10,}$/.test(data.phoneNumber.trim())) {
    return 'Please enter a valid phone number';
  }
  
  return null;
}

export function validateSignIn(data: SignInCredentials): string | null {
  if (!data.email?.trim()) return 'Email is required';
  if (!data.password?.trim()) return 'Password is required';
  
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    return 'Please enter a valid email address';
  }
  
  return null;
}