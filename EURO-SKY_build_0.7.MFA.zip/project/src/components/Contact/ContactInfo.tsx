import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

export function ContactInfo() {
  return (
<div className="bg-white rounded-lg shadow-lg p-6">
  <h3 className="text-xl font-semibold mb-6">Contact Information</h3>
  <div className="space-y-4">
    <div className="flex items-center space-x-3">
      <Mail className="text-sky-600 w-5 h-5" />
      <div>
        <p className="text-sm text-gray-500">Email</p>
        <a href="mailto:info@eurosky.be" className="text-sky-600 hover:text-sky-700">
          info@eurosky.be
        </a>
      </div>
    </div>
    <div className="flex items-center space-x-3">
      <Phone className="text-sky-600 w-5 h-5" />
      <div>
        <p className="text-sm text-gray-500">Phone</p>
        <a href="tel:+32123456789" className="text-sky-600 hover:text-sky-700">
          +32 12 345 67 89
        </a>
      </div>
    </div>
    <div className="space-y-4">
      <div className="flex items-center space-x-3">
        <MapPin className="text-sky-600 w-5 h-5" />
        <div>
          <p className="text-sm text-gray-500">Address</p>
          <p>Humbeeksesteenweg 313</p>
          <p>1850 Grimbergen, Belgium</p>
        </div>
      </div>
      <div className="flex items-center space-x-3">
        <MapPin className="text-sky-600 w-5 h-5" />
        <div>
          <p className="text-sm text-gray-500">Address</p>
          <p>Rue Capitaine Aviateur Jacquet 44</p>
          <p>5020 Namur, Belgium</p>
        </div>
      </div>
    </div>
  </div>
</div>


  );
}