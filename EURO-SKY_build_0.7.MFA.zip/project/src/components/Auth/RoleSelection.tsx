import React from 'react';
import { useRoles } from '../../hooks/useRoles';
import { Shield } from 'lucide-react';

interface RoleSelectionProps {
  onSelect: (role: string) => void;
  onComplete: () => void;
}

export function RoleSelection({ onSelect, onComplete }: RoleSelectionProps) {
  const { roles, loading, error } = useRoles();

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto">
        <div className="text-center">
          <Shield className="w-12 h-12 text-sky-600 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-4">Loading Roles...</h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto">
        <div className="text-center">
          <Shield className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-4">Error Loading Roles</h2>
          <p className="text-gray-600 mb-4">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto">
      <div className="flex justify-center mb-6">
        <Shield className="w-12 h-12 text-sky-600" />
      </div>

      <h2 className="text-xl font-bold text-center mb-4">Select Your Role</h2>
      <p className="text-sm text-gray-600 mb-6">
        Choose your role to complete the setup process. This will determine your access level and permissions.
      </p>

      <div className="space-y-3">
        {roles.map((role) => (
          <button
            key={role.id}
            onClick={() => {
              onSelect(role.role);
              onComplete();
            }}
            className="w-full p-4 text-left border rounded-lg hover:bg-sky-50 focus:outline-none focus:ring-2 focus:ring-sky-500 transition-colors"
          >
            <h3 className="font-semibold text-gray-900 capitalize">{role.role}</h3>
            <p className="text-sm text-gray-600">{role.description}</p>
          </button>
        ))}
      </div>
    </div>
  );
}