import React, { useEffect, useState, useCallback } from 'react';
import { Shield, Copy } from 'lucide-react';
import { useTOTP } from '../../hooks/useTOTP';
import toast from 'react-hot-toast';

interface TOTPSetupProps {
  onComplete: () => void;
}

export function TOTPSetup({ onComplete }: TOTPSetupProps) {
  const [verificationCode, setVerificationCode] = useState('');
  const [showQR, setShowQR] = useState(true);
  const [qrDisplayTime] = useState(Date.now());
  const [canVerify, setCanVerify] = useState(false);
  const { qrCode, secret, error, loading, setupTOTP, verifyTOTP, resetError } = useTOTP();

  useEffect(() => {
    const timer = setTimeout(() => {
      setCanVerify(true);
    }, 30000); // 30 seconds minimum display time

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    setupTOTP();
  }, [setupTOTP]);

  useEffect(() => {
    if (error) {
      toast.error(error.message);
    }
  }, [error]);

  const handleCopySecret = useCallback(() => {
    if (secret) {
      navigator.clipboard.writeText(secret);
      toast.success('Secret code copied to clipboard');
    }
  }, [secret]);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!canVerify) {
      toast.error('Please wait a moment before verifying');
      return;
    }

    if (!verificationCode.match(/^\d{6}$/)) {
      toast.error('Please enter a valid 6-digit code');
      return;
    }

    const success = await verifyTOTP(verificationCode);
    if (success) {
      toast.success('2FA setup complete');
      onComplete();
    } else {
      setVerificationCode('');
    }
  };

  const handleRetry = () => {
    setShowQR(true);
    setVerificationCode('');
    resetError();
    setupTOTP();
  };

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto">
        <div className="text-center">
          <Shield className="w-12 h-12 text-sky-600 mx-auto mb-4 animate-pulse" />
          <h2 className="text-xl font-bold mb-4">Setting up 2FA...</h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto">
        <div className="text-center">
          <Shield className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-4">2FA Setup Failed</h2>
          <p className="text-gray-600 mb-4">{error.message}</p>
          <button
            onClick={handleRetry}
            className="bg-sky-600 text-white px-4 py-2 rounded hover:bg-sky-700"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (!qrCode || !secret) {
    return null;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto">
      <div className="text-center mb-6">
        <Shield className="w-12 h-12 text-sky-600 mx-auto mb-4" />
        <h2 className="text-xl font-bold">Set Up Two-Factor Authentication</h2>
      </div>

      <div className="space-y-6">
        <div>
          <p className="text-sm text-gray-600 mb-4">
            1. Scan this QR code with your authenticator app (e.g., Google Authenticator, Authy)
          </p>
          <div className="flex justify-center mb-4">
            <img src={qrCode} alt="2FA QR Code" className="border p-2 rounded" />
          </div>
        </div>

        <div>
          <p className="text-sm text-gray-600 mb-2">
            2. Or manually enter this code in your authenticator app:
          </p>
          <div className="flex items-center justify-between bg-gray-50 p-2 rounded">
            <code className="font-mono text-sm">{secret}</code>
            <button
              onClick={handleCopySecret}
              className="text-sky-600 hover:text-sky-700 p-1"
              title="Copy secret code"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
        </div>

        <form onSubmit={handleVerify} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              3. Enter the 6-digit code from your authenticator app
            </label>
            <input
              type="text"
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
              className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500 text-center text-2xl tracking-wider font-mono"
              placeholder="000000"
              maxLength={6}
              pattern="\d{6}"
              required
              disabled={!canVerify}
            />
          </div>

          <button
            type="submit"
            disabled={!canVerify || verificationCode.length !== 6 || loading}
            className="w-full bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
          >
            {loading ? 'Verifying...' : 'Complete Setup'}
          </button>
        </form>
      </div>
    </div>
  );
}