/*
  # Add user roles table and update profiles

  1. New Tables
    - `user_roles`
      - `id` (uuid, primary key)
      - `role` (text, unique)
      - `description` (text)
      - `created_at` (timestamptz)

  2. Changes
    - Add `role` column to profiles table
    - Add foreign key constraint to user_roles
    - Add default roles

  3. Security
    - Enable RLS
    - Add policy for authenticated users to read roles
*/

-- Create user_roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text UNIQUE NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Add role to profiles
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS role text REFERENCES user_roles(role);

-- Insert default roles
INSERT INTO user_roles (role, description)
VALUES 
  ('pilot', 'Licensed pilot with flight privileges'),
  ('instructor', 'Flight instructor with teaching privileges'),
  ('maintenance', 'Maintenance staff member'),
  ('admin', 'Administrative staff member')
ON CONFLICT (role) DO NOTHING;

-- Enable RLS
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Allow all authenticated users to read roles
CREATE POLICY "Anyone can read roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);