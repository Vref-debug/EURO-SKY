import React from 'react';
import { Layout } from '../components/Layout';
import { DashboardHeader } from '../components/Dashboard/DashboardHeader';
import { ScheduleForm } from '../components/Schedule/ScheduleForm';
import { MaintenanceHistory } from '../components/Schedule/MaintenanceHistory';
import { useAuth } from '../hooks/useAuth';

export function SchedulerDashboard() {
  const { user } = useAuth();

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <DashboardHeader user={user} />
          <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
            <ScheduleForm />
            <MaintenanceHistory />
          </div>
        </div>
      </div>
    </Layout>
  );
}