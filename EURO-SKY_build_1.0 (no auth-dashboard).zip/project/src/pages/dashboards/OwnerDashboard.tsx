import React from 'react';
import { Layout } from '../../components/Layout';
import { AircraftDetails } from '../../components/Dashboard/Owner/AircraftDetails';
import { FlightHoursStatus } from '../../components/Dashboard/Owner/FlightHoursStatus';
import { MaintenanceStatus } from '../../components/Dashboard/Owner/MaintenanceStatus';

export function OwnerDashboard() {
  // Mock data - in a real app, this would come from your API/database
  const aircraftData = {
    registration: 'OO-ABC',
    type: 'Cessna 172S',
    serialNumber: '172S10234',
    yearManufactured: 2018,
    totalFlightHours: 1234.5,
    engineHours: 1234.5,
    lastUpdated: '2024-03-15',
    lastMaintenanceDate: '2024-02-15',
    nextMaintenanceDate: '2024-05-15',
    maintenanceStatus: 'ok' as const,
    hoursRemaining: 48.5
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Aircraft Owner Dashboard</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <AircraftDetails
              registration={aircraftData.registration}
              type={aircraftData.type}
              serialNumber={aircraftData.serialNumber}
              yearManufactured={aircraftData.yearManufactured}
            />
            <FlightHoursStatus
              totalFlightHours={aircraftData.totalFlightHours}
              engineHours={aircraftData.engineHours}
              lastUpdated={aircraftData.lastUpdated}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <MaintenanceStatus
              lastMaintenanceDate={aircraftData.lastMaintenanceDate}
              nextMaintenanceDate={aircraftData.nextMaintenanceDate}
              status={aircraftData.maintenanceStatus}
              hoursRemaining={aircraftData.hoursRemaining}
            />
          </div>
        </div>
      </div>
    </Layout>
  );
}