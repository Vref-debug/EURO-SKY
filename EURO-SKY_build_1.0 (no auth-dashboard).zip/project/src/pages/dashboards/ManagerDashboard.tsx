import React from 'react';
import { Layout } from '../../components/Layout';
import { BarChart, Clock, Users } from 'lucide-react';

export function ManagerDashboard() {
  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Manager Dashboard</h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Staff Performance</h3>
                <BarChart className="w-6 h-6 text-sky-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">92%</div>
              <p className="text-gray-600">Average efficiency</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Active Projects</h3>
                <Clock className="w-6 h-6 text-yellow-500" />
              </div>
              <div className="text-xl font-semibold">7 Projects</div>
              <p className="text-gray-600">2 nearing deadline</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Team Status</h3>
                <Users className="w-6 h-6 text-green-500" />
              </div>
              <div className="text-xl font-semibold text-green-600">15/16</div>
              <p className="text-gray-600">Staff availability</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}