import React from 'react';
import { Layout } from '../../components/Layout';
import { Users, BookOpen, BarChart } from 'lucide-react';
import { AircraftList } from '../../components/Dashboard/FlightSchool/AircraftList';
import type { AircraftStatus } from '../../types/aircraft';

export function FlightSchoolAdminDashboard() {
  // Mock data - in a real app, this would come from your API
  const fleetStatus: AircraftStatus[] = [
    {
      registration: 'OO-ABC',
      type: 'Cessna 172S',
      totalHours: 2345.6,
      engineHours: 2345.6,
      lastMaintenanceDate: '2024-02-15',
      nextMaintenanceDate: '2024-04-15',
      hoursUntilMaintenance: 45.5,
      status: 'active'
    },
    {
      registration: 'OO-DEF',
      type: 'Piper PA-28',
      totalHours: 3456.7,
      engineHours: 1234.5,
      lastMaintenanceDate: '2024-03-01',
      nextMaintenanceDate: '2024-04-01',
      hoursUntilMaintenance: 15.5,
      status: 'active'
    },
    {
      registration: 'OO-GHI',
      type: 'Diamond DA40',
      totalHours: 1567.8,
      engineHours: 1567.8,
      lastMaintenanceDate: '2024-03-10',
      nextMaintenanceDate: '2024-04-10',
      hoursUntilMaintenance: 8.5,
      status: 'active'
    },
    {
      registration: 'OO-JKL',
      type: 'Cessna 152',
      totalHours: 4567.9,
      engineHours: 1890.3,
      lastMaintenanceDate: '2024-03-05',
      nextMaintenanceDate: '2024-04-05',
      hoursUntilMaintenance: 22.5,
      status: 'active'
    }
  ];

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Flight School Fleet Status</h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Fleet Size</h3>
                <Users className="w-6 h-6 text-sky-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">4</div>
              <p className="text-gray-600">Active aircraft</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Maintenance Due</h3>
                <BookOpen className="w-6 h-6 text-yellow-500" />
              </div>
              <div className="text-xl font-semibold">2 Aircraft</div>
              <p className="text-gray-600">Within 25 hours</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Fleet Availability</h3>
                <BarChart className="w-6 h-6 text-green-500" />
              </div>
              <div className="text-xl font-semibold text-green-600">100%</div>
              <p className="text-gray-600">All aircraft operational</p>
            </div>
          </div>

          <AircraftList aircraft={fleetStatus} />
        </div>
      </div>
    </Layout>
  );
}