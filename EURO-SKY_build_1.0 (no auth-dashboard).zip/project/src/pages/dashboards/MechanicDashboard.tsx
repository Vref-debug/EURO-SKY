import React from 'react';
import { Layout } from '../../components/Layout';
import { Wrench, AlertCircle, CheckCircle } from 'lucide-react';

export function MechanicDashboard() {
  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Mechanic Dashboard</h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Active Work Orders</h3>
                <Wrench className="w-6 h-6 text-sky-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900">3</div>
              <p className="text-gray-600">Pending maintenance tasks</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Urgent Tasks</h3>
                <AlertCircle className="w-6 h-6 text-red-500" />
              </div>
              <div className="text-xl font-semibold">1 High Priority</div>
              <p className="text-gray-600">100-hour inspection due</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Completed Today</h3>
                <CheckCircle className="w-6 h-6 text-green-500" />
              </div>
              <div className="text-xl font-semibold text-green-600">2 Tasks</div>
              <p className="text-gray-600">Oil changes completed</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}