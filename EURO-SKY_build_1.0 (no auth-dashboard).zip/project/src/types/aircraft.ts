export interface AircraftStatus {
  registration: string;
  type: string;
  totalHours: number;
  engineHours: number;
  lastMaintenanceDate: string;
  nextMaintenanceDate: string;
  hoursUntilMaintenance: number;
  status: 'active' | 'maintenance' | 'grounded';
}