import { supabase } from '../supabase';
import type { UserRole } from './types';

export class RolesService {
  private static instance: RolesService;

  private constructor() {}

  static getInstance(): RolesService {
    if (!RolesService.instance) {
      RolesService.instance = new RolesService();
    }
    return RolesService.instance;
  }

  async getRoles(): Promise<UserRole[]> {
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('*')
        .order('role');

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching roles:', error);
      throw error;
    }
  }
}