import { dummyUsers } from './dummyUsers';
import type { SignInCredentials } from './types';

export class DummyAuthService {
  private static instance: DummyAuthService;

  private constructor() {}

  static getInstance(): DummyAuthService {
    if (!DummyAuthService.instance) {
      DummyAuthService.instance = new DummyAuthService();
    }
    return DummyAuthService.instance;
  }

  async signIn(credentials: SignInCredentials) {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const user = dummyUsers.find(
      u => u.email === credentials.email && u.password === credentials.password
    );

    if (!user) {
      throw new Error('Invalid email or password');
    }

    return {
      user: {
        id: crypto.randomUUID(),
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      }
    };
  }

  async signOut() {
    // Clear any stored session
    localStorage.removeItem('dummyUser');
  }
}