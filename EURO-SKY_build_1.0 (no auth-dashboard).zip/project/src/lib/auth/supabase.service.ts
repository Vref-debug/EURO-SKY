import { supabase } from '../supabase';
import type { SignUpCredentials, SignInCredentials } from './types';

export class SupabaseService {
  private static instance: SupabaseService;

  private constructor() {}

  static getInstance(): SupabaseService {
    if (!SupabaseService.instance) {
      SupabaseService.instance = new SupabaseService();
    }
    return SupabaseService.instance;
  }

  async signUp(credentials: SignUpCredentials) {
    const { data, error } = await supabase.auth.signUp({
      email: credentials.email.trim(),
      password: credentials.password,
      options: {
        data: {
          first_name: credentials.firstName.trim(),
          last_name: credentials.lastName.trim(),
          phone_number: credentials.phoneNumber.trim(),
          company: credentials.company?.trim(),
          role: credentials.role
        }
      }
    });

    if (error) throw error;
    if (!data.user) throw new Error('Failed to create user');

    return { user: data.user, session: data.session };
  }

  async signIn(credentials: SignInCredentials) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email: credentials.email.trim(),
      password: credentials.password
    });

    if (error) {
      if (error.message === 'Invalid login credentials') {
        throw new Error('Invalid email or password');
      }
      throw error;
    }

    return data;
  }

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }

  async getSession() {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) throw error;
    return session;
  }

  async getUserProfile(userId: string) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) throw error;
    return { data };
  }

  async verifyTOTP(code: string) {
    try {
      const { data, error } = await supabase.auth.mfa.verify({
        code,
        factorId: 'totp'
      });

      if (error) throw error;
      return !!data;
    } catch (error) {
      console.error('TOTP verification error:', error);
      return false;
    }
  }
}