import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

export function useRoleDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    async function redirectToDashboard() {
      if (!user?.role) return;

      try {
        const { data: dashboard } = await supabase
          .from('role_dashboards')
          .select('dashboard_path')
          .eq('role', user.role)
          .single();

        if (dashboard?.dashboard_path) {
          navigate(dashboard.dashboard_path);
        } else {
          console.error('No dashboard path found for role:', user.role);
          navigate('/dashboard'); // Fallback to default dashboard
        }
      } catch (error) {
        console.error('Error fetching dashboard path:', error);
        navigate('/dashboard');
      }
    }

    redirectToDashboard();
  }, [user?.role, navigate]);
}