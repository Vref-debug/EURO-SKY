import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from './useAuth';

export function useRoleRedirect() {
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    async function redirectToDashboard() {
      if (!user?.id) return;

      try {
        // Get user's role and corresponding dashboard
        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single();

        if (!profile?.role) {
          navigate('/auth');
          return;
        }

        const { data: dashboard } = await supabase
          .from('role_dashboards')
          .select('dashboard_path')
          .eq('role', profile.role)
          .single();

        if (dashboard?.dashboard_path) {
          navigate(dashboard.dashboard_path);
        } else {
          navigate('/dashboard'); // Fallback to default dashboard
        }
      } catch (error) {
        console.error('Error redirecting to dashboard:', error);
        navigate('/auth');
      }
    }

    redirectToDashboard();
  }, [user, navigate]);
}