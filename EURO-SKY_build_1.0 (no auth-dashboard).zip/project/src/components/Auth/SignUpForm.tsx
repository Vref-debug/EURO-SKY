import React, { useState } from 'react';
import { Mail, Shield, Phone, Building2, User } from 'lucide-react';
import { AuthService } from '../../lib/auth/auth.service';
import { validateSignUp } from '../../lib/auth/validation';
import toast from 'react-hot-toast';
import type { SignUpCredentials } from '../../lib/auth/types';

interface SignUpFormProps {
  onComplete: (data: { mfaData?: any }) => void;
  onCancel: () => void;
}

export function SignUpForm({ onComplete, onCancel }: SignUpFormProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<SignUpCredentials>({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    company: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateField = (name: string, value: string) => {
    switch (name) {
      case 'email':
        if (!value.trim()) return 'Email is required';
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim())) {
          return 'Please enter a valid email address';
        }
        break;
      case 'password':
        if (!value.trim()) return 'Password is required';
        if (value.length < 8) return 'Password must be at least 8 characters';
        break;
      case 'firstName':
        if (!value.trim()) return 'First name is required';
        break;
      case 'lastName':
        if (!value.trim()) return 'Last name is required';
        break;
      case 'phoneNumber':
        if (!value.trim()) return 'Phone number is required';
        if (!/^\+?[\d\s-]{10,}$/.test(value.trim())) {
          return 'Please enter a valid phone number';
        }
        break;
    }
    return '';
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const error = validateField(name, value);
    if (error) {
      setErrors(prev => ({ ...prev, [name]: error }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Validate all fields
    const newErrors: Record<string, string> = {};
    Object.entries(formData).forEach(([key, value]) => {
      if (key !== 'company') { // Company is optional
        const error = validateField(key, value);
        if (error) newErrors[key] = error;
      }
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    try {
      const validationError = validateSignUp(formData);
      if (validationError) {
        toast.error(validationError);
        return;
      }

      const authService = AuthService.getInstance();
      const result = await authService.signUp(formData);
      
      if (result.mfaData) {
        onComplete({ mfaData: result.mfaData });
      } else {
        toast.success('Account created successfully!');
        onCancel();
      }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            First Name <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              onBlur={handleBlur}
              className={`pl-10 w-full p-2 border rounded focus:ring-sky-500 focus:border-sky-500 ${
                errors.firstName ? 'border-red-500' : 'border-gray-300'
              }`}
              required
              placeholder="Enter your first name"
            />
          </div>
          {errors.firstName && (
            <p className="mt-1 text-sm text-red-500">{errors.firstName}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Last Name <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              onBlur={handleBlur}
              className={`pl-10 w-full p-2 border rounded focus:ring-sky-500 focus:border-sky-500 ${
                errors.lastName ? 'border-red-500' : 'border-gray-300'
              }`}
              required
              placeholder="Enter your last name"
            />
          </div>
          {errors.lastName && (
            <p className="mt-1 text-sm text-red-500">{errors.lastName}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Email <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            onBlur={handleBlur}
            className={`pl-10 w-full p-2 border rounded focus:ring-sky-500 focus:border-sky-500 ${
              errors.email ? 'border-red-500' : 'border-gray-300'
            }`}
            required
            placeholder="Enter your email"
          />
        </div>
        {errors.email && (
          <p className="mt-1 text-sm text-red-500">{errors.email}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Password <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            onBlur={handleBlur}
            className={`pl-10 w-full p-2 border rounded focus:ring-sky-500 focus:border-sky-500 ${
              errors.password ? 'border-red-500' : 'border-gray-300'
            }`}
            required
            minLength={8}
            placeholder="Enter your password"
          />
        </div>
        {errors.password ? (
          <p className="mt-1 text-sm text-red-500">{errors.password}</p>
        ) : (
          <p className="mt-1 text-sm text-gray-500">Must be at least 8 characters</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Phone Number <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="tel"
            name="phoneNumber"
            value={formData.phoneNumber}
            onChange={handleChange}
            onBlur={handleBlur}
            className={`pl-10 w-full p-2 border rounded focus:ring-sky-500 focus:border-sky-500 ${
              errors.phoneNumber ? 'border-red-500' : 'border-gray-300'
            }`}
            required
            placeholder="Enter your phone number"
            pattern="\+?[\d\s-]{10,}"
          />
        </div>
        {errors.phoneNumber && (
          <p className="mt-1 text-sm text-red-500">{errors.phoneNumber}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Company
        </label>
        <div className="relative">
          <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            name="company"
            value={formData.company}
            onChange={handleChange}
            className="pl-10 w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
            placeholder="Enter your company name (optional)"
          />
        </div>
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          disabled={loading || Object.keys(errors).length > 0}
          className="flex-1 bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 disabled:opacity-50"
        >
          {loading ? 'Creating Account...' : 'Create Account'}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded hover:bg-gray-200"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}