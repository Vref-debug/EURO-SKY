import React, { useState } from 'react';
import { Mail, Lock } from 'lucide-react';
import { DummyAuthService } from '../../lib/auth/dummyAuth.service';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

export function DummyLoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const authService = DummyAuthService.getInstance();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { user } = await authService.signIn({ email, password });
      localStorage.setItem('dummyUser', JSON.stringify(user));
      toast.success('Login successful!');
      navigate(`/${user.role}-dashboard`);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-2xl p-8 w-full max-w-md mx-auto">
      <h2 className="text-2xl font-bold text-center mb-6">Demo Login</h2>
      
      <div className="mb-4 p-3 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-800">
          Demo Accounts:
        </p>
        <ul className="text-sm text-blue-600 mt-1 space-y-1">
          <li>school-admin@demo.com / demo1234</li>
          <li>mechanic@demo.com / demo1234</li>
          <li>owner@demo.com / demo1234</li>
          <li>admin@demo.com / demo1234</li>
        </ul>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              disabled={loading}
              placeholder="Enter your email"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Password
          </label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              disabled={loading}
              placeholder="Enter your password"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-sky-600 text-white py-3 px-4 rounded-lg hover:bg-sky-700 focus:ring-4 focus:ring-sky-500/50 font-medium transition-colors disabled:opacity-50"
        >
          {loading ? 'Logging in...' : 'Log In'}
        </button>
      </form>
    </div>
  );
}