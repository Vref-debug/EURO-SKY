import React from 'react';
import { Plane } from 'lucide-react';

interface AuthLayoutProps {
  children: React.ReactNode;
}

export function AuthLayout({ children }: AuthLayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-800 to-sky-600 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center bg-white/10 rounded-full p-3 mb-4">
            <Plane className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Welcome to Euro-Sky</h1>
          <p className="text-sky-100">Aircraft Maintenance Management</p>
        </div>
        {children}
      </div>
    </div>
  );
}