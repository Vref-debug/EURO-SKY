import React, { useState } from 'react';
import { Clock } from 'lucide-react';
import { formatDate, isDateValid } from '../../utils/dateUtils';

interface FlightHoursUpdateProps {
  lastUpdated: string;
  onUpdate: (hours: number, date: string) => void;
}

export function FlightHoursUpdate({ lastUpdated, onUpdate }: FlightHoursUpdateProps) {
  const [hours, setHours] = useState('');
  const [date, setDate] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const selectedDate = new Date(date);
    const lastUpdateDate = new Date(lastUpdated.split('/').reverse().join('-'));

    if (selectedDate < lastUpdateDate) {
      setError('Selected date cannot be earlier than the last update');
      return;
    }

    if (Number(hours) <= 0) {
      setError('Hours must be greater than 0');
      return;
    }

    onUpdate(Number(hours), formatDate(selectedDate));
    setHours('');
    setDate('');
    setError('');
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Submit Flight Hours</h3>
        <Clock className="w-6 h-6 text-sky-600" />
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Flight Hours
          </label>
          <input
            type="number"
            step="0.1"
            value={hours}
            onChange={(e) => setHours(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
            required
            min="0.1"
            placeholder="Enter flight hours"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Flight Date
          </label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            min={lastUpdated.split('/').reverse().join('-')}
            className="w-full p-2 border border-gray-300 rounded focus:ring-sky-500 focus:border-sky-500"
            required
          />
        </div>

        {error && (
          <p className="text-red-500 text-sm">{error}</p>
        )}

        <button
          type="submit"
          className="w-full bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 transition-colors"
        >
          Submit Flight Hours
        </button>
      </form>
    </div>
  );
}