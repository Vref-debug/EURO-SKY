import React from 'react';
import { AlertCircle } from 'lucide-react';

interface FlightHoursInfoProps {
  totalHours: number;
  lastUpdated: string;
}

export function FlightHoursInfo({ totalHours, lastUpdated }: FlightHoursInfoProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Flight Hours Status</h3>
        <AlertCircle className="w-6 h-6 text-sky-600" />
      </div>
      <div className="space-y-3">
        <div className="flex justify-between">
          <span className="text-gray-600">Total Flight Hours</span>
          <span className="font-semibold">{totalHours.toFixed(1)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">Last Updated</span>
          <span className="font-semibold">{lastUpdated}</span>
        </div>
      </div>
    </div>
  );
}