import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserCircle, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { DummyAuthService } from '../lib/auth/dummyAuth.service';
import { formatRole } from '../utils/textUtils';

export function ProfileMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();
  const menuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const authService = DummyAuthService.getInstance();

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSignOut = async () => {
    try {
      await authService.signOut();
      localStorage.removeItem('dummyUser');
      navigate('/auth');
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  if (!user) return null;

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-3 text-white hover:text-sky-200 transition-colors"
      >
        <UserCircle className="w-8 h-8" />
        <div className="text-left">
          <div className="font-medium">{user.firstName}</div>
          {user.role && (
            <div className="text-sm text-sky-300">{formatRole(user.role)}</div>
          )}
        </div>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-1 z-50">
          <button
            onClick={handleSignOut}
            className="flex items-center w-full px-4 py-2 text-gray-700 hover:bg-sky-50"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </button>
        </div>
      )}
    </div>
  );
}