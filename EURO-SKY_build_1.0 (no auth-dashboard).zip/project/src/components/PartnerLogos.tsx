import React from 'react';
import { logos } from '../assets/logos';

export function PartnerLogos() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex flex-wrap items-center justify-center gap-8">
        <a href="https://txtav.com/" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded hover:opacity-80 transition-opacity">
          <img 
            src={logos.textron}
            alt="Textron Aviation" 
            className="h-12 md:h-14 object-contain"
          />
        </a>
        <a href="https://www.piper.com/" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded hover:opacity-80 transition-opacity">
          <img 
            src={logos.piper}
            alt="Piper Aircraft" 
            className="h-10 md:h-12 object-contain"
          />
        </a>
        <a href="https://www.rotax.com/" target="_blank" rel="noopener noreferrer" className="bg-white p-4 rounded hover:opacity-80 transition-opacity">
          <img 
            src={logos.rotax}
            alt="Rotax Aircraft Engines" 
            className="h-10 md:h-12 object-contain"
          />
        </a>
      </div>
    </div>
  );
}