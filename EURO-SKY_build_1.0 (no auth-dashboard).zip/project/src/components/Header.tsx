import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Plane, Menu, X } from 'lucide-react';
import { ServicesDropdown } from './ServicesDropdown/ServicesDropdown';
import { LanguageSwitcher } from './LanguageSwitcher';
import { ProfileMenu } from './ProfileMenu';
import { useLanguage } from '../i18n/LanguageContext';
import { useAuth } from '../hooks/useAuth';

export function Header() {
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { t } = useLanguage();
  const { user } = useAuth();

  const scrollToContact = (e: React.MouseEvent) => {
    e.preventDefault();
    if (window.location.pathname !== '/') {
      navigate('/');
      setTimeout(() => {
        document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="bg-sky-900 text-white relative">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-3">
            <Plane className="h-8 w-8" />
            <h1 className="text-2xl font-bold">Euro-Sky BV</h1>
          </Link>
          
          <div className="flex items-center space-x-6">
            <nav className="hidden md:block">
              <ul className="flex space-x-6">
                <li><Link to="/" className="hover:text-sky-300">{t('nav.home')}</Link></li>
                <li><Link to="/about" className="hover:text-sky-300">{t('nav.about')}</Link></li>
                <li className="relative">
                  <button 
                    className="hover:text-sky-300 flex items-center"
                    onMouseEnter={() => setIsServicesOpen(true)}
                    onMouseLeave={() => setIsServicesOpen(false)}
                  >
                    {t('nav.services')}
                    <ServicesDropdown isOpen={isServicesOpen} />
                  </button>
                </li>
                <li><Link to="/team" className="hover:text-sky-300">{t('nav.team')}</Link></li>
                <li><a href="#contact" onClick={scrollToContact} className="hover:text-sky-300">{t('nav.contact')}</a></li>
              </ul>
            </nav>

            <div className="flex items-center space-x-6">
              <LanguageSwitcher />
              {user && <ProfileMenu />}
              <button 
                className="md:hidden"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {isMobileMenuOpen && (
          <nav className="md:hidden mt-4">
            <ul className="space-y-4">
              <li><Link to="/" className="block hover:text-sky-300">{t('nav.home')}</Link></li>
              <li><Link to="/about" className="block hover:text-sky-300">{t('nav.about')}</Link></li>
              <li>
                <button 
                  className="w-full text-left hover:text-sky-300"
                  onClick={() => setIsServicesOpen(!isServicesOpen)}
                >
                  {t('nav.services')}
                </button>
                {isServicesOpen && <ServicesDropdown isOpen={true} />}
              </li>
              <li><Link to="/team" className="block hover:text-sky-300">{t('nav.team')}</Link></li>
              <li><a href="#contact" onClick={scrollToContact} className="block hover:text-sky-300">{t('nav.contact')}</a></li>
            </ul>
          </nav>
        )}
      </div>
    </header>
  );
}