/*
  # Add Flight School Admin Role

  1. Changes
    - Add new 'flight-school-admin' role to user_roles
    - Add corresponding dashboard path to role_dashboards
    - Update existing roles descriptions
*/

-- First ensure the role doesn't exist
DELETE FROM user_roles WHERE role = 'flight-school-admin';

-- Insert the new role
INSERT INTO user_roles (role, description)
VALUES ('flight-school-admin', 'Flight school administrator with oversight of training operations');

-- Add dashboard path for the new role
INSERT INTO role_dashboards (role, dashboard_path)
VALUES ('flight-school-admin', '/flight-school-admin-dashboard');

-- Clean up any orphaned entries
DELETE FROM role_dashboards
WHERE role NOT IN (SELECT role FROM user_roles);

-- Update or insert dashboard paths for all roles to ensure consistency
INSERT INTO role_dashboards (role, dashboard_path)
VALUES 
  ('pilot', '/pilot-dashboard'),
  ('instructor', '/instructor-dashboard'),
  ('mechanic', '/mechanic-dashboard'),
  ('inspector', '/inspector-dashboard'),
  ('manager', '/manager-dashboard'),
  ('scheduler', '/scheduler-dashboard'),
  ('student', '/student-dashboard'),
  ('owner', '/owner-dashboard'),
  ('admin', '/admin-dashboard'),
  ('flight-school-admin', '/flight-school-admin-dashboard')
ON CONFLICT (role) 
DO UPDATE SET 
  dashboard_path = EXCLUDED.dashboard_path,
  updated_at = now();