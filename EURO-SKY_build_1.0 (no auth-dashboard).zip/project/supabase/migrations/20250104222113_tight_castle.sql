/*
  # Update Role Dashboards Schema and Data

  1. Schema Changes
    - Add updated_at column to role_dashboards
    - Add trigger for automatic updated_at updates

  2. Data Updates
    - Clean up orphaned entries
    - Update dashboard paths for all roles
*/

-- First ensure the updated_at column exists
ALTER TABLE role_dashboards 
ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

-- Create or replace the timestamp update function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create the trigger if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'set_role_dashboards_updated_at'
  ) THEN
    CREATE TRIGGER set_role_dashboards_updated_at
    BEFORE UPDATE ON role_dashboards
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

-- Clean up any orphaned entries
DELETE FROM role_dashboards
WHERE role NOT IN (SELECT role FROM user_roles);

-- Update or insert dashboard paths for all roles
INSERT INTO role_dashboards (role, dashboard_path)
VALUES 
  ('pilot', '/pilot-dashboard'),
  ('instructor', '/instructor-dashboard'),
  ('mechanic', '/mechanic-dashboard'),
  ('inspector', '/inspector-dashboard'),
  ('manager', '/manager-dashboard'),
  ('scheduler', '/scheduler-dashboard'),
  ('student', '/student-dashboard'),
  ('owner', '/owner-dashboard'),
  ('admin', '/admin-dashboard')
ON CONFLICT (role) 
DO UPDATE SET 
  dashboard_path = EXCLUDED.dashboard_path;