/*
  # Synchronize User Roles and Role Dashboards

  1. Changes
    - Ensures all user roles have corresponding dashboard paths
    - Updates existing dashboard paths to match current role structure
    - Adds missing role-dashboard mappings
    - Removes orphaned dashboard entries

  2. Security
    - Maintains existing RLS policies
    - No changes to existing security model
*/

-- First, clean up any orphaned entries in role_dashboards
DELETE FROM role_dashboards
WHERE role NOT IN (SELECT role FROM user_roles);

-- Update or insert dashboard paths for all roles
INSERT INTO role_dashboards (role, dashboard_path)
VALUES 
  ('pilot', '/pilot-dashboard'),
  ('instructor', '/instructor-dashboard'),
  ('mechanic', '/mechanic-dashboard'),
  ('inspector', '/inspector-dashboard'),
  ('manager', '/manager-dashboard'),
  ('scheduler', '/scheduler-dashboard'),
  ('student', '/student-dashboard'),
  ('owner', '/owner-dashboard'),
  ('admin', '/admin-dashboard')
ON CONFLICT (role) 
DO UPDATE SET 
  dashboard_path = EXCLUDED.dashboard_path,
  updated_at = now();

-- Add updated_at trigger if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'set_role_dashboards_updated_at'
  ) THEN
    CREATE TRIGGER set_role_dashboards_updated_at
    BEFORE UPDATE ON role_dashboards
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;