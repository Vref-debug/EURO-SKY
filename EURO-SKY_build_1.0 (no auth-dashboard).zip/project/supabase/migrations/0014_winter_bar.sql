/*
  # Fix Profile Creation and Role Management

  1. Changes
    - Update profile trigger to properly handle new user creation
    - Add role validation
    - Ensure proper column defaults

  2. Security
    - Maintain RLS policies
    - Add proper constraints
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create improved function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    email,
    first_name,
    last_name,
    phone_number,
    company,
    role,
    created_at,
    mfa_status
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'first_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'last_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'phone_number', ''),
    NEW.raw_user_meta_data->>'company',
    NEW.raw_user_meta_data->>'role',
    NOW(),
    'pending'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Ensure profiles table has all required columns with proper defaults
DO $$ 
BEGIN
  -- Add columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'mfa_status'
  ) THEN
    ALTER TABLE profiles ADD COLUMN mfa_status text DEFAULT 'pending';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'role'
  ) THEN
    ALTER TABLE profiles ADD COLUMN role text;
  END IF;

  -- Set NOT NULL constraints where appropriate
  ALTER TABLE profiles 
    ALTER COLUMN email SET NOT NULL,
    ALTER COLUMN first_name SET NOT NULL,
    ALTER COLUMN last_name SET NOT NULL,
    ALTER COLUMN phone_number SET NOT NULL,
    ALTER COLUMN mfa_status SET NOT NULL;

  -- Add foreign key constraint if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'profiles_role_fkey'
  ) THEN
    ALTER TABLE profiles
    ADD CONSTRAINT profiles_role_fkey 
    FOREIGN KEY (role) 
    REFERENCES user_roles(role) 
    ON DELETE SET NULL;
  END IF;
END $$;